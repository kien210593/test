#!/usr/bin/env python
# coding: utf-8

# In[1]:


import cv2
from pyzbar.pyzbar import decode
import numpy as np
import pandas as pd
from PIL import Image
from glob import glob
import os
from pathlib import Path
import random
import re
from tqdm import tqdm
import json
import argparse

# In[2]:


def convert_box2yolo2(size, box): # (x_center, y_center, w, h)
    width = size[0]
    height = size[1]
    return box[0]/width, box[1]/height, box[2]/width, box[3]/height


# In[14]:


def map_image2track_csv_file(folder_img, csv_file, img_size):
    startX, startY, width, height = 0, 0, 170, 12
    img_dir = sorted(glob(folder_img+'/*.jpg'))
    ID = []
    topx = []
    topy = []
    w = []
    h = []
    clss = []
    flag1 = 'AI CLICKED - DETECTED'
    flag2 = 'AI TIT - DETECTED'
    flag3 = 'AI RE DETECT - DETECTED'
    # flag4 = 'Detect result empty!'
    # flag5 = 'Init location is out of image'
    cls = 0
    state_detect = False
    dic_detect = []
    state_TiT = False
    dic_TiT = []
    state_redetect = False
    dic_redetect = []
    index = 0
    #print("Reading csv file")
    with open(csv_file, 'r') as file:
        for line in file:
            index = index+1
            count = line.count(',')
            count1 = line.count('ID')
            # print('cls:', cls)
            if flag1 in line:
                # print(line)
                cls =1
                state_detect = True
            if flag2 in line:
                # print(line)
                cls = 0
                state_TiT = True
                # print(cls)
            if flag3 in line:
                # print(line)
                cls = 1
                state_redetect = True
            # # wrong if flag4 or flag5 in line ???
            # if flag4 in line:
            #     # print(line)
            #     cls = 1
            #     state_redetect = False
            # if flag5 in line:
            #     cls = 1
            #     state_redetect = False
            if count == 4 and count1 == 0:
                numbers = re.findall(r'\d+\.\d+|\d+', line)
                # numbers = re.findall(r'\b\d+\.\d+\b', line)
                # print('numbers:', numbers)
                if state_detect == True:
                    dic_detect.append(numbers[0])
                    state_detect = False
                if state_redetect == True:
                    dic_redetect.append(numbers[0])
                    state_redetect = False
                if state_TiT == True:
                    dic_TiT.append(numbers[0])
                    state_TiT = False 
                ID.append(numbers[0])
                clss.append(cls)
                topx.append(float(numbers[1]))
                topy.append(float(numbers[2]))
                w.append(float(numbers[3]))
                h.append(float(numbers[4]))            
                # 1/0
            if count >= 8 and count1 ==0:
                numbers = re.findall(r'\d+\.\d+|\d+', line)
                # numbers = re.findall(r'\b\d+\.\d+\b', line)
                # print('numbers:', numbers)
                ID.append(numbers[0])
                clss.append(cls)
                topx.append(float(numbers[2]))
                topy.append(float(numbers[3]))
                w.append(float(numbers[4]))
                h.append(float(numbers[5]))
        
    df1 = pd.DataFrame(ID, columns = ['ID'])
    dfcls = pd.DataFrame(clss, columns = ['class'])
    df2 = pd.DataFrame(topx, columns = ['x'])
    df3 = pd.DataFrame(topy, columns = ['y'])
    df4 = pd.DataFrame(w, columns = ['w'])
    df5 = pd.DataFrame(h, columns = ['h'])
    df = pd.concat([df1,dfcls,df2,df3,df4,df5], axis = 1)
    # print(df)
    
#     startID = int(df1['ID'].iloc[0])
#     print(startID)
    
    
    parent_folder = str(Path(folder_img).parent.absolute())
    name_new_json = '_'.join(folder_img.split("/")[-1].split("_")[:-1]) + ".json"
    save_in = parent_folder + "/" + name_new_json
    dict_all = {"dic_detect": dic_detect, "dic_TiT":dic_TiT, "dic_redetect": dic_redetect}
    with open(save_in, 'w') as f:
        json.dump(dict_all, f)

    
    
    parent_folder = str(Path(folder_img).parent.absolute())
    name_new_folder = '_'.join(folder_img.split("/")[-1].split("_")[:])
    target_folder_txt = parent_folder + "/" + name_new_folder + '_tracking_lb/'
    Path(target_folder_txt).mkdir(parents=True, exist_ok=True)
    target_folder_img = parent_folder + "/" + name_new_folder + '_tracking_im/'
    Path(target_folder_img).mkdir(parents=True, exist_ok=True)
    
    cls = 1 
    beg = 0
    count = 0
    barcode_error = 5555555
    # print(img_dir[0])
    for (im_i, im_path) in enumerate(tqdm(img_dir, "mapping")):
        # print('im_path:', im_path)
        # tmp = im_path.split("/")[-1]
        # tmp = tmp[: tmp.rindex(".")]
        # tmp = int(tmp.split("_")[-1])
        image = cv2.imread(im_path)
        image_copy = image.copy()
        # crop_box = [startX, startY, startX + width, startY+ height]
        # print('crop_box:', crop_box)
        # cropped_image = image[startY:startY+ height, startX: startX+width]
        decode_objects = decode(image)
        for obj in decode_objects:
            barcode_data = obj.data.decode('utf-8')
            barcode_type = obj.type
            # tmp = int(barcode_data[0:7])
            try:
                tmp = int(barcode_data[0:7])
            except:
                tmp = barcode_error
        
        if tmp == barcode_error:
            barcode_error += 1
            continue
#             if im_i == 0:
#                 startID = tmp
#                 print(startID)
        for i in range(beg, len(df)):
            # print('tmp:', tmp)
            # print(tmp, df['ID'].iloc[i])
            if tmp == int(df['ID'].iloc[i]):
                count = count+1
                if count == 1:
                    startID = tmp
                    print(startID)
                beg = i
                name = im_path.split('/')[-1].split('.')[0]
                file1 = target_folder_txt + name + '.txt'
                #print(file1)
                box = [int(df['x'].iloc[i]), int(df['y'].iloc[i]), int(df['w'].iloc[i]), int(df['h'].iloc[i])]
                box1 = convert_box2yolo2(img_size, box)
                cls = int(df['class'].iloc[i])
                # if cls == 0:
                #     print(name)
                lines= []
                with open(file1, 'w') as f:
                    lines.append(f"{cls} {' '.join(f'{x:.6f}' for x in box1)}\n")
                    f.writelines(lines)
                
                file2 =target_folder_img + name + ".jpg"
                # print('file2:', file2)
                cv2.imwrite(file2, image_copy)
                break
    
    # print("Image result save in:", target_folder_img)
    # print("Label resutl save in:", target_folder_txt)
    return 1
    


# In[15]:


# folder_img="/home/pc1/works/HungNV/tank/9/tank_sb_916_Txx_00000009_07_03_clip5"
# csv_file="/home/pc1/works/HungNV/tank/9/00000009.csv"
# map_image2track_csv_file(folder_img, csv_file)


if __name__ == "__main__":
        
    parser = argparse.ArgumentParser("Read_file_seeker")
    parser.add_argument('--ilog', required=False, type=str) #Tracking images folder
    parser.add_argument('--csv', required=False, type=str) #IP Log file path
    parser.add_argument('--imgsz', default = (1920,1080), nargs='+', type = int) 
    args = parser.parse_args()
    # folder_img = '/mnt/data/hungnv152/data/UAV_2X/tank_video/video_do_kiem_hung/test/tank_sb_916_T02_00000002_17_05_clip1'
    # csv_file = '/mnt/data/hungnv152/data/UAV_2X/tank_video/video_do_kiem_hung/test/00000002.csv'
    
    # folder_img = "/mnt/data/hungnv152/data/UAV_2X/tank_video/1/videorecord/tank_sb_yb_T05_00000193_13_01_clip5"
    # csv_file = "/mnt/data/hungnv152/data/UAV_2X/tank_video/1/ip_log/ip_log/00000193.csv"
    
    folder_img = args.ilog
    csv_file = args.csv
    # img_size = (640,512)
    # img_size = (1920, 1080)

    # img_size = [int(i) for i in args.imgsz.split(",")]
    img_size = tuple(args.imgsz)
    startID = map_image2track_csv_file(folder_img, csv_file, img_size)
    
    #python 2_0_read_file_seeker_v1.py --ilog=/mnt/data/hungnv152/data/UAV_2X/tank_video/1/videorecord/new/tank_sb_yb_T05_00000193_13_01_clip5 --csv=/mnt/data/hungnv152/data/UAV_2X/tank_video/1/ip_log/ip_log/00000193.csv




