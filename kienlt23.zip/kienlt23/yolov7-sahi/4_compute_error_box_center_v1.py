#!/usr/bin/env python
# coding: utf-8


import pandas as pd
import numpy as np
import csv
from pathlib import Path
import cv2
import glob
import os
from tqdm import tqdm
import re
import random
import time
import argparse


def check_file_exist(file_path): #check file exist or not
    '''
    input: file_path: string: ""
    output: boolean: True or False
    '''
    return os.path.exists(file_path)


# In[3]:


def calculate_iou(arr_box1, arr_box2):
    x_left_intercept = max(arr_box1[1], arr_box2[1])
    y_left_intercept = max(arr_box1[2], arr_box2[2])
    x_right_intercept = min(arr_box1[3], arr_box2[3])
    y_right_intercept = min(arr_box1[4], arr_box2[4])
    
    w_intercept = max(0, x_right_intercept - x_left_intercept)
    h_intercept = max(0, y_right_intercept - y_left_intercept)
    
    area_intercept = w_intercept * h_intercept
    area_box1 = (arr_box1[3] - arr_box1[1]) * (arr_box1[4] - arr_box1[2])
    area_box2 = (arr_box2[3] - arr_box2[1]) * (arr_box2[4] - arr_box2[2])
    area_union = area_box1 + area_box2 - area_intercept
    
    iou = area_intercept / area_union
    return iou


# In[4]:


def xywhn2xyxy(size, boxes):
    '''
    input: List: [[class, x, y, w, h], [...]]
            size: Tuple: (w, h)
    output: List: [[class, x1, y1, x2, y2], [...]]
    '''
    w = size[0]
    h = size[1]
    box_xyxy = []
    for box in boxes:
        x1 = max(int((box[1]-box[3]/2)*w), 0)
        y1 = max(int((box[2]-box[4]/2)*h), 0)
        x2 = min(int((box[1]+box[3]/2)*w), w)
        y2 = min(int((box[2]+box[4]/2)*h), h)
        box_xyxy.append([box[0], x1, y1, x2, y2])
    return box_xyxy

def xyxy2xywh(box):
    '''
    input: List: [[class, x, y, w, h], [...]]
            size: Tuple: (w, h)
    output: List: [[class, x1, y1, x2, y2], [...]]
    '''
    x1, y1, x2, y2 = box[1], box[2], box[3], box[4]
    x = max(int((x1+x2)/2), 0)
    y = max(int((y1+y2)/2), 0)
    w = int(x2-x1)
    h = int(y2-y1)
    box_xywh = [box[0], x, y, w, h]
    return box_xywh


# In[5]:


def increment_path(path, exist_ok=True, sep=''):
    # Increment path, i.e. runs/exp --> runs/exp{sep}0, runs/exp{sep}1 etc.
    path = Path(path)  # os-agnostic
    if (path.exists() and exist_ok) or (not path.exists()):
        return str(path)
    else:
        dirs = glob.glob(f"{path}{sep}*")  # similar paths
        matches = [re.search(rf"%s{sep}(\d+)" % path.stem, d) for d in dirs]
        i = [int(m.groups()[0]) for m in matches if m]  # indices
        n = max(i) + 1 if i else 2  # increment number
        return f"{path}{sep}{n}"  # update path
    
def plot_one_box(x, img, color=None, label=None, line_thickness=1):
    # Plots one bounding box on image img
    tl = line_thickness #or round(0.002 * (img.shape[0] + img.shape[1]) / 2) + 1  # line/font thickness
    color = color or [random.randint(0, 255) for _ in range(3)]
    c1, c2 = (int(x[1]), int(x[2])), (int(x[3]), int(x[4]))
    cv2.rectangle(img, c1, c2, color, thickness=tl, lineType=cv2.LINE_AA)
    if label:
        tf = max(tl - 1, 1)  # font thickness
        t_size = cv2.getTextSize(label, 0, fontScale=tl / 3, thickness=tf)[0]
        c2 = c1[0] + t_size[0], c1[1] - t_size[1] - 3
        cv2.rectangle(img, c1, c2, color, -1, cv2.LINE_AA)  # filled
        cv2.putText(img, label, (c1[0], c1[1] - 2), 0, tl / 3, [225, 255, 255], thickness=tf, lineType=cv2.LINE_AA)


# In[6]:


def is_file_empty(file_path):
    return os.path.getsize(file_path) == 0


# In[7]:


def define_TiT(json_file):
    return os.path.getsize(file_path) == 0


# In[8]:
import json

threshold1 = 120
def compute_error_bbox_center(tracking_folder, tracking_folder_lb, detect_folder, json_file, phase = 'dic_TiT'):
    if phase is not None:
        with open(json_file, "r") as json_data:
            state = json.load(json_data)
        phase_startIDs = np.array([int(i) for i in state[phase]])
    
    parent_folder = str(Path(tracking_folder).parent.absolute())
    name_new_folder = '_'.join(tracking_folder.split("/")[-1].split("_")[:-2])
    type = '_for_detect' if 'for_detect' in tracking_folder_lb else '_tracking'
    name_new_folder = name_new_folder + type + "_cp_error"
    save_dir = parent_folder + "/" + name_new_folder
    # save_dir = increment_path(save_dir, exist_ok=False)
    Path(save_dir).mkdir(parents=True, exist_ok=True)
    
    list_image_path = sorted(glob.glob(tracking_folder + "/" + "*.jpg"))
    min_id = int(list_image_path[0][:-4].split("_")[-1])
    max_id = int(list_image_path[-1][:-4].split("_")[-1])
        
    if phase is not None:
        if np.digitize(max_id, phase_startIDs) - np.digitize(min_id, phase_startIDs) == 1:
            start_ID = phase_startIDs[np.digitize(min_id, phase_startIDs)]
            # end_ID = 
        else:
            start_ID = None
    else:
        start_ID = min_id

    if start_ID is None:
        return False
    
    end_ID = len(list_image_path)

    for image_path in list_image_path[::-1]:
        name_image = Path(image_path).name
        name_label = name_image[:-4] + ".txt"
        
        label_track_path = tracking_folder_lb + "/" + name_label
        label_detect_path = detect_folder + "/" + name_label
       
        if not is_file_empty(label_detect_path):
            break
        else:
            end_ID -= 1

    
    t0=time.time()
    for i, image_path in enumerate(tqdm(list_image_path)):
        name_image = Path(image_path).name
        name_label = name_image[:-4] + ".txt"
        name_label_gt = "_".join(name_label.split("_")[:-1]) + ".txt"
        label_track_path = tracking_folder_lb + "/" + name_label
        label_detect_path = detect_folder + "/" + name_label


        if check_file_exist(label_track_path) and check_file_exist(label_detect_path) and is_file_empty(label_detect_path)==False and is_file_empty(label_track_path)==False:
            image = cv2.imread(image_path)
            id = int(name_image[:-4].split("_")[-1])
            if id <= start_ID:
                continue
            if end_ID is not None and i > end_ID:
                print("Stop at: ", i)
                break
#             print('id: ', id)
            height, width = image.shape[:2]
            
            df = pd.read_csv(label_track_path, header = None, sep=' ')
            box_xywhn_track = df.values
            box_xyxy_track = xywhn2xyxy((width, height), box_xywhn_track)
                # if is_file_empty(label_detect_path):
                    
            # print(label_detect_path)
            df1 = pd.read_csv(label_detect_path, header = None, sep=' ')
            # if df1 == None:
            #     print('label_detect_path:', label_detect_path)
            box_xywhn_detect = df1.values
            
            box_xyxy_detect = xywhn2xyxy((width, height), box_xywhn_detect)
            # print('box_xyxy_detect:', box_xyxy_detect)
            # print('box_xyxy_track:' , box_xyxy_track)

            
            for box_track in box_xyxy_track:
                cls_track = box_track[0]
                if cls_track == 1:
                    threshold1 = 120
                else:
                    threshold1 = 60
                max_iou = 0
                max_match_box = None
                for box_detect in box_xyxy_detect:
                    if int(box_track[0]) == int(box_detect[0]) or box_detect[0]==1:
                    # if box_detect[0]==1:
                        iou = calculate_iou(box_track, box_detect)
                    else:
                        iou=0
                    # if iou > max_iou and box_detect[0]==1:
                    if iou > max_iou:
                                # print(box_detect)
                        max_iou = iou
                        max_match_box = box_detect
                # print('max_match_box:', max_match_box)
                # 1/0
                    
                if max_match_box != None:
                    if max((max_match_box[3]-max_match_box[1]), (max_match_box[4]-max_match_box[2]))> threshold1:
                        for box_track in box_xyxy_track:
                            max_iou = 0
                            max_match_box = None
                            for box_detect in box_xyxy_detect:
                                if box_detect[0]==0:
                                    iou = calculate_iou(box_track, box_detect)
                                else:
                                    iou=0
                                # if iou > max_iou and box_detect[0]==1:
                                if iou > max_iou:
                                    # print(box_detect)
                                    max_iou = iou
                                    max_match_box = box_detect                  
                
                if max_match_box != None:
                    box_xywh_track = xyxy2xywh(box_track)
                    box_xywh_detect = xyxy2xywh(max_match_box)
                    
                    x_error = np.abs(box_xywh_track[1] - box_xywh_detect[1])
                    y_error = np.abs(box_xywh_track[2] - box_xywh_detect[2])
                    error = np.sqrt(x_error**2 + y_error**2)
                    # Hungnv
                    # x_error = "{:.3f}".format(x_error)
                    # y_error = "{:.3f}".format(y_error)
                    # error = "{:.3f}".format(error)
                    data = [str(id), str(x_error), str(y_error), str(round(error, 3))]
                    #data0 = [name_label, str(id), str(box_xywh_detect[1]), str(box_xywh_detect[2]), str(box_xywh_detect[3]), str(box_xywh_detect[4]), str(int(box_xywh_detect[0]))]
                    
                    data0 = [str(id), str(box_xywh_detect[1]), str(box_xywh_detect[2]), str(box_xywh_detect[3]), str(box_xywh_detect[4]), str(int(box_xywh_detect[0]))]
                    
                    label = f"dx={x_error}, dy={y_error}, dxy={round(error,3)}"
                    plot_one_box(x=box_track, img=image, color=[0, 0, 255], label=label)
                    plot_one_box(x=max_match_box, color=[0, 255, 0], img=image)
                    save_img_path = save_dir + "/" + name_image
                    cv2.imwrite(save_img_path, image)
                    
                    path_file_csv = save_dir + "/" + "results.csv"
                    with open(path_file_csv, "a", encoding="UTF8") as f:
                        writer = csv.writer(f)
                        writer.writerow(data)
                    path_file_csv = save_dir + "/" + "results0.csv"
                    with open(path_file_csv, "a", encoding="UTF8") as f:
                        writer = csv.writer(f)
                        writer.writerow(data0)
    
    print('Completed in %.3f hours.\n' % ((time.time() - t0) / 3600))
    print("All result save in:", save_dir)
    return True


# tracking_folder = "/home/pc1/works/HungNV/tank/30/tank_sb916_T25_00000030_22_02_clip3_tracking_im_crop_rs"
# detect_folder = "/home/pc1/works/HungNV/tank/30/tank_sb916_T25_00000030_22_02_clip3_tracking_im_crop_rs_predict/label_predict/label_no_score"
# compute_error_bbox_center(tracking_folder, detect_folder)

if __name__ == "__main__":
        
    parser = argparse.ArgumentParser("Compute error box center")
    parser.add_argument('--tlog', required=True, type=str) #Tracking image folder
    parser.add_argument('--tllog', required=True, type=str) #Tracking label folder
    parser.add_argument('--plog', required=True, type=str) #Predict result folder
    parser.add_argument('--json', required=True, type=str) #Json file path
    parser.add_argument('--phase', required=False, default = None, type=str) # Optional
    
    args = parser.parse_args()
    tracking_folder = args.tlog
    tracking_folder_lb = args.tllog
    detect_folder = args.plog
    json_file = args.json
    phase = args.phase
    # tracking_folder = "/mnt/data/hungnv152/data/UAV_2X/tank_video/1/videorecord/new/tank_sb_yb_T05_00000193_13_01_clip5_tracking_im"
    # tracking_folder_lb = "/mnt/data/hungnv152/data/UAV_2X/tank_video/1/videorecord/tank_sb_yb_T05_00000193_13_01_clip5_labels"
    # detect_folder = "/mnt/data/hungnv152/data/UAV_2X/tank_video/1/videorecord/new/tank_sb_yb_T05_00000193_13_01_clip5_tracking_lb"
    # json_file = "/mnt/data/hungnv152/data/UAV_2X/tank_video/1/videorecord/new/tank_sb_yb_T05_00000193_13_01.json"
    # phase = None
    compute_error_bbox_center(tracking_folder, tracking_folder_lb, detect_folder, json_file, phase)
    
# python 4_compute_error_box_center_v1.py --tlog=/mnt/data/hungnv152/data/UAV_2X/tank_video/1/videorecord/new/tank_sb_yb_T05_00000193_13_01_clip5_tracking_im/ --tllog=/mnt/data/hungnv152/data/UAV_2X/tank_video/1/videorecord/new/tank_sb_yb_T05_00000193_13_01_clip5_labels --plog=/mnt/data/hungnv152/data/UAV_2X/tank_video/1/videorecord/new/tank_sb_yb_T05_00000193_13_01_clip5_tracking_lb --json=/mnt/data/hungnv152/data/UAV_2X/tank_video/1/videorecord/new/tank_sb_yb_T05_00000193_13_01.json



