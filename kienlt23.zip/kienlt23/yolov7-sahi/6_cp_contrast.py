#!/usr/bin/env python
# coding: utf-8



import numpy as np
import torch
import os
import cv2
from tqdm import tqdm
import argparse


def box_MBC(img_np, bboxes):
    """
    Return contrast value of object bboxes
    Arguments:
        bboxes (Array (N, 4) of xywh)
        img_np (HxW intensity array of an YUV-image read by numpy)
    Returns:
        MBC (Array (N) of contrast values
    """
    # Usage:
    # img_np = cv2.imread(img_path)
    # img_np_yuv = cv2.cvtColor(img_np, cv2.COLOR_BGR2YUV)[:,:,0]
    # box_MBC(img_np_yuv, bboxes)
    # Compares 0.8x region of bboxes to the 2x region of background surrounding the bbox
    size_background = 2
    crop_target = 0.8
    img_W, img_H = img_np.shape[1], img_np.shape[0]
    N = bboxes.shape[0]
    MBCs = torch.zeros(N)
    for i in range(N):
        x, y, w, h = bboxes[i, :]
        img_lv = img_np[
            int(min(img_H, y + (1 - crop_target) * h / 2)):int(min(img_H, y + (1 + crop_target) * h / 2)),
            int(min(img_W, x + (1 - crop_target) * w / 2)):int(min(img_W, x + (1 + crop_target) * w / 2))
        ]
        size_lv = img_lv.shape[0] * img_lv.shape[1]

        # Avoids bounding boxes with minimal size (0, 1)
        if size_lv <= 0:
            MBCs[i] = 0
            continue
        lv = int(np.sum(img_lv) / size_lv)
        img_lv_ = img_np[int(y) : min(img_H, int(y + h)), int(x) : min(img_W, int(x + w))]
        size_lv_ = img_lv_.shape[0] * img_lv_.shape[1]

        img_lb = img_np[
                 int(max(0, y - (size_background - 1) * h / 2)):int(min(img_H, max(0, y + (size_background + 1) * h / 2))),
                 int(max(0, x - (size_background - 1) * w / 2)):int(min(img_W, max(0, x + (size_background + 1) * w / 2))),
                 ]
        size_lb = img_lb.shape[0] * img_lb.shape[1]
        lb = int(np.sum(img_lb) - np.sum(img_lv_)) / (size_lb - size_lv_)
        
        # Calculate MBC
        MBC_Weber = abs(lv - lb) / (lb) if lb > 0.0 else 0
        MBC_Michelson = abs(lv - lb) / (lv + lb) if lv + lb > 0.0 else 0
        MBC_Kien = abs(lv - lb) / 255
        # print("MBC_Weber : {}, MBC_Michelson : {}, MBC_Kien : {}".format(MBC_Weber, MBC_Michelson, MBC_Kien))

        MBCs[i] = min(MBC_Weber, MBC_Michelson, MBC_Kien)
        
        # print(f'MBC weber {MBC_Weber} michel {MBC_Michelson} kien {MBC_Kien} all {min(MBC_Weber, MBC_Michelson, MBC_Kien)}')
        # import cv2
        # cv2.imshow('img_np', img_np)
        # cv2.imshow('img_lv', img_lv)
        # cv2.imshow('img_lb', img_lb)
        # k = cv2.waitKey(1)
        # if k==27:
        
        #     cv2.destroyAllWindows()
        #     sys.exit()

    return MBCs.reshape((N, 1))

def cp_contrast(file_txt, folder_image, target_file):
    with open(file_txt, 'r') as f:
        ground_truth = [x.split(",") for x in f.read().strip().splitlines()]
    image_file_name = os.listdir(folder_image)
    for bbox in tqdm(ground_truth, "cp_contrast"):
        new_bbox = bbox        
        for image_file in image_file_name:
            if bbox[0] in image_file:
                image_path = folder_image + "/" + image_file
                img_np = cv2.imread(image_path)
                img_np_yuv = cv2.cvtColor(img_np, cv2.COLOR_BGR2YUV)[:,:,0]
                x_topleft = int(int(bbox[1]) - int(bbox[3])/2)
                y_topleft = int(int(bbox[2]) - int(bbox[4])/2)
                box_xywh = np.array([[x_topleft, y_topleft, int(bbox[3]), int(bbox[4])]])
                
                
                contrast_values = box_MBC(img_np_yuv, box_xywh)
                contrast_values = contrast_values.item()
                new_bbox.append(str(round(contrast_values, 4)))
        
        with open(target_file, "a") as f:
            line = ",".join(map(str, new_bbox))
            line += "\n"
            f.write(line)
                
if __name__ == "__main__":
    # file_txt = "/home/pc1/works/HungNV/ball_video/bia_ll/test_case/try21/bia_tt_00000065_sb916_FT1_12_1_clip1_full.txt"
    # folder_image = "/home/pc1/works/HungNV/ball_video/bia_ll/test_case/try21/bia_tt_00000065_sb916_FT1_12_1_clip1"
    # target_file = "/home/pc1/works/HungNV/ball_video/bia_ll/test_case/try21/bia_tt_00000065_sb916_FT1_12_1_clip1_full_contrast.txt"
    # cp_contrast(file_txt, folder_image, target_file)

#     file_txt = "/home/pc1/Documents/gt/vlcsnap-2024-03-04-19h27m05s640.txt"
#     folder_image = "/home/pc1/Documents/test"
#     target_file = "/home/pc1/Documents/rs/1.txt"
#     cp_contrast(file_txt, folder_image, target_file)

#     file_txt = "/home/pc1/Documents/gt2/vlcsnap-2024-03-04-19h28m26s044.txt"
#     folder_image = "/home/pc1/Documents/test2"
#     target_file = "/home/pc1/Documents/rs2/1.txt"
    
    parser = argparse.ArgumentParser("Calculate contrast")
    parser.add_argument('--txtlog', required=True, type=str)
    parser.add_argument('--ilog', required=True, type=str)
    parser.add_argument('--tglog', required=True, type=str)
    args = parser.parse_args()
    file_txt = args.txtlog
    folder_image = args.ilog
    target_file = args.tglog
    
    
    cp_contrast(file_txt, folder_image, target_file)






