#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd
import numpy as np
import csv
from pathlib import Path
import cv2
import glob
import os
from tqdm import tqdm
import re
import random
import time
import shutil
import os
import csv
from numpy import savetxt
import matplotlib.pyplot as plt
import json
import argparse

# In[3]:


def save_result(result_file, bandicam_log, image_id_column = '', height_column_name=' UavAMSL'):
    parent_folder = str(Path(result_file).parent.absolute())
    bdc_log = pd.read_csv(bandicam_log)
    bdc_log = bdc_log.reset_index()
    # print(data1)
    # print(data1.columns)
    # print(data1[' Roll'])

    # print("alo:", data1[' Roll'].iloc[0])
    columns = ['ID', 'dx', 'dy', 'mse']
    data2 = pd.read_csv(result_file)
    try:
        data2.columns = columns
    except:
        data2 = data2.iloc[:, [0, 2, 3, 4]]
        data2.columns = columns

    p = 0
    barcode_error = 5555555
    # print(bdc_log[image_id_column].iloc[7689], data2['ID'][630])
    txt_file = result_file.split("/")[-1].split(".")[0] + '2.txt'
    file_save_txt = parent_folder + "/" + txt_file
    lastp = 0
    for i in range(0, len(data2)):
        gotError = False
        ID2 = int(data2['ID'][i])
        if ID2 == barcode_error:
            barcode_error += 1
            continue
        ID1 = int(bdc_log[image_id_column].iloc[p])
        mse = data2['mse'][i]
        # print('ID2:', ID2)
        # print('ID1:', ID1)
        while(ID1<ID2):
            p = p+1
            try:
                ID1 = int(bdc_log[image_id_column].iloc[p])
            except:
                gotError = True
                break
            # print(ID1)
        if gotError: 
            p = lastp
            continue
        lastp = p
        x = bdc_log[height_column_name].iloc[p]
        mse = data2['mse'][i]
        box = []
        
        box = [ID2, mse, f'{x:.3f}']
        lines = []
        with open(file_save_txt, 'a') as f1:
            lines.append(' '.join(f'{x}' for x in box) + "\n")
            f1.writelines(lines)

    print("Result save in:", file_save_txt)
    return file_save_txt

def plot_result_matplotlib(rs_file, json_file, target):
    
    columns1 = ['ID', 'mse', 'height']
    df1 = pd.read_csv(rs_file, sep = ' ', names = columns1, dtype = {'ID' : int, 'mse' : float, 'height': float}, keep_default_na = False)
    ID = []
    MSE = []
    H = []
    for i in range(0, len(df1)):
        id_image = df1['ID'][i]
        ID.append(id_image)
        H.append(df1['height'][i])
        MSE.append(df1['mse'][i])
    print("json_file: " , json_file)
    with open(json_file, "r") as json_data:
        state = json.load(json_data)
    detect = state['dic_detect']
    redetect = state['dic_redetect']
    TiT = state["dic_TiT"]

    beg = 0
    # end = 150
    end = len(ID)
    fig, ax1 = plt.subplots()
    ax1.plot(ID[beg:end], MSE[beg:end], color="black", label="MSE(pixel)")
    ax1.set_xlabel('ID')
    ax1.set_ylim([0,30])
    ax1.set_ylabel('mse')
    ax2 = ax1.twinx()
    ax2.plot(ID[beg:end], H[beg:end], 'y', color="yellow", label= "Height(m)")
    ax2.set_ylabel('height')
    ax1.grid()
    ax1.legend(loc="upper center")
    ax2.legend(loc="upper left")
    
    Id_max = max(ID[beg:end])
    Id_min = min(ID[beg:end])
    middle = int(max(H[beg:end]) / 2)
    if len(detect) > 0:
        for i in detect:
            if Id_min <= int(i) <= Id_max:
                ax2.axvline(x = int(i), color = 'blue')
                ax2.text(int(i)+0.2,middle,'detect',rotation=90)
    if len(redetect) > 0:
        for i in redetect:
            if Id_min <= int(i) <= Id_max:
                ax2.axvline(x = int(i), color = 'blue', linestyle='dashed')
                ax2.text(int(i)+0.2,middle,'redetect',rotation=90)
    if len(TiT) > 0:
        for i in TiT:
            if Id_min <= int(i) <= Id_max:
                ax2.axvline(x = int(i), color = 'red')
                ax2.text(int(i)+5,middle + 10,'TiT',rotation=90)
    
    parent_folder = str(Path(json_file).parent.absolute())
    #path_to_save = parent_folder + "/" + "plot_result_matplotlib.jpg"
    path_to_save = target + '.jpg'
    fig.savefig(path_to_save)
    print("Image save in:", path_to_save)
    plt.show()
    
    
def plot_result_plotly(rs_file, json_file):
    columns1 = ['ID', 'mse', 'height']
    df1 = pd.read_csv(rs_file, sep = ' ', names = columns1, dtype = {'ID' : int, 'mse' : float, 'height': float}, keep_default_na = False)
    ID = []
    MSE = []
    H = []
    for i in range(0, len(df1)):
        id_image = df1['ID'][i]
        ID.append(id_image)
        H.append(df1['height'][i])
        MSE.append(df1['mse'][i])
    
    try:
        import plotly.graph_objects as go
        from plotly.subplots import make_subplots
    except:
        print("Import error")
        return
    
    with open(json_file, "r") as json_data:
        state = json.load(json_data)
    detect = state['dic_detect']
    redetect = state['dic_redetect']
    TiT = state["dic_TiT"]

    beg = 0
    # end = 150
    end = len(ID)
    fig = make_subplots(specs=[[{"secondary_y": True}]])

    fig.add_trace(
        go.Scatter(x=ID[beg:end], y=MSE[beg:end], name="Euclidean Dist(pixel)", mode='lines', line=dict(color="black")),
        secondary_y=False,)

    fig.add_trace(
        go.Scatter(x=ID[beg:end], y=H[beg:end], name="Height(m)", mode='lines', line=dict(color="yellow")),
        secondary_y=True,)

    fig.update_layout(
        title_text="Error bbox tracking-detect"
    )


    
    fig.update_xaxes(title_text="ID")
    fig.update_yaxes(title_text="ED", secondary_y=False)
    fig.update_yaxes(title_text="height", secondary_y=True)
    Id_max = max(ID[beg:end])
    Id_min = min(ID[beg:end])
    
    if len(detect) > 0:
        for i in detect:
            if Id_min <= int(i) <= Id_max:
                fig.add_vline(x=int(i), line_width=3, line_dash="dash", line_color="yellow", label=dict(
                                text="detect",
                                textposition="top left",
                                font=dict(size=15, family="Times New Roman"),
                            ))
    if len(redetect) > 0:
        for i in redetect:
            if Id_min <= int(i) <= Id_max:
                fig.add_vline(x=int(i), line_width=3, line_dash="dash", line_color="blue", label=dict(
                                    text="redetect",
                                    textposition="top left",
                                    font=dict(size=15, family="Times New Roman"),
                                ))
    if len(TiT) > 0:
        for i in TiT:
            if Id_min <= int(i) <= Id_max:
                fig.add_vline(x=int(i), line_width=3, line_dash="dash", line_color="green", label=dict(
                                text="TiT",
                                textposition="top left",
                                font=dict(size=15, family="Times New Roman"),
                            ))

    parent_folder = str(Path(json_file).parent.absolute())
    path_to_save = parent_folder + "/" + "plot_result_plotly.jpg"
    fig.write_image(path_to_save)
    fig.show()



# result_file='/home/pc1/works/HungNV/ball_video/bia_ll/test_case/try21/bia_tt_00000065_sb916_FT1_12_1_clip4_cp_error/results.csv'
# bandicam_log='/home/pc1/works/HungNV/ball_video/bia_ll/test_case/try21/VT_bia_tt_00000065_sb916_FT1_12_1.csv'
# # image_id_column = ' ImageId'
# # image_id_column = 'ImageId'
# # height_column_name=' UavAMSL'
# image_id_column = 'ImageId'
# height_column_name=' Alt'

# # height_column_name='Roll'
# rs = save_result(result_file=result_file, bandicam_log=bandicam_log, image_id_column=image_id_column, height_column_name=height_column_name)



#rs="/mnt/data/tuananh/test_performance_of_tracking/data/bia_ll_00000035_tb_t26_24_11_clip2_cp_error/results2.txt"
# json_file="/home/pc1/works/HungNV/ball_video/bia_ll/test_case/try21/bia_tt_00000065_sb916_FT1_12_1.json"
# plot_result_matplotlib(rs, json_file)


# In[ ]:


# json_file="/mnt/data/tuananh/test_performance_of_tracking/data/bia_ll_00000035_tb_t26_24_11_clip2.json"
# plot_result_plotly(rs, json_file)

if __name__ == "__main__":
        
    parser = argparse.ArgumentParser("draw")
    image_id_column = 'ImageId'
    height_column_name = ' Alt'
    parser.add_argument('--csv', required=True, type=str) #tracking_cp_error/results.csv
    parser.add_argument('--blog', required=True, type=str) #bandicam log
    parser.add_argument('--json', required=True, type=str) #json file
    parser.add_argument('--tg', required=True, type=str) #target file name (no extension)
    args = parser.parse_args()
    result_file = args.csv
    bandicam_log = args.blog
    target = args.tg
    json_file = args.json


    rs = save_result(result_file, bandicam_log, image_id_column, height_column_name)
    plot_result_matplotlib(rs, json_file, target)

# python 5_draw.py --csv=/mnt/data/hungnv152/data/UAV_2X/tank_video/1/videorecord/new/_tracking_cp_error/results.csv --blog=/mnt/data/hungnv152/data/UAV_2X/tank_video/1/videorecord/00000193.csv --json=/mnt/data/hungnv152/data/UAV_2X/tank_video/1/videorecord/new/tank_sb_yb_T05_00000193_13_01.json --tg=/mnt/data/hungnv152/data/UAV_2X/tank_video/1/videorecord/new/tank_sb_yb_T05_00000193_13_01_clip5
