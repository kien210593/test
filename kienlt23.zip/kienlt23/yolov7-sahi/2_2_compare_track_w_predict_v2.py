#!/usr/bin/env python
# coding: utf-8

import numpy as np
import pandas as pd
from PIL import Image
from glob import glob
import os
import cv2
from pathlib import Path
import random
import shutil
import argparse
from util import glob_images_all_suffixes, read_size, yolo2xyxy


def convert_box2yolo1(size, box): # (x_top, y_top, x_bot, y_bot)
    width = size[0]
    height = size[1]
    return (box[0]+box[2])/(2*width), (box[1]+box[3])/(2*height), (box[2]-box[0])/width, (box[3]-box[1])/height
def bbox_iou(box1, box2, x1y1x2y2= True):
    # Returns the IoU of box1 to box2. box1 is 4, box2 is nx4
    # box2 = box2.T

    # Get the coordinates of bounding boxes
    if x1y1x2y2:  # x1, y1, x2, y2 = box1
        b1_x1, b1_y1, b1_x2, b1_y2 = box1[0], box1[1], box1[2], box1[3]
        b2_x1, b2_y1, b2_x2, b2_y2 = box2[0], box2[1], box2[2], box2[3]
    else:  # transform from xywh to xyxy
        b1_x1, b1_x2 = box1[0] - box1[2] / 2, box1[0] + box1[2] / 2
        b1_y1, b1_y2 = box1[1] - box1[3] / 2, box1[1] + box1[3] / 2
        b2_x1, b2_x2 = box2[0] - box2[2] / 2, box2[0] + box2[2] / 2
        b2_y1, b2_y2 = box2[1] - box2[3] / 2, box2[1] + box2[3] / 2

    # Intersection area
    # inter = (torch.min(b1_x2, b2_x2) - torch.max(b1_x1, b2_x1)).clamp(0) * \
    #         (torch.min(b1_y2, b2_y2) - torch.max(b1_y1, b2_y1)).clamp(0)

    x1 = max(b1_x1, b2_x1)
    y1 = max(b1_y1, b2_y1)
    x2 = min(b1_x2, b2_x2)
    y2 = min(b1_y2, b2_y2)


    inter = max(0, x2-x1) * max(0,y2-y1)

    # inter = (min(b1_x2, b2_x2) - max(b1_x1, b2_x1)) * \
    #         (min(b1_y2, b2_y2) - max(b1_y1, b2_y1))

    # Union Area
    w1, h1 = b1_x2 - b1_x1, b1_y2 - b1_y1 
    w2, h2 = b2_x2 - b2_x1, b2_y2 - b2_y1 
    union = w1 * h1 + w2 * h2 - inter

    if union == 0:
        iou = 0
    else:
        iou = inter / union
    return iou

def find_related_columns(matrix, start_column_indices, visited_columns = None):
    # if visited_columns is None:
    #     visited_columns = set()

    stack = list(start_column_indices)
    related_columns = set(start_column_indices)

    while stack:
        cureent_column = stack.pop()

        # related_columns = set()
        for col_index, value in enumerate(matrix[:, cureent_column]):
            if value and col_index not in related_columns and col_index not in stack:
                stack.append(col_index)
                # visited_columns.add(col_index)
                related_columns.add(col_index)
            # related_columns.update(find_related_columns(matrix, col_index, visited_columns))
    return related_columns
def create_boolean_matrix(matrix, threshold):
    return matrix > threshold
def is_file_empty(file_path):
    return os.path.getsize(file_path) == 0


def compare_track_w_predict(img_folder, label_track_dir, label_pr_dir, img_sz):
    threshold = 0.000001
    # sz = [1920, 1080]
    sz = img_sz
    sz1 = [640,640]
    columns = ['class', 'x0', 'y0', 'dw', 'dh', 'score']

    # img_dir = sorted(glob(img_folder+'*.jpg'))
    img_dir = glob_images_all_suffixes(img_folder)
    print('Number of images:', len(img_dir))
    parent_folder = str(Path(img_folder).parent.absolute())
    type = '_for_detect' if '_for_detect' in label_track_dir else '_tracking'
    # name_new_folder = '_'.join(img_folder.split("/")[-1].split("_"))
    name_new_folder = '_'.join(img_folder.split("/")[-1].split("_")[:-2]) + type
    # print('name_new_folder:', name_new_folder)
    tar_dir = parent_folder + "/" + name_new_folder + '_new/'
    tar_dir_lb = parent_folder + "/" + name_new_folder + '_lb_org/'
    miss_dir = parent_folder + "/" + name_new_folder + '_miss/'
    print(tar_dir, '\n', tar_dir_lb)
    
    # tar_dir = parent_folder + "/" + name_new_folder + '_new/'
    # tar_dir_lb = parent_folder + "/" + name_new_folder + '_lb_org/'
    # miss_dir = parent_folder + "/" + name_new_folder + '_miss/'
    Path(tar_dir).mkdir(parents=True, exist_ok=True)
    Path(tar_dir_lb).mkdir(parents=True, exist_ok=True)
    Path(miss_dir).mkdir(parents=True, exist_ok=True)
    for (im_i, im) in enumerate(img_dir):
        # print(im)
        image = cv2.imread(im)
        name = im.split('/')[-1][:-4] #.split('.')[0]
        # print('name:', name)
        tmp_label_track = os.path.join(label_track_dir , name + '.txt')
        tmp_label_pr = os.path.join(label_pr_dir , name + '.txt')
        # print(tmp_label_track)
        flag0 = False
        if os.path.exists(tmp_label_track) and name!='classes' and os.path.exists(tmp_label_pr):
            # take box traking (only 1)
            df_track = pd.read_csv(tmp_label_track, header = None, names = columns, sep = ' ')
            boxt = [df_track['x0'][0], df_track['y0'][0], df_track['dw'][0], df_track['dh'][0]]
            boxt_xyxy = yolo2xyxy(sz, boxt)
            boxg1 = boxt
            boxg1_xyxy = boxt_xyxy
            # print('boxg1_xyxy:', boxg1_xyxy)
            
            if is_file_empty(tmp_label_pr):
                # if not detected save to missing, and using tracking box to gt
                file1= os.path.join(tar_dir_lb, name)+'.txt'
                shutil.copy2(tmp_label_track, file1)
                # print('miss:', tmp_label_track)
                # crop and save file by tracking box
                top_x = max(0, min(sz[0]-640,random.randint(max(0, boxg1_xyxy[0]-640), boxg1_xyxy[0])))
                bot_x = min(sz[0], top_x+ 640)
                top_y = max(0, min(sz[1]-640,random.randint(max(0, boxg1_xyxy[1]-640), boxg1_xyxy[1])))
                bot_y = min(sz[1], top_y+ 640)
                crop_box = [top_x, top_y, bot_x, bot_y]
                cropped_image = image[top_y:bot_y, top_x: bot_x]
                # print('crop_box:', crop_box)
                true_box_new = [boxg1_xyxy[0] - top_x, boxg1_xyxy[1] - top_y, boxg1_xyxy[2] - top_x, boxg1_xyxy[3] - top_y]
                # print('true_box_new:', true_box_new)
      
                true_box_new2 = convert_box2yolo1(sz1, true_box_new)
                
                file1= os.path.join(miss_dir, name)+'_miss_'+str(top_x)+'_'+str(top_y)+'.txt'
                cls = 1 
                lines = []
                with open(file1, 'w') as f:
                    lines.append(f"{cls} {' '.join(f'{x:.6f}' for x in true_box_new2)}\n")
                    f.writelines(lines)
                    # Save the cropped ROI
                # print(output_path)
                # target_output_path = os.path.join(miss_dir, name)+'_miss'+str(j)+'.jpg'
                target_output_path = os.path.join(miss_dir, name)+'_miss_'+str(top_x)+'_'+str(top_y)+'.jpg'
                cv2.imwrite(target_output_path, cropped_image)
                
            else:
                # if detected using box intersect with tracking box to ground truth
                df_pr = pd.read_csv(tmp_label_pr, header = None, names = columns, sep = ' ').reset_index(drop=True)
    
                box_array = np.zeros(len(df_pr))
    
                for j in range(0, len(df_pr)):
                    boxp = [df_pr['x0'][j], df_pr['y0'][j], df_pr['dw'][j], df_pr['dh'][j]] # box white target
                    boxp_xyxy = yolo2xyxy(sz, boxp)
                    box_array[j] = bbox_iou(boxt_xyxy, boxp_xyxy)
    
                    if box_array[j]> threshold:
                        cls = df_pr['class'][j]
                        if cls == 1:
                            boxg1 = boxp
                            boxg1_xyxy = boxp_xyxy
                        if cls == 0:
                            flag0 = True
                            boxg0 = boxp
                            boxg0_xyxy = boxp_xyxy
                if flag0 == True:
                    delta = tuple(x-y for x,y in zip(boxg0_xyxy, boxg1_xyxy))
                # saving ground truth label for raw image
                file1= os.path.join(tar_dir_lb, name)+'.txt'
                cls =1
                lines = []
                with open(file1, 'a') as f:
                    lines.append(f"{cls} {' '.join(f'{x:.6f}' for x in boxg1)}\n")
                    f.writelines(lines)
    
                if flag0 == True:
                    cls = 0
                    lines = []
                    with open(file1, 'a') as f:
                        lines.append(f"{cls} {' '.join(f'{x:.6f}' for x in boxg0)}\n")
                        f.writelines(lines)
                        
                 
                for j in range(0, len(df_pr)):
                    boxp = [df_pr['x0'][j], df_pr['y0'][j], df_pr['dw'][j], df_pr['dh'][j]] # box white target
                    boxp_xyxy = yolo2xyxy(sz, boxp)
                    # box_array[j] = bbox_iou(boxt_xyxy, boxp_xyxy)
    
                    # if detected box not intersect with gt
                    if box_array[j]< threshold:
                        min_x = min(boxg1_xyxy[0], boxp_xyxy[0])
                        max_x = max(boxg1_xyxy[2], boxp_xyxy[2])
                        distance_x = abs(max_x-min_x)
    
                        min_y = min(boxg1_xyxy[1], boxp_xyxy[1])
                        max_y = max(boxg1_xyxy[3], boxp_xyxy[3])
                        distance_y = abs(max_y-min_y)
    
                        # print('distance_x:', distance_x)
                        # print('distance_y:', distance_y)
    
                        if distance_x <=640 and distance_y <=640:
                            
                            top_x = max(0, min(sz[0]-640,random.randint(max(0, boxg1_xyxy[0]-640), boxg1_xyxy[0])))
                            bot_x = min(sz[0], top_x+ 640)
                            top_y = max(0, min(sz[1]-640,random.randint(max(0, boxg1_xyxy[1]-640), boxg1_xyxy[1])))
                            bot_y = min(sz[1], top_y+ 640)
                            crop_box = [top_x, top_y, bot_x, bot_y]
                            cropped_image = image[top_y:bot_y, top_x: bot_x]
    
                            # if flag_1:
                            box_true1 = boxg1_xyxy
                            true_box_new1 = [box_true1[0] - top_x, box_true1[1] - top_y, box_true1[2] - top_x, box_true1[3] - top_y]
                            # print('true_box_new1:', true_box_new1)
                            true_box_new11 = convert_box2yolo1(sz1, true_box_new1)
                            file1= os.path.join(tar_dir, name)+'_crop_paste'+str(j)+'_'+str(top_x)+'_'+str(top_y)+'.txt'
                            cls = 1 
                            lines = []
                            with open(file1, 'a') as f:
                                lines.append(f"{cls} {' '.join(f'{x:.6f}' for x in true_box_new11)}\n")
                                f.writelines(lines)
    
                            if flag0:
                                box_true0 = boxg0_xyxy
                                true_box_new0 = [box_true0[0] - top_x, box_true0[1] - top_y, box_true0[2] - top_x, box_true0[3] - top_y]
                                true_box_new00 = convert_box2yolo1(sz1, true_box_new0)
                                file1= os.path.join(tar_dir, name)+'_crop_paste'+str(j)+'_'+str(top_x)+'_'+str(top_y)+'.txt'
                                cls = 0 
                                lines = []
                                with open(file1, 'a') as f:
                                    lines.append(f"{cls} {' '.join(f'{x:.6f}' for x in true_box_new00)}\n")
                                    f.writelines(lines)                            
    
                            target_output_path = os.path.join(tar_dir, name)+'_crop_paste'+str(j)+'_'+str(top_x)+'_'+str(top_y)+'.jpg'
                            cv2.imwrite(target_output_path, cropped_image)
                            # print(target_output_path)
                            # print(cropped_image.shape)
                        else:
                            # print(1)
                            temp_x1 = boxp_xyxy[2]-640
                            temp_x2 = boxp_xyxy[0]+640
                            # print('temp_x1:', temp_x1)
                            # print('temp_x2:', temp_x2)
                            
                            if temp_x1 >0 and temp_x2 < sz[0]:
                                top_x = random.randint(temp_x1, boxp_xyxy[0])
                                # bot_x = top_x + 640
                            elif temp_x1 <=0:
                                top_x = 0
                            else:
                                top_x = max(0, sz[0] - 640)
                            bot_x = top_x+ 640
    
                            temp_y1 = boxp_xyxy[3]-640
                            temp_y2 = boxp_xyxy[1]+640
                            if temp_y1 >0 and temp_y2 < sz[1]:
                                top_y = random.randint(temp_y1, boxp_xyxy[1])
                                # bot_x = top_x + 640
                            elif temp_y1 <=0:
                                top_y = 0
                            else:
                                top_y = max(0, sz[1] - 640)
                            bot_y = top_y+ 640
                            crop_box = [top_x, top_y, bot_x, bot_y]
                            image = cv2.imread(im)
                            cropped_image = image[top_y:bot_y, top_x: bot_x]
                            # print("cropped_image:", cropped_image.shape)
                            false_box_new = [boxp_xyxy[0] - top_x, boxp_xyxy[1] - top_y, boxp_xyxy[2] - top_x, boxp_xyxy[3] - top_y]
         
                            w = boxg1_xyxy[2]- boxg1_xyxy[0]
                            h = boxg1_xyxy[3]- boxg1_xyxy[1]
    
                            box_crop = [max(0,boxg1_xyxy[0]-int(w*0.2)), max(0,boxg1_xyxy[1]-int(h*0.2)), boxg1_xyxy[2]+int(w*0.2), boxg1_xyxy[3]+int(h*0.2)]
                            # print('box_crop:', box_crop)
                            # w1 = box1_xyxy[2]- box1_xyxy[0]
                            # h1 = box1_xyxy[3]- box1_xyxy[1]
                            # print(w1)
                            # print(h1)
                            # Crop the selected ROI
                            cropped_roi = image[box_crop[1]:box_crop[3], box_crop[0]: box_crop[2]]
                            # print('cropped_roi:', cropped_roi.shape)
                            # small_height, small_width = box_crop[3]- box_crop[1], box_crop[2]- box_crop[0]
                            small_height = cropped_roi.shape[0]
                            small_width = cropped_roi.shape[1]
                            # print('small_width:', small_width)
                            # print('small_height:', small_height)
                            target_image = cropped_image
                            # x = random.randint(0, 640-small_width)
                            # y = random.randint(0, 640-small_height)
                            if small_width<320 and small_height<320:
                                x = random.randint(small_width, 640-small_width)
                                y = random.randint(small_height, 640-small_height)
                            else:
                                # x = random.randint(min(small_width, 640-small_width), max(small_width, 640-small_width))
                                # y = random.randint(min(small_height, 640-small_height), max(small_height, 640-small_height))
                                x = random.randint(int(small_width/2)+1, 640-int(small_width/2)-1)
                                y = random.randint(int(small_height/2)+1, 640-int(small_height/2)-1)
                            # print('x:', x)
                            # print('y:', y)
                            if small_height%2 == 0 and small_width%2 == 0:
                                temp_h = int(small_height/2)
                                temp_w = int(small_width/2)
                                target_image[y-temp_h:y+temp_h, x-temp_w:x+temp_w] = cropped_roi
                                true_box_new = [x-temp_w+int(w*0.2), y-temp_h+int(h*0.2), x-temp_w+int(w*0.2)+w, y-temp_h+int(h*0.2)+h]
                            elif small_height%2 == 1 and small_width%2 == 0:
                                temp_h = int(small_height/2)
                                temp_w = int(small_width/2)
                                target_image[y-temp_h-1:y+temp_h, x-temp_w:x+temp_w] = cropped_roi
                                true_box_new = [x-temp_w+int(w*0.2), y-temp_h-1+int(h*0.2), x-temp_w+int(w*0.2)+w, y-temp_h-1+int(h*0.2)+h]
        
                            elif small_height%2 == 0 and small_width%2 == 1:
                                temp_h = int(small_height/2)
                                temp_w = int(small_width/2)
                                # print('temp_h:', temp_h)
                                # print('temp_w:', temp_w)
                                target_image[y-temp_h:y+temp_h, x-temp_w-1:x+temp_w] = cropped_roi
                                true_box_new = [x-temp_w+int(w*0.2)-1, y-temp_h-1+int(h*0.2), x-temp_w+int(w*0.2)+w-1, y-temp_h-1+int(h*0.2)+h]
                            else:
                                temp_h = int(small_height/2)
                                temp_w = int(small_width/2)
                                # print(small_width)
                                # print(small_height)
                                target_image[y-temp_h-1:y+temp_h, x-temp_w-1:x+temp_w] = cropped_roi
                                true_box_new = [x-temp_w+int(w*0.2)-1, y-temp_h-1+int(h*0.2)-1, x-temp_w+int(w*0.2)+w-1, y-temp_h-1+int(h*0.2)-1+h]
                            # print('true_box_new:', true_box_new)
                            
                            true_box_new1 = convert_box2yolo1(sz1, true_box_new)
    
                            # file1= os.path.join(tar_dir, name)+'_crop_paste'+str(j)+'.txt'
                            file1= os.path.join(tar_dir, name)+'_crop_paste'+str(j)+'_'+str(top_x)+'_'+str(top_y)+'.txt'
                            cls = 1 
                            lines = []
                            with open(file1, 'a') as f:
                                lines.append(f"{cls} {' '.join(f'{x:.6f}' for x in true_box_new1)}\n")
                                f.writelines(lines)
    
                            if flag0:
                                true_box_new0 = tuple(x+y for x, y in zip(true_box_new, delta))
                                true_box_new00 = convert_box2yolo1(sz1, true_box_new0)
                                cls = 0
                                lines = []
                                with open(file1, 'a') as f:
                                    lines.append(f"{cls} {' '.join(f'{x:.6f}' for x in true_box_new00)}\n")
                                    f.writelines(lines)
    
                            target_output_path = os.path.join(tar_dir, name)+'_crop_paste'+str(j)+'_'+str(top_x)+'_'+str(top_y)+'.jpg'
                            cv2.imwrite(target_output_path, target_image)
                            # print(target_output_path)
                            # print(target_image.shape)
                            # print('----------')



# img_folder = '/home/pc1/works/HungNV/tank/9/tank_sb_916_Txx_00000009_07_03_clip4/'
# # label_track_dir = img_folder
# label_track_dir = '/home/pc1/works/HungNV/tank/9/tank_sb_916_Txx_00000009_07_03_clip4_tracking_lb/'
# label_pr_dir = '/home/pc1/works/HungNV/tank/9/tank_sb_916_Txx_00000009_07_03_clip4_tracking_im_predict/label_predict/label_no_score/'
# compare_track_w_predict(img_folder, label_track_dir, label_pr_dir)


if __name__ == "__main__":
        
    parser = argparse.ArgumentParser("compare_track_w_predict")
    parser.add_argument('--ilog', required=True, type=str)
    parser.add_argument('--ltlog', required=True, type=str)
    parser.add_argument('--lplog', required=True, type=str)
    parser.add_argument('--imgsz', default = (1920,1080), nargs='+', type = int)
    
    args = parser.parse_args()
    
    img_folder = args.ilog
    label_track_dir = args.ltlog
    label_pr_dir = args.lplog
    # img_size = [int(i) for i in args.imgsz.split(",")]
    img_size = tuple(args.imgsz)
    # img_folder = "/home/temp_data/199_29_07_IR/bia_IR_sb916_00000199_29_07_clip1_tracking_im"
    # label_track_dir = "/home/temp_data/199_29_07_IR/bia_IR_sb916_00000199_29_07_clip1_tracking_lb"
    # label_pr_dir = "/home/temp_data/199_29_07_IR/bia_IR_sb916_00000199_29_07_clip1_tracking_im_predict/label_predict/label_no_score"     
    compare_track_w_predict(img_folder, label_track_dir, label_pr_dir, img_size)





