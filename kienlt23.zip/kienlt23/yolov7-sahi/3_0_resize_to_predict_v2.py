#!/usr/bin/env python
# coding: utf-8


import numpy as np
import pandas as pd
from PIL import Image
from glob import glob
import os
import cv2
from pathlib import Path
import random
from tqdm import tqdm
import argparse
from util import yolo2xyxy, read_size



def convert_box2yolo1(size, box): # (x_top, y_top, x_bot, y_bot)
    width = size[0]
    height = size[1]
    return (box[0]+box[2])/(2*width), (box[1]+box[3])/(2*height), (box[2]-box[0])/width, (box[3]-box[1])/height
def is_file_empty(file_path):
    return os.path.getsize(file_path) == 0


def resize_im2pred(folder_track_im, folder_track_lb, imgsz):
    img_dir = sorted(glob(folder_track_im + '/*.jpg'))
    parent_folder = str(Path(folder_track_im).parent.absolute())
    # name_new_folder = '_'.join(folder_track_im.split("/")[-1].split("_")[:-2])
    # type = '_for_detect' if '_for_detect' in folder_track_lb else '_tracking'
    name_new_folder = '_'.join(folder_track_im.split("/")[-1].split("_")) #+ type

    # 1/0
    # name_new_folder = '_'.join(folder_track_im.split("/"))[-1]
    tar_dir = parent_folder + "/" + name_new_folder + '_crop_rs/'
    Path(tar_dir).mkdir(parents=True, exist_ok=True)
    columns = ['class', 'x0', 'y0', 'dw', 'dh', 'score']
    
    threshold = 0.000001
    sz1 = [640, 640]
    # threshold_length = 80
    
    for (im_i, im) in enumerate(tqdm(img_dir, "resize:")):
        image = cv2.imread(im)
        name = im.split('/')[-1].split('.')[0]
        tmp_label_org = folder_track_lb + "/" + name + '.txt'
        # print(tmp_label_org)
        #curr_frame = cv2.imread(im)
        sz = read_size(im)
        # print(is_file_empty(tmp_label_org))
        if os.path.exists(tmp_label_org) and name!='classes' and is_file_empty(tmp_label_org)!=True:
            df = pd.read_csv(tmp_label_org, header = None, names = columns, sep = ' ')
            if len(df):
                box0 = [df['x0'][0], df['y0'][0], df['dw'][0], df['dh'][0]] # box white target
                box0_xyxy = yolo2xyxy(sz, box0)
                # print(box0_xyxy)
                size_box = [box0_xyxy[2]-box0_xyxy[0], box0_xyxy[3]-box0_xyxy[1]]
                temp_max_length = max(size_box)
                # print('temp_max_length:', temp_max_length)
    
                if df['class'][0] == 1:
                    # if temp_max_length<threshold_length:
                    temp_x1 = box0_xyxy[2]-320
                    temp_x2 = box0_xyxy[0]+320
            
                            
                    if temp_x1 >0 and temp_x2 < imgsz[0]:
                        top_x = random.randint(min(temp_x1, box0_xyxy[0]), max(temp_x1, box0_xyxy[0]))
                    elif temp_x1 <=0:
                        top_x = 0
                    else:
                        top_x = imgsz[0] -320
                    bot_x = top_x+ 320
                    
                    
                    temp_y1 = box0_xyxy[3]-320
                    temp_y2 = box0_xyxy[1]+320
                    if temp_y1 >0 and temp_y2 < imgsz[1]:
                        # print('temp_y1:', temp_y1)
                        # print('temp_y2:', temp_y2)
                        # print(box0_xyxy[1])
                        top_y = random.randint(min(temp_y1, box0_xyxy[1]), max(temp_y1, box0_xyxy[1]))
                    elif temp_y1 <=0:
                        top_y = 0
                    else:
                        top_y = imgsz[1] - 320
                    bot_y = top_y+ 320
                    crop_box = [top_x, top_y, bot_x, bot_y]
                    cropped_image = image[top_y:bot_y, top_x: bot_x]
                    
                    true_box_new = [box0_xyxy[0] - top_x, box0_xyxy[1] - top_y, box0_xyxy[2] - top_x, box0_xyxy[3] - top_y]
                    true_box_new_rs = [true_box_new[0]*2, true_box_new[1]*2, true_box_new[2]*2, true_box_new[3]*2]
                    true_box_new_rs1 = convert_box2yolo1(sz1, true_box_new_rs)
                    rs_cropped_image = cv2.resize(cropped_image, (640, 640))
                    
                    target_output_path = os.path.join(tar_dir, name)+'_crop_paste_rs'+'_'+str(top_x)+'_'+str(top_y)+'.jpg'
                    
                    # print(target_output_path)
                    file1= target_output_path[:-4]+'.txt'
                    cls = 1 
                    lines = []
    
                    with open(file1, 'w') as f:
                        lines.append(f"{cls} {' '.join(f'{x:.6f}' for x in true_box_new_rs1)}\n")
                        f.writelines(lines)
                    cv2.imwrite(target_output_path, rs_cropped_image)


def resize_poly(folder_track_im, folder_track_lb, imgsz):
    img_dir = sorted(glob(folder_track_im + '/*.jpg'))
    parent_folder = str(Path(folder_track_im).parent.absolute())
    # name_new_folder = '_'.join(folder_track_im.split("/")[-1].split("_")[:-2])
    # type = '_for_detect' if '_for_detect' in folder_track_lb else '_tracking'
    name_new_folder = '_'.join(folder_track_im.split("/")[-1].split("_")) #+ type

    # 1/0
    # name_new_folder = '_'.join(folder_track_im.split("/"))[-1]
    tar_dir = parent_folder + "/" + name_new_folder + '_crop_rs/'
    Path(tar_dir).mkdir(parents=True, exist_ok=True)
    columns = ['class', 'x0', 'y0', 'x1', 'y1', 'x2', 'y2', 'x3','y3', 'score']
    
    for (im_i, im) in enumerate(tqdm(img_dir, "resize:")):
        image = cv2.imread(im)
        name = im.split('/')[-1].split('.')[0]
        tmp_label_org = folder_track_lb + "/" + name + '.txt'
        # print(tmp_label_org)
        
        sz = read_size(im)
        if os.path.exists(tmp_label_org) and name!='classes' and is_file_empty(tmp_label_org)!=True:
            df = pd.read_csv(tmp_label_org, header = None, names = columns, sep = ' ')
            box0 = [df['x0'][0], df['y0'][0], df['x1'][0], df['y1'][0], df['x2'][0], df['y2'][0], df['x3'][0], df['y3'][0]] 
            box0 = yolo2xyxy(sz, box0)
            box = np.array([[box0[0], box0[1]],
                            [box0[2], box0[3]],
                            [box0[4], box0[5]],
                            [box0[6], box0[7]]])
            if len(df):
                outter_box = [ min(box[:, 0]), min(box[:, 1]), max(box[:, 0]), max(box[:, 1])] 
                x_range = (int(max(0, outter_box[2] - 320)), min(int(outter_box[0]), sz[0] - 320) ) 
                y_range = (int(max(0, outter_box[3] - 320)), min(int(outter_box[1]), sz[1] - 320) )

                top_left = (random.randint(*x_range), random.randint(*y_range)) 
                
                top_x, top_y, bot_x, bot_y = top_left[0], top_left[1], top_left[0] + 320, top_left[1] + 320
                cropped_image = image[top_y:bot_y, top_x: bot_x]
                if cropped_image.shape[0] != 320 or cropped_image.shape[1] != 320:
                    print("Error in cropping, got cropped shape: ", cropped_image.shape, "top left: ", top_left) 
                    print("Outter box:", outter_box)
                    print("Crop region: ", top_x, top_y, bot_x, bot_y)
                    
                rs_cropped_image = cv2.resize(cropped_image, (640, 640))
                
                # box_rs = box*2
                # box_rs[:, 0] /= sz[0]*2
                # box_rs[:, 1] /= sz[1]*2
                box_rs = box.copy()
                box_rs[:, 0] = box_rs[:, 0] - top_x
                box_rs[:, 1] = box_rs[:, 1] - top_y
                box_rs *= 2
                box_rs = box_rs.reshape(-1).tolist()
                
                target_output_path = os.path.join(tar_dir, name)+'_crop_paste_rs'+'_'+str(top_x)+'_'+str(top_y)+'.jpg'
                file1= target_output_path[:-4] + '.txt'
                cls = 1 
                lines = []
                with open(file1, 'w') as f:
                    lines.append(f"{cls} {' '.join(f'{x:.6f}' for x in box_rs)}\n")
                    f.writelines(lines)
                cv2.imwrite(target_output_path, rs_cropped_image)
                
if __name__ == "__main__":
    parser = argparse.ArgumentParser("resize_2_predict")
    parser.add_argument('--ilog', required=True, type=str)
    parser.add_argument('--llog', required=True, type=str)
    parser.add_argument('--imgsz', default = (1920,1080), nargs='+', type = int)
    parser.add_argument('--type', required=True, type=str)
    args = parser.parse_args()
    
    folder_track_im = args.ilog
    folder_track_lb = args.llog
    # imgsz = [int(i) for i in args.imgsz.split(",")]
    imgsz = tuple(args.imgsz)
    if args.type == 'hbb':
        resize_im2pred(folder_track_im, folder_track_lb, imgsz)
    else:
        resize_poly(folder_track_im, folder_track_lb, imgsz)




