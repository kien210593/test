import torch
import torch.nn as nn
import torch.nn.functional as F

class SeparableConv2d_BNReLU(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=1, stride=1, padding=0, dilation=1, bias=False):
        super(SeparableConv2d_BNReLU, self).__init__()

        self.conv1 = nn.Conv2d(in_channels, in_channels, kernel_size, stride, padding, dilation, groups=in_channels,
                               bias=bias)
        self.pointwise = nn.Conv2d(in_channels, out_channels, 1, 1, 0, 1, 1, bias=bias)
        self.BN = nn.BatchNorm2d(out_channels)
        self.ReLU = nn.ReLU()

    def forward(self, x):
        x = self.conv1(x)
        x = self.pointwise(x)
        x = self.ReLU(self.BN(x))
        return x

class head_subnet(nn.Module):
    def __init__(self, path_head_cls, path_head_reg, num_channel_cls = 192 , num_channel_reg = 128 , inchannels = 64, kernel_list=[3, 5, 0], towernum=8,
                      linear_reg=False):
        super(head_subnet, self).__init__()
        tower_cls_list = nn.ModuleList()
        tower_reg_list = nn.ModuleList()
        # add operations
        tower_cls = nn.Sequential(
            *get_towers(tower_cls_list, path_head_cls, inchannels, num_channel_cls, towernum=towernum,
                        kernel_list=kernel_list))
        tower_reg = nn.Sequential(
            *get_towers(tower_reg_list, path_head_reg, inchannels, num_channel_reg, towernum=towernum,
                        kernel_list=kernel_list))
        # add prediction head
        cls_pred = cls_pred_head(inchannels=num_channel_cls)
        reg_pred = reg_pred_head(inchannels=num_channel_reg, linear_reg=linear_reg)

        module_dict = {'cls_tower': tower_cls, 'reg_tower': tower_reg, 'cls_pred': cls_pred, 'reg_pred': reg_pred}

        self.cls_tower = module_dict['cls_tower']
        self.reg_tower = module_dict['reg_tower']
        self.cls_perd = module_dict['cls_pred']
        self.reg_pred = module_dict['reg_pred']

    def forward(self, feat_z, feat_x):
        
        # cls
        cls_feat = self.cls_tower(feat_z)
        cls = self.cls_perd(cls_feat)
        # reg
        reg_feat = self.reg_tower(feat_x)
        loc = self.reg_pred(reg_feat)
        return cls, loc


def get_towers(module_list: torch.nn.ModuleList, path_head, inchannels, outchannels, towernum=8, kernel_list=[3, 5, 0]):
    num_choice_kernel = len(kernel_list)
    for tower_idx in range(towernum):
        block_idx = path_head[tower_idx]
        kernel_sz = kernel_list[block_idx]
        if tower_idx == 0:
            assert (kernel_sz != 0)
            padding = (kernel_sz - 1) // 2
            module_list.append(SeparableConv2d_BNReLU(inchannels, outchannels, kernel_size=kernel_sz,
                                                      stride=1, padding=padding, dilation=1))
        else:
            if block_idx != num_choice_kernel - 1:  # else skip
                assert (kernel_sz != 0)
                padding = (kernel_sz - 1) // 2
                module_list.append(SeparableConv2d_BNReLU(outchannels, outchannels, kernel_size=kernel_sz,
                                                          stride=1, padding=padding, dilation=1))
    return module_list

class cls_pred_head(nn.Module):
    def __init__(self, inchannels=256):
        super(cls_pred_head, self).__init__()
        self.cls_pred = nn.Conv2d(inchannels, 2, kernel_size=3, stride=1, padding=1)

    def forward(self, x):
        """mode should be in ['all', 'cls', 'reg']"""
        x = 0.1 * self.cls_pred(x)
        return x


class reg_pred_head(nn.Module):
    def __init__(self, inchannels=256, linear_reg=False, stride=16):
        super(reg_pred_head, self).__init__()
        self.linear_reg = linear_reg
        self.stride = stride
        # reg head
        self.bbox_pred = nn.Conv2d(inchannels, 4, kernel_size=3, stride=1, padding=1)
        # adjust scale
        if not self.linear_reg:
            self.adjust = nn.Parameter(0.1 * torch.ones(1))
            self.bias = nn.Parameter(torch.Tensor(1.0 * torch.ones(1, 4, 1, 1)))

    def forward(self, x):
        if self.linear_reg:
            x = nn.functional.relu(self.bbox_pred(x)) * self.stride
        else:
            x = self.adjust * self.bbox_pred(x) + self.bias
            x = torch.exp(x)
        return x

def head_ef(path_head_cls, path_head_reg, num_channel_cls = 192 , num_channel_reg = 128 , inchannels = 64, kernel_list=[3, 5, 0], towernum=8,
                      linear_reg=False):
    
    tower_cls_list = nn.ModuleList()
    tower_reg_list = nn.ModuleList()
    # add operations
    tower_cls = nn.Sequential(
        *get_towers(tower_cls_list, path_head_cls, inchannels, num_channel_cls, towernum=towernum,
                    kernel_list=kernel_list))
    tower_reg = nn.Sequential(
        *get_towers(tower_reg_list, path_head_reg, inchannels, num_channel_reg, towernum=towernum,
                    kernel_list=kernel_list))
    # add prediction head
    cls_pred = cls_pred_head(inchannels=num_channel_cls)
    reg_pred = reg_pred_head(inchannels=num_channel_reg, linear_reg=linear_reg)

    module_dict = {'cls_tower': tower_cls, 'reg_tower': tower_reg, 'cls_pred': cls_pred, 'reg_pred': reg_pred}
    
    return head_subnet(module_dict)

