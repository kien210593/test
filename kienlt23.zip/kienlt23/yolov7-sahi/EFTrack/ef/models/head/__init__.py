from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from ef.models.head.head import head_subnet


EFS = {
        'head_ef': head_subnet
       }


def get_ef_head(name, **kwargs):
    return EFS[name](**kwargs)

