from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import torch
import torch.nn as nn
import torch.nn.functional as F

from ef.core.xcorr import xcorr_fast, xcorr_depthwise, xcorr_pixelwise

class CAM(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(CAM, self).__init__()
        self.linear_max = nn.Sequential(
            nn.Linear(in_features=in_channels, out_features=out_channels, bias=True),
            nn.ReLU(inplace=True),
            nn.Linear(in_features=out_channels, out_features=in_channels, bias=True))
        self.linear_avg = nn.Sequential(
            nn.Linear(in_features=in_channels, out_features=out_channels, bias=True),
            nn.ReLU(inplace=True),
            nn.Linear(in_features=out_channels, out_features=in_channels, bias=True))

    def forward(self, x):
        max = F.adaptive_max_pool2d(x, output_size=1)
        avg = F.adaptive_avg_pool2d(x, output_size=1)
        b, c, _, _ = x.size()
        linear_max = self.linear_max(max.view(b,c)).view(b, c, 1, 1)
        linear_avg = self.linear_avg(avg.view(b,c)).view(b, c, 1, 1)
        output = linear_max + linear_avg
        output = F.sigmoid(output) * x
        return output
    
class SepConv(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, padding):
        super(SepConv, self).__init__()
        self.SepConv = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size=kernel_size, padding = padding, bias = False),
            nn.Conv2d(in_channels, out_channels, kernel_size=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU6(inplace=True),
            )

    def forward(self, x):
        return self.SepConv(x)

class EF(nn.Module):
    def __init__(self):
        super(EF, self).__init__()

    def forward(self, z_f, x_f):
        raise NotImplementedError

class DepthwiseCls(nn.Module):
    def __init__(self, in_channels, hidden, hidden_cls, out_channels):
        super(DepthwiseCls, self).__init__()

        self.cam = CAM(in_channels, hidden)
        
        self.sepconv = SepConv(hidden, hidden_cls, 5, 2)
        
        self.sepconv3 = SepConv(hidden_cls, hidden_cls, 3, 1)
        
        self.sepconv5 = SepConv(hidden_cls, hidden_cls, 5, 2)
            
        self.head = nn.Sequential(
            nn.Conv2d(hidden_cls, out_channels, kernel_size=1)
            )

    def forward(self, kernel, search):
        if kernel.size(3) < 10:
            l = 2
            r = l + 4
            kernel = kernel[:, :, l:r, l:r]
        
        feature = xcorr_pixelwise(search, kernel)
        # feature = xcorr_depthwise(search, kernel)
        feature = self.cam(feature)
        feature = self.sepconv(feature)
        feature = self.sepconv5(feature)
        feature = self.sepconv3(feature)
        feature = self.sepconv3(feature)
        out = self.head(feature)
        return out
    
class DepthwiseReg(nn.Module):
    def __init__(self, in_channels, hidden, hidden_reg, out_channels):
        super(DepthwiseReg, self).__init__()
    
        self.cam = CAM(in_channels, hidden)
        
        self.sepconv = SepConv(hidden, hidden_reg, 5, 2)
        
        self.sepconv3 = SepConv(hidden_reg, hidden_reg, 3, 1)
        
        self.sepconv5 = SepConv(hidden_reg, hidden_reg, 5, 2)
            
        self.head = nn.Sequential(
            nn.Conv2d(hidden_reg, out_channels, kernel_size=1)
            )

    def forward(self, kernel, search):
        if kernel.size(3) < 10:
            l = 2
            r = l + 4
            kernel = kernel[:, :, l:r, l:r]
        
        # feature = xcorr_depthwise(search, kernel)
        feature = xcorr_pixelwise(search, kernel)
        feature = self.cam(feature)
        feature = self.sepconv(feature)
        feature = self.sepconv3(feature)
        feature = self.sepconv3(feature)
        feature = self.sepconv5(feature)
        feature = self.sepconv5(feature)
        out = self.head(feature)
        return out


class DepthwiseEF(EF):
    def __init__(self, in_channels = 112, hidden = 64, hidden_cls = 192, hidden_reg = 128, weighted=False):
        super(DepthwiseEF, self).__init__()
        self.cls = DepthwiseCls(in_channels, hidden, hidden_cls, 2)
        self.loc = DepthwiseReg(in_channels, hidden, hidden_reg, 4)

    def forward(self, z_f, x_f):
        cls = self.cls(z_f, x_f)
        loc = self.loc(z_f, x_f)
        return cls, loc


class MultiEF(EF):
    def __init__(self, in_channels, hidden, hidden_cls, hidden_reg, weighted=False):
        super(MultiEF, self).__init__()
        self.weighted = weighted
        self.add_module('box'+str(1), DepthwiseEF(in_channels, hidden, hidden_cls, hidden_reg))
        
        self.loc_scale = nn.Parameter(torch.ones(1))

    def forward(self, z_fs, x_fs):
        cls = []
        loc = []
        
        for idx, (z_f, x_f) in enumerate(zip(z_fs, x_fs), start=1):
            box = getattr(self, 'box'+str(idx))
            c, l = box(z_fs, x_fs)
            
            cls.append(c)
            loc.append(torch.exp(l*self.loc_scale[idx-1]))
        
        return cls[0], loc[0]
