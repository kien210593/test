# Copyright (c) SenseTime. All Rights Reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import torch
import torch.nn as nn
import torch.nn.functional as F

from ef.models.correlation.correlation import PW_Corr_adj

CORRELATION = {
         'PW_Corr_adj': PW_Corr_adj
        }

def get_correlation(name, **kwargs):
    return CORRELATION[name](**kwargs)
