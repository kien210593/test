# Copyright (c) SenseTime. All Rights Reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import torch.nn as nn
import torch.nn.functional as F
import torch

from ef.core.config import cfg
from ef.models.loss import select_cross_entropy_loss, select_iou_loss, rank_cls_loss, rank_loc_loss
from ef.models.backbone import get_backbone
from ef.models.head import get_ef_head
from ef.models.neck_xf import get_neck_xf
from ef.models.neck_zf import get_neck_zf
from ef.models.correlation import get_correlation
from ef.utils.point import Point
import numpy as np


class ModelBuilder(nn.Module):
    def __init__(self):
        super(ModelBuilder, self).__init__()

        # build backbone
        self.backbone = get_backbone(cfg.BACKBONE.TYPE,
                                     **cfg.BACKBONE.KWARGS)
        
        # build the neck layer
        self.neck_xf = get_neck_xf(cfg.ADJUST.TYPE,
                                **cfg.ADJUST.KWARGS) 
        
        # build the neck layer
        self.neck_zf = get_neck_zf(cfg.ADJUST.TYPE,
                                **cfg.ADJUST.KWARGS) 
        
        # Correlation
        self.correlation = get_correlation(cfg.CORRELATION.TYPE,
                                        **cfg.CORRELATION.KWARGS) 

        # build EF head
        if cfg.EF.EF:
            self.head = get_ef_head(cfg.EF.TYPE,
                                     **cfg.EF.KWARGS)
            
        self.rank_cls_loss=rank_cls_loss()
        self.rank_loc_loss=rank_loc_loss()
            
        # self.points = self.generate_points(cfg.POINT.STRIDE, cfg.TRAIN.OUTPUT_SIZE)
        
    def convert_bbox(self,delta, points):
        batch_size=delta.shape[0]
        delta = delta.view(batch_size, 4, -1) #delta shape before: [batch_size,4,25,25]
        points=points.view(2,-1) #points shape before: [2,25,25]
        output_boxes=torch.zeros(batch_size,4,delta.shape[2])
        for i in range (batch_size):
           output_boxes[i][0, :] = points[0,:] - delta[i][0, :]
           output_boxes[i][1, :] = points[1,:] - delta[i][1, :]
           output_boxes[i][2, :] = points[0,:] + delta[i][2, :]
           output_boxes[i][3, :] = points[1,:] + delta[i][3, :]
        return output_boxes
    
    # def iou(box1, box2):
    #     x1 = box1[0]
    #     y1 = box1[1]
    #     w1 = box1[2]
    #     h1 = box1[3]
        
    #     x2 = box2[0]
    #     y2 = box2[1]
    #     w2 = box2[2]
    #     h2 = box2[3]
        
    #     # Calculate the coordinates of the intersection rectangle
    #     intersection_x1 = max(x1, x2)
    #     intersection_y1 = max(y1, y2)
    #     intersection_x2 = min(x1 + w1, x2 + w2)
    #     intersection_y2 = min(y1 + h1, y2 + h2)

    #     # Calculate area of intersection rectangle
    #     intersection_area = max(0, intersection_x2 - intersection_x1) * max(0, intersection_y2 - intersection_y1)

    #     # Calculate area of union rectangle
    #     union_area = w1 * h1 + w2 * h2 - intersection_area

    #     # Calculate IOU
    #     iou = intersection_area / union_area
    #     return iou

    def template(self, z):
        zf = self.backbone(z)
        zf = self.neck_zf(zf)
        self.zf = zf

    def track(self, x):
        xf = self.backbone(x)
        xf = self.neck_xf(xf)
        feat_z, feat_x = self.correlation(self.zf, xf)
        cls, loc = self.head(feat_z, feat_x)
        return {
            'cls': cls,
            'loc': loc
            }
        
    # def forward(self, z):
    #     zf = self.backbone(z)
    #     return zf
    
    # def forward(self, z, x):
    #     zf = self.backbone(z)
    #     zf = self.neck_zf(zf)
    #     xf = self.backbone(x)
    #     xf = self.neck_xf(xf)
        
    #     print(xf.shape)
    #     print(zf.shape)
        
    #     feat_z, feat_x = self.correlation(zf, xf)
        
    #     # print("feat_z.shape : ", feat_z.shape)
    #     # print("feat_x.shape : ", feat_x.shape)
    
    #     cls, loc = self.head(feat_z, feat_x)
        
    #     # print("cls.shape : ", cls.shape)
    #     # print("loc.shape : ", loc.shape)
        
    #     return {
    #         'cls': cls,
    #         'loc': loc
    #         }

    def log_softmax(self, cls):
        if cfg.EF.EF:
            cls = cls.permute(0, 2, 3, 1).contiguous()
            cls = F.log_softmax(cls, dim=3)
        return cls

    def forward(self, data):
        """ only used in training
        """
        template = data['template'].cuda()
        search = data['search'].cuda()
        label_cls = data['label_cls'].cuda()
        label_loc = data['label_loc'].cuda()
        label_target = data['search_bbox'].cuda()

        # get feature
        zf = self.backbone(template)
        zf = self.neck_zf(zf)
        xf = self.backbone(search)
        xf = self.neck_xf(xf)
        
        feat_z, feat_x = self.correlation(zf, xf)
    
        cls, loc = self.head(feat_z, feat_x)

        # get loss
        self.points = Point(cfg.POINT.STRIDE, cfg.TRAIN.OUTPUT_SIZE, cfg.TRAIN.SEARCH_SIZE//2)
        points = self.points.points
        point_tensor=torch.from_numpy(points).cuda()
        pred_bboxes = self.convert_bbox(loc, point_tensor).cuda()

        # cls loss with cross entropy loss
        cls = self.log_softmax(cls)
        cls_loss = select_cross_entropy_loss(cls, label_cls)

        
        # loc loss with iou loss
        loc_loss = select_iou_loss(loc, label_loc, label_cls)

        outputs = {}
        # outputs['total_loss'] = cfg.TRAIN.CLS_WEIGHT * cls_loss + \
        #     cfg.TRAIN.LOC_WEIGHT * loc_loss
        # outputs['cls_loss'] = cls_loss
        # outputs['loc_loss'] = loc_loss

        # # outputs['CR_loss'] = cfg.TRAIN.RANK_CLS_WEIGHT*CR_loss
        # # outputs['IGR_loss_1'] =cfg.TRAIN.RANK_IGR_WEIGHT*IGR_loss_1
        # # outputs['IGR_loss_2'] = cfg.TRAIN.RANK_IGR_WEIGHT*IGR_loss_2

        if cfg.TRAIN.RBO:
            CR_loss=self.rank_cls_loss(cls,label_cls)
            IGR_loss_1,IGR_loss_2=self.rank_loc_loss(cls,label_cls,pred_bboxes,label_target)

            outputs['total_loss'] = cfg.TRAIN.CLS_WEIGHT * cls_loss + \
                cfg.TRAIN.LOC_WEIGHT * loc_loss +cfg.TRAIN.RANK_CLS_WEIGHT*CR_loss+cfg.TRAIN.RANK_IGR_WEIGHT*IGR_loss_1+cfg.TRAIN.RANK_IGR_WEIGHT*IGR_loss_2
            outputs['CR_loss'] = cfg.TRAIN.RANK_CLS_WEIGHT*CR_loss
            outputs['IGR_loss_1'] =cfg.TRAIN.RANK_IGR_WEIGHT*IGR_loss_1
            outputs['IGR_loss_2'] = cfg.TRAIN.RANK_IGR_WEIGHT*IGR_loss_2
        else:
            outputs['total_loss'] = cfg.TRAIN.CLS_WEIGHT * cls_loss + \
                cfg.TRAIN.LOC_WEIGHT * loc_loss
            
        outputs['cls_loss'] = cls_loss
        outputs['loc_loss'] = loc_loss
        
        return outputs

