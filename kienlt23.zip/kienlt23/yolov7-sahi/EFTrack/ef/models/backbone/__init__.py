# Copyright (c) SenseTime. All Rights Reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from ef.models.backbone.efficientnet import efficientnet

BACKBONES = {
              'efficientnet': efficientnet
            }


def get_backbone(name, **kwargs):
    return BACKBONES[name]()
