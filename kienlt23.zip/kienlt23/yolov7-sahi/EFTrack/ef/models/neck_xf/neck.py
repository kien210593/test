# Copyright (c) SenseTime. All Rights Reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import torch.nn as nn

########## BN adjust layer before Correlation ##########

class AdjustLayer(nn.Module):
    def __init__(self, num_channel = 112):
        super(AdjustLayer, self).__init__()
        self.downsample_xf = nn.Sequential(
            nn.BatchNorm2d(num_channel),
            )

    def forward(self, x):
        x = self.downsample_xf(x)
        return x
