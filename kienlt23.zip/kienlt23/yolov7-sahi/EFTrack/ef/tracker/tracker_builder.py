from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from ef.core.config import cfg
from ef.tracker.siamef_tracker import SiamEFTracker

TRACKS = {
          'SiamEFTracker': SiamEFTracker
         }


def build_tracker(model):
    return TRACKS[cfg.TRACK.TYPE](model)
