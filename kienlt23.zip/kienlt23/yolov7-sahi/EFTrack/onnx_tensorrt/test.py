import torch
import torch.nn.functional as F

# Tạo tensor với kích thước (1, 3, 6, 9) và giá trị mặc định là 0
# tensor = torch.randint((1, 2, 4, 8))

# In ra kích thước của tensor
x = torch.randint(1,10,(1, 2, 3, 4))
print(x)

print(x.permute(1, 2, 3, 0))


print(x.permute(1, 2, 3, 0).contiguous())

print(x.permute(1, 2, 3, 0).contiguous().view(2, -1))

print(x.permute(1, 2, 3, 0).contiguous().view(2, -1).permute(1, 0))

# print(x.permute(1, 2, 3, 0).contiguous().view(2, -1)[1, :])

# print(x.permute(1, 2, 3, 0).contiguous().view(2, -1)[2, :])

# print(x.permute(1, 2, 3, 0).contiguous().view(2, -1)[3, :])

score = x.permute(1, 2, 3, 0).contiguous().view(2, -1).permute(1, 0)

print(F.softmax(score.float(), dim=1))

print(F.softmax(score.float(), dim=1).data[:, 1])

score = F.softmax(score.float(), dim=1).data[:, 1].cpu().numpy()


