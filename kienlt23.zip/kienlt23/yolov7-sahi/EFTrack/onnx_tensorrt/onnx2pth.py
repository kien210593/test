import onnx
import torch
import torchvision

# Load the ONNX model
onnx_model_path = "/home/vee/thangkv/linhnq11/Tracking/pysot-master/onnx_tensorrt/model_template.onnx"
onnx_model = onnx.load(onnx_model_path)

# Convert the ONNX model to a PyTorch model
# pytorch_model = torchvision.models.detection.fasterrcnn_resnet50_fpn(pretrained=False, progress=False, num_classes=91)
# pytorch_model.eval()
dummy_input = torch.randn(1, 3, 127, 127)
pytorch_model = torch.onnx.export(onnx_model, dummy_input, "onnx_tensorrt/model_template.pth", verbose=False)