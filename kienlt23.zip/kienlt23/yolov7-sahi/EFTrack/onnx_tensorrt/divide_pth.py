import torch
import torch.nn as nn
from collections import OrderedDict
from ef.models.model_builder import ModelBuilder
from ef.core.config import cfg

# Load the original PyTorch model
model_path = "/home/vee/thangkv/linhnq11/Tracking/pysot-master/experiments/siamrpn_mobilev2_l234_dwxcorr/model.pth"
state_dict = torch.load(model_path)
# model = nn.Sequential(OrderedDict(state_dict))

# load config
cfg.merge_from_file("/home/vee/thangkv/linhnq11/Tracking/pysot-master/experiments/siamrpn_mobilev2_l234_dwxcorr/config.yaml")
cfg.CUDA = torch.cuda.is_available() and cfg.CUDA
device = torch.device('cuda' if cfg.CUDA else 'cpu')

# create model
model = ModelBuilder()

# load model
model.load_state_dict(torch.load(model_path,
    map_location=lambda storage, loc: storage.cpu()))
device = torch.device('cuda')
model.eval().to(device)

z = torch.randn(1, 3, 127, 127, device="cuda")

print(model.template())

print("====================================")



# # Create two sequential models
# n = 5  # the index of the layer to split on
# model1 = nn.Sequential(*list(model.children())[:2])
# model2 = nn.Sequential(*list(model.children())[2:])
# # print(model1)