import onnx

# Load ONNX model
onnx_model = onnx.load('/home/vee/thangkv/linhnq11/Tracking/pysot-master/onnx_tensorrt/model_search.onnx')

# Check tensor precision
for tensor in onnx_model.graph.initializer:
    print(tensor.name, tensor.data_type)
    
model = onnx.load('/home/vee/thangkv/linhnq11/Tracking/pysot-master/onnx_tensorrt/model_search.onnx')
weights = model.graph.initializer
print(weights)
