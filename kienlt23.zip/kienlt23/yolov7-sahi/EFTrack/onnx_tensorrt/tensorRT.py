import tensorrt as trt
import pycuda.driver as cuda
import pycuda.autoinit
import numpy as np
import onnx

# Đọc mô hình ONNX
onnx_model = onnx.load("/home/vee/thangkv/linhnq11/Tracking/pysot-master/onnx_tensorrt/model_template.onnx")

# Tạo trình phân tích TensorRT
TRT_LOGGER = trt.Logger(trt.Logger.WARNING)
trt_runtime = trt.Runtime(TRT_LOGGER)

# Chuyển đổi mô hình ONNX sang mô hình TensorRT
onnx_input_shape = (1, 3, 127, 127)  # Shape của input của mô hình ONNX
engine = trt.utils.onnx_to_trt_engine(onnx_model, TRT_LOGGER, max_batch_size=1, max_workspace_size=1 << 30, input_shape=onnx_input_shape, output_shapes=[(1, 256, 7, 7),(1, 256, 7, 7),(1, 256, 7, 7)])
