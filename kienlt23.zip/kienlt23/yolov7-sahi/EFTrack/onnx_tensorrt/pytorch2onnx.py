# Some standard imports
import io
import numpy as np

from torch import nn
import torch.utils.model_zoo as model_zoo
import torch.onnx

import torch.nn as nn
import torch.nn.init as init

from ef.models.model_builder import ModelBuilder
from ef.core.config import cfg
from ef.tracker.tracker_builder import build_tracker

# Load pretrained model weights
model_url = '/home/vee/thangkv/linhnq11/Tracking/EFTrack/experiments/efficienet/snapshot/checkpoint_e1.pth'
batch_size = 1    # just a random number

config = '/home/vee/thangkv/linhnq11/Tracking/EFTrack/experiments/efficienet/config.yaml'

cfg.merge_from_file(config)
cfg.CUDA = torch.cuda.is_available() and cfg.CUDA
# device = torch.device('cuda' if cfg.CUDA else 'cpu')
device = torch.device('cpu')
# create model
model = ModelBuilder()
# dist_model = DistModule(model)

# Initialize model with the pretrained weights
map_location = lambda storage, loc: storage
if torch.cuda.is_available():
    map_location = None
if 'model' in model_url :
    model.load_state_dict(torch.load(model_url,
        map_location=lambda storage, loc: storage.cpu()))
else:
    model.load_state_dict(torch.load(model_url,
        map_location=lambda storage, loc: storage.cpu())["state_dict"])

# model.load_state_dict(model_zoo.load_url(model_url, map_location=map_location))
model.to(device)

model.head.to(device)

print("device : ", device)

if device == "cuda" and torch.cuda.is_available():
    print("aaaaaaaaa")
    dtype = torch.cuda.FloatTensor
    # dtype = torch.float32  
else:
    dtype = torch.FloatTensor
# Input to the model
# x = torch.randn(batch_size, 3, 255, 255, requires_grad=True)
# print(x.shape)
# y = torch.randn(batch_size, 3, 127, 127, requires_grad=True)
# z = torch.randn(batch_size, 1, 4 , requires_grad=True)

# model.train(False)

input_size_template = [(3, 128, 128)]
input_size_search = [(3, 256, 256)]
# input_size_search = [(3, 255, 255)]
# input_size_search = [(3, 639, 639)]
input_size_template_z1 = [(256, 7, 7)]
input_size_template_z2 = [(256, 7, 7)]
input_size_template_z3 = [(256, 7, 7)]


x = [torch.rand(*in_size_search).type(dtype) for in_size_search in input_size_search]
z = [torch.rand(*in_size_template).type(dtype) for in_size_template in input_size_template]
z1 = [torch.rand(*in_size_template1).type(dtype) for in_size_template1 in input_size_template_z1]
z2 = [torch.rand(*in_size_template2).type(dtype) for in_size_template2 in input_size_template_z2]
z3 = [torch.rand(*in_size_template3).type(dtype) for in_size_template3 in input_size_template_z3]


x = torch.stack(x).to(device)
z = torch.stack(z).to(device)
z1 = torch.stack(z1).to(device)
z2 = torch.stack(z2).to(device)
z3 = torch.stack(z3).to(device)


# torch_out = torch.onnx.export(model,                   # model being run
#                               z,                       # model input
#                             "onnx_tensorrt/model_template.onnx",
#                             input_names = ["input"],
#                             output_names= ["output"],# where to save the model
# 			                opset_version=10,
#                             verbose = False,
#                             export_params=True)      # store the trained parameter weights


# torch_out = torch.onnx.export(model,                   # model being run
#                             (x,[z1,z2,z3]),       
#                             "onnx_tensorrt/model_template_191.onnx",
#                             input_names = ["input0", "input1", "input2", "input3"],
#                             output_names = ["cls", "loc"],
#                             verbose = False,
# 			                opset_version=10,
#                             export_params=True)      # store the trained parameter weights

torch_out = torch.onnx.export(model,                   # model being run
                            (z,x),       
                            "onnx_tensorrt/model_EF.onnx",
                            input_names = ["input1", "input2"],
                            output_names = ["cls", "loc"],
                            verbose = False,
			                opset_version=10,
                            export_params=True)      # store the trained parameter weights




import onnx
import onnxsim
onnx_model = onnx.load("onnx_tensorrt/model_EF.onnx")
onnx.checker.check_model(onnx_model)
onnx_model, check = onnxsim.simplify(onnx_model)
onnx.save(onnx_model, "onnx_tensorrt/model_EF.onnx")
