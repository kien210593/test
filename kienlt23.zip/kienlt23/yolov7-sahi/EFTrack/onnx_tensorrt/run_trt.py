import tensorrt as trt
import numpy as np
import os

import pycuda.driver as cuda
import pycuda.autoinit
import cv2

import torch


class HostDeviceMem(object):
    def __init__(self, host_mem, device_mem):
        self.host = host_mem
        self.device = device_mem

    def __str__(self):
        return "Host:\n" + str(self.host) + "\nDevice:\n" + str(self.device)

    def __repr__(self):
        return self.__str__()


class TrtModel:

    def __init__(self, engine_path, max_batch_size=1, dtype=np.float32):

        self.engine_path = engine_path
        self.dtype = dtype
        self.logger = trt.Logger(trt.Logger.WARNING)
        self.runtime = trt.Runtime(self.logger)
        print("self.runtime : ", self.runtime)
        self.engine = self.load_engine(self.runtime, self.engine_path)
        print("self.engine : ", self.engine)
        self.max_batch_size = max_batch_size
        self.inputs, self.outputs, self.bindings, self.stream = self.allocate_buffers()
        self.context = self.engine.create_execution_context()

    @staticmethod
    def load_engine(trt_runtime, engine_path):
        trt.init_libnvinfer_plugins(None, "")
        with open(engine_path, 'rb') as f:
            engine_data = f.read()
        engine = trt_runtime.deserialize_cuda_engine(engine_data)
        return engine

    def allocate_buffers(self):

        inputs = []
        outputs = []
        bindings = []
        stream = cuda.Stream()
        for binding in self.engine:
            self.outputs_shape = self.engine.get_binding_shape(binding)
            size = trt.volume(self.engine.get_binding_shape(binding)) * self.max_batch_size
            host_mem = cuda.pagelocked_empty(size, self.dtype)
            device_mem = cuda.mem_alloc(host_mem.nbytes)

            bindings.append(int(device_mem))

            if self.engine.binding_is_input(binding):
                inputs.append(HostDeviceMem(host_mem, device_mem))
            else:
                outputs.append(HostDeviceMem(host_mem, device_mem))
        
        return inputs, outputs, bindings, stream

    def __call__(self, x: np.ndarray, batch_size=1):
        
        print("len(x) :", len(x))
        print(len(self.inputs))
        for i in range(len(x)):
            np.copyto(self.inputs[i].host, x[i].ravel())
            cuda.memcpy_htod_async(self.inputs[i].device, self.inputs[i].host, self.stream)
            
        print("self.context : ", self.context)

        self.context.execute_async(batch_size=batch_size, bindings=self.bindings, stream_handle=self.stream.handle)
        for out in self.outputs:
            cuda.memcpy_dtoh_async(out.host, out.device, self.stream)

        self.stream.synchronize()
        return [out.host.reshape(batch_size, -1) for out in self.outputs]


if __name__ == "__main__":
    batch_size = 1
    trt_engine_path = os.path.join("onnx_tensorrt/model_template.trt")
    trt_engine_path1 = os.path.join("onnx_tensorrt/model_template_int8.trt")
    print(trt_engine_path)
    model = TrtModel(trt_engine_path)
    model1 = TrtModel(trt_engine_path1)
    shape = model.engine.get_binding_shape(0)
    data = np.random.randint(0, 255, (batch_size, *shape[1:])) # / 255
    img = cv2.imread("/media/oem/linhnq/Data_drone/Image/Data_Drone_Linh/37/1680.jpg")
    img = img[300:427,300:427]
    im_patch = img.transpose(2, 0, 1)
    im_patch = im_patch[np.newaxis, :, :, :]
    im_patch = im_patch.astype(np.float32)
    print(data)
    result = model(data)
    result1 = model1(data)
    print(result)
    print(result1)
    
    
    
    
    # input_shape = (1, 3, 127, 127)
    # input_data = np.zeros(input_shape, dtype=np.float32)
    # img = cv2.imread("/media/oem/linhnq/Data_drone/Image/Data_Drone_Linh/37/0215.jpg")
    # fs = cv2.FileStorage('/media/oem/linhnq/pysot-master/datatemplate_cpp.yml', cv2.FILE_STORAGE_READ)
    # mat = fs.getNode("matrix").mat()
    # print(mat)
    # print(mat.shape)
    # print(img)
    # img_crop = img[300:427,300:427]
    # cv2.imwrite("/home/vee/Downloads/TensorRT-8.5.3.1/data/siamrpn/template.jpg",img_crop)
    # img_crop = img[300:555,300:555]
    # cv2.imwrite("/home/vee/Downloads/TensorRT-8.5.3.1/data/siamrpn/search.jpg",img_crop)
    # print(img_crop.shape)
    
    # im_patch = mat.transpose(2, 0, 1)
    # im_patch = im_patch[np.newaxis, :, :, :]
    # im_patch = im_patch.astype(np.float32)
    # im_patch = torch.from_numpy(im_patch)
    # print(input_data)
    # print(im_patch[0][0][0])
    # print(im_patch[0][1][0])
    # print(im_patch[0][2][0])
    
    # print(im_patch.shape)
    # result = model(im_patch)
    # # print(len(result))
    # # print(result[1].shape)
    # print(result[0][0][:20])

    # # batch_size = 1
    # # trt_engine_path = os.path.join("onnx_tensorrt/model_search.trt")
    # # model = TrtModel(trt_engine_path)
    # # shape = model.engine.get_binding_shape(0)
    # # shape1 = model.engine.get_binding_shape(1)
    # # shape2 = model.engine.get_binding_shape(2)
    # # shape3 = model.engine.get_binding_shape(3)
    # # print("shape :", shape)
    # # # data_zero = np.zeros(shape, dtype=np.float32)
    # # data_img = img = cv2.imread("/home/vee/Downloads/TensorRT-8.5.3.1/data/siamrpn/search.jpg")
    # # im_patch = img.transpose(2, 0, 1)
    # # im_patch = im_patch[np.newaxis, :, :, :]
    # # im_patch = im_patch.astype(np.float32)
    # # data = np.random.randint(0, 255, (batch_size, *shape[1:])) / 255
    # # data1 = np.random.randint(0, 255, (batch_size, *shape1[1:])) / 255
    # # data2 = np.random.randint(0, 255, (batch_size, *shape2[1:])) / 255
    # # data3 = np.random.randint(0, 255, (batch_size, *shape3[1:])) / 255
    # # # input = [data, data1,data2,data3]
    # # input = [im_patch, result[0],result[1],result[2]]
    # # # data = np.random.randint(0,255,(1, 256, 25, 25))
    # # print(data.shape)
    # # # result = model(data,batch_size)
    # # result = model(input)
    # # print(result[0][0][:20])

    
    # Branch Mask
    # batch_size = 1
    # trt_engine_path = os.path.join("onnx_tensorrt/model_search_mask.trt")
    # model = TrtModel(trt_engine_path)
    # # shape = model.engine.get_binding_shape(0)
    # # shape1 = model.engine.get_binding_shape(1) 
    # shape = model.engine.get_binding_shape(0)
    # shape1 = model.engine.get_binding_shape(1)

    # data = np.random.randint(0, 255, (batch_size, *shape[1:])) / 255
    # data1 = np.random.randint(0, 255, (batch_size, *shape1[1:])) / 255
    # # input = [data, data1,data2,data3]
    
    # result = model([data, data1])
    # # print(len(result))
    # print(result[0].shape)
    
    # # Branch Search Mask
    # batch_size = 1
    # trt_engine_path = os.path.join("onnx_tensorrt/model_search_r50.trt")
    # model = TrtModel(trt_engine_path)
    # # shape = model.engine.get_binding_shape(0)
    # # shape1 = model.engine.get_binding_shape(1) 
    # print(type(model.engine.get_binding_shape))
    # shape = model.engine.get_binding_shape(0)
    # shape1 = model.engine.get_binding_shape(1)
    # shape2 = model.engine.get_binding_shape(2)
    # shape3 = model.engine.get_binding_shape(3)
    # shape4 = model.engine.get_binding_shape(4)
    # print(shape4)

    # data = np.random.randint(0, 255, (batch_size, *shape[1:])) / 255
    # data1 = np.random.randint(0, 255, (batch_size, *shape1[1:])) / 255
    # data2 = np.random.randint(0, 255, (batch_size, *shape2[1:])) / 255
    # data3 = np.random.randint(0, 255, (batch_size, *shape3[1:])) / 255
    # data4 = np.random.randint(0, 255, (batch_size, *shape4[1:])) / 255
    # input = [data, data1,data2,data3]
    
    # result = model(input)
    # # print(len(result))
    # # print(len(result))
    
    
    # # Branch Search Mask
    # batch_size = 1
    # trt_engine_path = os.path.join("onnx_tensorrt/model_search.trt")
    # model = TrtModel(trt_engine_path)
    # # shape = model.engine.get_binding_shape(0)
    # # shape1 = model.engine.get_binding_shape(1) 
    # print(type(model.engine.get_binding_shape))
    # shape = model.engine.get_binding_shape(0) 
    # print(shape)

    # data = np.random.randint(0, 255, (batch_size, *shape[1:])) / 255
    # input = [data]
    
    # result = model(input)
    # # # print(len(result))
    # # print(len(result))
    
    
    # # Branch Search Mask
    # batch_size = 1
    # trt_engine_path = os.path.join("onnx_tensorrt/model_reg.trt")
    # model = TrtModel(trt_engine_path)
    # # shape = model.engine.get_binding_shape(0)
    # # shape1 = model.engine.get_binding_shape(1) 
    # print(type(model.engine.get_binding_shape))
    # shape = model.engine.get_binding_shape(0)
    # shape1 = model.engine.get_binding_shape(1)
    # shape2 = model.engine.get_binding_shape(2)
    # shape3 = model.engine.get_binding_shape(3)
    # shape4 = model.engine.get_binding_shape(4)
    # shape5 = model.engine.get_binding_shape(5)
    # # shape6 = model.engine.get_binding_shape(6)
    # # print(shape4)
    # # print(shape6)

    # data = np.random.randint(0, 255, (batch_size, *shape[1:])) / 255
    # data1 = np.random.randint(0, 255, (batch_size, *shape1[1:])) / 255
    # data2 = np.random.randint(0, 255, (batch_size, *shape2[1:])) / 255
    # data3 = np.random.randint(0, 255, (batch_size, *shape3[1:])) / 255
    # data4 = np.random.randint(0, 255, (batch_size, *shape4[1:])) / 255
    # data5 = np.random.randint(0, 255, (batch_size, *shape5[1:])) / 255
    # # data6 = np.random.randint(0, 255, (batch_size, *shape6[1:])) / 255
    # input = [data, data1,data2,data3,data4,data5]
    
    # result = model(input)
    # # # print(len(result))
    # print(len(result))
    # print(result[0].shape)
    
    
    # # Branch Search Mask
    # batch_size = 1
    # trt_engine_path = os.path.join("onnx_tensorrt/model_mask.trt")
    # model = TrtModel(trt_engine_path)
    # # shape = model.engine.get_binding_shape(0)
    # # shape1 = model.engine.get_binding_shape(1) 
    # print(type(model.engine.get_binding_shape))
    # shape = model.engine.get_binding_shape(0)
    # shape1 = model.engine.get_binding_shape(1)

    # data = np.random.randint(0, 255, (batch_size, *shape[1:])) / 255
    # data1 = np.random.randint(0, 255, (batch_size, *shape1[1:])) / 255
    # input = [data, data1]
    
    # result = model(input)
    # # # print(len(result))
    # print(len(result))
    # print(result[0].shape)