import tensorrt as trt


TRT_LOGGER = trt.Logger(trt.Logger.WARNING)
trt_runtime = trt.Runtime(TRT_LOGGER)
def build_engine(onnx_path, shape = [1,3,127,127]):
    print(shape)
    with trt.Builder(TRT_LOGGER) as builder, builder.create_network(1) as network, trt.OnnxParser(network, TRT_LOGGER) as parser:
        config = builder.create_builder_config()
        # config.max_workspace_size = 1 << 28
        config.max_workspace_size = 8 * (2 ** 30)
        # builder.max_workspace_size = (256 << 20)
        # if builder.platform_has_fast_fp16:
        #     builder.fp16_mode = True
        # config.set_flag(trt.BuilderFlag.FP16)
        
        config.set_flag(trt.BuilderFlag.STRICT_TYPES)
        config.set_flag(trt.BuilderFlag.FP16)

        # # Enable the use of subnormal numbers
        # builder_config = builder.create_builder_config()
        # builder_config.set_flag(trt.BuilderFlag.FP16)

        
    with open(onnx_path, "rb") as model:
        parser.parse(model.read())
        for i in range(len(shape)):
            # network.get_input(i)
            network.get_input(i).shape = shape[i]    
        # network.get_input(0).shape = shape
        engine = builder.build_engine(network, config)
    return engine

onnx_path = "onnx_tensorrt/model_template.onnx"
shape = [1,3,127,127]
x = [1,3,255,255]
x1 = [1,256,31,31]
x2 = [1,256,31,31]
x3 = [1,256,31,31]
z1 = [1,256,7,7]
z2 = [1,256,7,7]
z3 = [1,256,7,7]
engine = build_engine(onnx_path=onnx_path, shape= [shape])
# engine = build_engine(onnx_path=onnx_path, shape= [x1,x2,x3,z1,z2,z3])

# TRT Mask
x = [1,256,7,7]
z = [1,256,31,31]
# engine = build_engine(onnx_path=onnx_path, shape= [x,z])
print(engine)

# Serialize and save the TensorRT engine to a file
serialized_engine = engine.serialize()
with open('onnx_tensorrt/model_template.trt', 'wb') as f:
    f.write(serialized_engine)


