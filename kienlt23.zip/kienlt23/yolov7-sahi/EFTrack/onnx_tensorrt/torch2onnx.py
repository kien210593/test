import onnx
import torch
import cv2
from ef.models.model_builder import ModelBuilder
from ef.core.config import cfg

# load config
cfg.merge_from_file("/home/vee/thangkv/linhnq11/Tracking/pysot-master/experiments/siamrpn_mobilev2_l234_dwxcorr/config.yaml")
cfg.CUDA = torch.cuda.is_available() and cfg.CUDA
device = torch.device('cuda' if cfg.CUDA else 'cpu')
# create model
model = ModelBuilder()

# load model
# device = torch.device('cuda' if True else 'cpu')
device = torch.device('cpu')
print(device)
model_path = "/home/vee/thangkv/linhnq11/Tracking/pysot-master/experiments/siamrpn_mobilev2_l234_dwxcorr/model.pth"
model.load_state_dict(torch.load(model_path,
    map_location=lambda storage, loc: storage.cpu()))
model.eval().to(device)

ONNX_FILE_PATH = '/home/vee/thangkv/linhnq11/Tracking/pysot-master/onnx_tensorrt/model_search.onnx'
z = torch.randn(1, 3, 127, 127, device="cuda")
x = torch.randn(1, 3, 255, 255, device="cuda")
z1 = torch.randn(1, 256, 7, 7, device="cuda")
z2 = torch.randn(1, 256, 7, 7, device="cuda")
z3 = torch.randn(1, 256, 7, 7, device="cuda")
zf = [z1,z2,z3]

# ONNX Template
torch.onnx.export(model, z, ONNX_FILE_PATH,verbose = False, input_names=['input'],output_names=['output'], export_params=True)


# ONNX Search
# torch.onnx.export(model, (x,zf), ONNX_FILE_PATH,verbose = False, input_names=['input'],output_names=['output'], export_params=True)
