import torch

# Load the model
# model = torch.load('/home/vee/thangkv/linhnq11/Tracking/EFTrack/experiments/efficienet/snapshot/checkpoint_e22.pth')

model = torch.load('/home/vee/thangkv/linhnq11/Tracking/EFTrack/experiments/efficienet/checkpoint_e4.pth')

# Inspect the dtype of the model parameters
for name, param in model['state_dict'].items():
# for name, param in model.items():
    print(f'{name}: {param.device}')
    # if 'layer9._bn2.weight' in name:
    #     print(param)
    
    
# import torch

# # Load the model
# model = torch.load('/home/vee/thangkv/linhnq11/Tracking/EFTrack/experiments/efficienet/efficientnet-b0.pth')

# # Inspect the dtype of the model parameters
# # for name, param in model['state_dict'].items():
# for name, param in model.items():
#     # print(f'{name}: {param.device}')
#     if 'layer7._bn0.weigh' in name:
#         print(param)