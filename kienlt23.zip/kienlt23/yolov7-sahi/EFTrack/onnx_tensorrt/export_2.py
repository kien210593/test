import os
import sys
import logging
import argparse

import numpy as np
import tensorrt as trt
import pycuda.driver as cuda
import pycuda.autoinit
from PIL import Image
import torchvision.transforms as transforms
import ctypes
import cv2
from onnx_tensorrt.augmentation import Augmentation

from ef.utils.bbox import corner2center, \
        Center, center2corner, Corner


# from image_batch import ImageBatcher

logging.basicConfig(level=logging.INFO)
logging.getLogger("EngineBuilder").setLevel(logging.INFO)
log = logging.getLogger("EngineBuilder")

class HostDeviceMem(object):
    def __init__(self, host_mem, device_mem):
        self.host = host_mem
        self.device = device_mem

    def __str__(self):
        return "Host:\n" + str(self.host) + "\nDevice:\n" + str(self.device)

    def __repr__(self):
        return self.__str__()


class TrtModel:

    def __init__(self, engine_path, max_batch_size=1, dtype=np.float32):

        self.engine_path = engine_path
        self.dtype = dtype
        self.logger = trt.Logger(trt.Logger.WARNING)
        self.runtime = trt.Runtime(self.logger)
        self.engine = self.load_engine(self.runtime, self.engine_path)
        self.max_batch_size = max_batch_size
        self.inputs, self.outputs, self.bindings, self.stream = self.allocate_buffers()
        self.context = self.engine.create_execution_context()

    @staticmethod
    def load_engine(trt_runtime, engine_path):
        trt.init_libnvinfer_plugins(None, "")
        with open(engine_path, 'rb') as f:
            engine_data = f.read()
        engine = trt_runtime.deserialize_cuda_engine(engine_data)
        return engine

    def allocate_buffers(self):

        inputs = []
        outputs = []
        bindings = []
        stream = cuda.Stream()
        for binding in self.engine:
            self.outputs_shape = self.engine.get_binding_shape(binding)
            size = trt.volume(self.engine.get_binding_shape(binding)) * self.max_batch_size
            host_mem = cuda.pagelocked_empty(size, self.dtype)
            device_mem = cuda.mem_alloc(host_mem.nbytes)

            bindings.append(int(device_mem))

            if self.engine.binding_is_input(binding):
                inputs.append(HostDeviceMem(host_mem, device_mem))
            else:
                outputs.append(HostDeviceMem(host_mem, device_mem))
        
        return inputs, outputs, bindings, stream

    def __call__(self, x: np.ndarray, batch_size=1):
        
        for i in range(len(x)):
            np.copyto(self.inputs[i].host, x[i].ravel())
            cuda.memcpy_htod_async(self.inputs[i].device, self.inputs[i].host, self.stream)

        self.context.execute_async(batch_size=batch_size, bindings=self.bindings, stream_handle=self.stream.handle)
        for out in self.outputs:
            cuda.memcpy_dtoh_async(out.host, out.device, self.stream)

        self.stream.synchronize()
        return [out.host.reshape(batch_size, -1) for out in self.outputs]

class HostDeviceMem(object):
    def __init__(self, host_mem, device_mem):
        self.host = host_mem
        self.device = device_mem

    def __str__(self):
        return "Host:\n" + str(self.host) + "\nDevice:\n" + str(self.device)

    def __repr__(self):
        return self.__str__()


class TrtModel:

    def __init__(self, engine_path, max_batch_size=1, dtype=np.float32):

        self.engine_path = engine_path
        self.dtype = dtype
        self.logger = trt.Logger(trt.Logger.WARNING)
        self.runtime = trt.Runtime(self.logger)
        self.engine = self.load_engine(self.runtime, self.engine_path)
        self.max_batch_size = max_batch_size
        self.inputs, self.outputs, self.bindings, self.stream = self.allocate_buffers()
        self.context = self.engine.create_execution_context()

    @staticmethod
    def load_engine(trt_runtime, engine_path):
        trt.init_libnvinfer_plugins(None, "")
        with open(engine_path, 'rb') as f:
            engine_data = f.read()
        engine = trt_runtime.deserialize_cuda_engine(engine_data)
        return engine

    def allocate_buffers(self):

        inputs = []
        outputs = []
        bindings = []
        stream = cuda.Stream()
        for binding in self.engine:
            self.outputs_shape = self.engine.get_binding_shape(binding)
            size = trt.volume(self.engine.get_binding_shape(binding)) * self.max_batch_size
            host_mem = cuda.pagelocked_empty(size, self.dtype)
            device_mem = cuda.mem_alloc(host_mem.nbytes)

            bindings.append(int(device_mem))

            if self.engine.binding_is_input(binding):
                inputs.append(HostDeviceMem(host_mem, device_mem))
            else:
                outputs.append(HostDeviceMem(host_mem, device_mem))
        
        return inputs, outputs, bindings, stream

    def __call__(self, x: np.ndarray, batch_size=1):
        
        for i in range(len(x)):
            np.copyto(self.inputs[i].host, x[i].ravel())
            cuda.memcpy_htod_async(self.inputs[i].device, self.inputs[i].host, self.stream)

        self.context.execute_async(batch_size=batch_size, bindings=self.bindings, stream_handle=self.stream.handle)
        for out in self.outputs:
            cuda.memcpy_dtoh_async(out.host, out.device, self.stream)

        self.stream.synchronize()
        return [out.host.reshape(batch_size, -1) for out in self.outputs]

class ImageBatcher:
    """
    Creates batches of pre-processed images.
    """

    def __init__(self, input, shape, dtype, max_num_images=None, exact_batches=False, preprocessor="fixed_shape_resizer", model = None):
        """
        :param input: The input directory to read images from.
        :param shape: The tensor shape of the batch to prepare, either in NCHW or NHWC format.
        :param dtype: The (numpy) datatype to cast the batched data to.
        :param max_num_images: The maximum number of images to read from the directory.
        :param exact_batches: This defines how to handle a number of images that is not an exact multiple of the batch
        size. If false, it will pad the final batch with zeros to reach the batch size. If true, it will *remove* the
        last few images in excess of a batch size multiple, to guarantee batches are exact (useful for calibration).
        :param preprocessor: Set the preprocessor to use, depending on which network is being used.
        """
        # Find images in the given input path
        input = os.path.realpath(input)
        self.images = []
        self.model = model

        extensions = [".jpg", ".jpeg", ".png", ".bmp"]

        def is_image(path):
            return os.path.isfile(path) and os.path.splitext(path)[1].lower() in extensions

        if os.path.isdir(input):
            self.images = [os.path.join(input, f) for f in os.listdir(input) if is_image(os.path.join(input, f))]
            self.images.sort()
        elif os.path.isfile(input):
            if is_image(input):
                self.images.append(input)
        self.num_images = len(self.images)
        if self.num_images < 1:
            print("No valid {} images found in {}".format("/".join(extensions), input))
            sys.exit(1)

        self.batch_size = shape[0][0]
        assert self.batch_size > 0
	

        # # Handle Tensor Shape
        self.dtype = dtype
        # self.shape = shape
        # assert len(self.shape) == 4
        # self.batch_size = shape[0]
        # assert self.batch_size > 0
        # self.format = None
        # self.width = -1
        # self.height = -1
        # if self.shape[1] == 3:
        #     self.format = "NCHW"
        #     self.height = self.shape[2]
        #     self.width = self.shape[3]
        # elif self.shape[3] == 3:
        #     self.format = "NHWC"
        #     self.height = self.shape[1]
        #     self.width = self.shape[2]
        # assert all([self.format, self.width > 0, self.height > 0])

        # Adapt the number of images as needed
        if max_num_images and 0 < max_num_images < len(self.images):
            self.num_images = max_num_images
        print("exact_batches :", exact_batches)
        if exact_batches:
            self.num_images = self.batch_size * (self.num_images // self.batch_size)
        if self.num_images < 1:
            print("Not enough images to create batches")
            sys.exit(1)
        self.images = self.images[0:self.num_images]

        # Subdivide the list of images into batches
        self.num_batches = 1 + int((self.num_images - 1) / self.batch_size)
        self.batches = []
        for i in range(self.num_batches):
            start = i * self.batch_size
            end = min(start + self.batch_size, self.num_images)
            self.batches.append(self.images[start:end])

        # Indices
        self.image_index = 0
        self.batch_index = 0

        self.preprocessor = preprocessor


    def get_batch(self):
        """
        Retrieve the batches. This is a generator object, so you can use it within a loop as:
        for batch, images in batcher.get_batch():
           ...
        Or outside of a batch with the next() function.
        :return: A generator yielding three items per iteration: a numpy array holding a batch of images, the list of
        paths to the images loaded within this batch, and the list of resize scales for each image in the batch.
        """
        # for i, batch_images in enumerate(self.batches):
        #     batch_data = np.zeros(self.shape, dtype=self.dtype)
        #     batch_scales = [None] * len(batch_images)
        #     for i, image in enumerate(batch_images):
        #         self.image_index += 1
        #         batch_data[i], batch_scales[i] = self.preprocess_image(image)
        #     self.batch_index += 1
        #     yield batch_data, batch_images, batch_scales

        for i, batch_images in enumerate(self.batches):
            batch_data = []
            image_batch = []
            #print(i)
            for j, image in enumerate(batch_images):
                #print(image)
                print(image)
                image = load_and_preprocess_image(image, j, self.model)
                image_batch = image_batch + image
                self.image_index += 1
            batch_data.append(image_batch)
            self.batch_index += 1
            yield batch_data, batch_images
        
        # images = []
        # for i in range(self.batch_size):
        #     # image = load_and_preprocess_image(image_path, shape)
        #     image = load_and_preprocess_image(self.images[self.current_batch], i)
        #     images.append(image)


class EngineCalibrator(trt.IInt8EntropyCalibrator2):
    def __init__(self, batch_size, cache_file = None):
        """
        :param cache_file: The location of the cache file.
        """
        super().__init__()
        self.cache_file = cache_file
        self.image_batcher = None
        self.batch_allocation = None
        self.batch_generator = None
        self.batch_size = batch_size
        self.device_inputs = []

    def set_image_batcher(self, image_batcher: ImageBatcher):
        """
        Define the image batcher to use, if any. If using only the cache file, an image batcher doesn't need
        to be defined.
        :param image_batcher: The ImageBatcher object
        """
        self.image_batcher = image_batcher
        input_sizes = [[3, 255, 255], [256, 7, 7], [256, 7, 7], [256, 7, 7]]
        # input_sizes = [[3, 127, 127]]
        
        for i in range(len(input_sizes)):
            #device_input = cuda.mem_alloc(ctypes.c_ulong(self.batch_size * np.prod(size) * 4).value.nbytes)
            #self.device_inputs.append(device_input)
            size = int(np.dtype(self.image_batcher.dtype[i]).itemsize * np.prod([self.batch_size] + list(input_sizes[i])))
            self.device_inputs.append(cuda.mem_alloc(size))
        self.batch_generator = self.image_batcher.get_batch()

    def get_batch_size(self):
        """
        Overrides from trt.IInt8EntropyCalibrator2.
        Get the batch size to use for calibration.
        :return: Batch size.
        """
        if self.image_batcher:
            return self.image_batcher.batch_size
        return 1

    def get_batch(self, names):
        #if self.current_batch >= len(self.images):
        #    return None

        # # Load and preprocess the images for the current batch
        # images = []
        # for i in range(self.batch_size):
        #     image = load_and_preprocess_image(self.images[self.current_batch], i)
        #     images.append(image)

        try:
            
            images, _ = next(self.batch_generator)
            log.info("Calibrating image {} / {}".format(self.image_batcher.image_index, self.image_batcher.num_images))
            # print("images : ", len(images[0]))
            # print(images[0][1].shape)
            
            # Copy the preprocessed images to the GPU for each input tensor
            for i, device_input in enumerate(self.device_inputs):
            #    cuda.memcpy_htod(self.batch_allocation, np.ascontiguousarray(image[i] for image in images))
                cuda.memcpy_htod(device_input, np.ascontiguousarray(images[0][i]))
        except StopIteration:
            log.info("Finished calibration batches")
            return None

        # Return a list of GPU pointers to the preprocessed images for each input tensor
        return [int(device_input) for device_input in self.device_inputs]
    
    def read_calibration_cache(self):
        """
        Overrides from trt.IInt8EntropyCalibrator2.
        Read the calibration cache file stored on disk, if it exists.
        :return: The contents of the cache file, if any.
        """
        if os.path.exists(self.cache_file):
            with open(self.cache_file, "rb") as f:
                log.info("Using calibration cache file: {}".format(self.cache_file))
                return f.read()

    def write_calibration_cache(self, cache):
        """
        Overrides from trt.IInt8EntropyCalibrator2.
        Store the calibration cache to a file on disk.
        :param cache: The contents of the calibration cache to store.
        """
        with open(self.cache_file, "wb") as f:
            log.info("Writing calibration cache data to: {}".format(self.cache_file))
            f.write(cache)


def load_and_preprocess_image(image_path, index, model):
    # Implement your own image loading and preprocessing logic here
    # This function should return a preprocessed image as a numpy array
    # The size of the image should match the respective input tensor size

    # Example: Using OpenCV to load and preprocess an image
    import cv2
    search_aug = Augmentation()
    image = cv2.imread(image_path)
    image = search_aug(image=image)
    if index == 0:
        image = cv2.resize(image, (255, 255))
        image = image.astype(np.float32)
        image = np.transpose(image, (2, 0, 1))  # Change the channel order to (C, H, W)
        print("image.shape1 : ", image_path)
    # elif index == 1:
    else:
        data = cv2.resize(image,(127,127))
        data = data.transpose(2, 0, 1)
        data = data[np.newaxis, :, :, :]
        data = data.astype(np.float32)
        import torch
        data = torch.from_numpy(data)
        result = model(data)
        image = [result[0].reshape((256, 7, 7)),result[1].reshape((256, 7, 7)),result[2].reshape((256, 7, 7))]
        print("image.shape2 : ", image_path)
        
        return image    
        
    return [image]


# def load_and_preprocess_image(image_path, index, model):
#     # Implement your own image loading and preprocessing logic here
#     # This function should return a preprocessed image as a numpy array
#     # The size of the image should match the respective input tensor size

#     # Example: Using OpenCV to load and preprocess an image
#     import cv2

#     image = cv2.imread(image_path)
#     if index == 0:
#         image = cv2.resize(image, (255, 255))
#         image = image.astype(np.float32)
#         image = np.transpose(image, (2, 0, 1))  # Change the channel order to (C, H, W)
#         print("image.shape : ", image.shape)
#     # elif index == 1:
#     else:
#         data = cv2.resize(image,(127,127))
#         data = data.transpose(2, 0, 1)
#         data = data[np.newaxis, :, :, :]
#         data = data.astype(np.float32)
#         import torch
#         data = torch.from_numpy(data)
#         result = model(data)
#         image = [result[0].reshape((256, 7, 7)),result[1].reshape((256, 7, 7)),result[2].reshape((256, 7, 7))]
#         return image    
        
#     return [image]

# Continue with the rest of your TensorRT code for building and executing the INT8 precision engine

class EngineBuilder:
    """
    Parses an ONNX graph and builds a TensorRT engine from it.
    """
    def __init__(self, verbose=False, workspace=8):
        """
        :param verbose: If enabled, a higher verbosity level will be set on the TensorRT logger.
        :param workspace: Max memory workspace to allow, in Gb.
        """
        self.trt_logger = trt.Logger(trt.Logger.INFO)
        if verbose:
            self.trt_logger.min_severity = trt.Logger.Severity.VERBOSE

        trt.init_libnvinfer_plugins(self.trt_logger, namespace="")

        self.builder = trt.Builder(self.trt_logger)
        self.config = self.builder.create_builder_config()
        self.config.max_workspace_size = workspace * (2 ** 30)

        self.batch_size = None
        self.network = None
        self.parser = None

    def create_network(self, onnx_path, end2end, conf_thres, iou_thres, max_det):
        """
        Parse the ONNX graph and create the corresponding TensorRT network definition.
        :param onnx_path: The path to the ONNX graph to load.
        """
        network_flags = (1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH))

        self.network = self.builder.create_network(network_flags)
        self.parser = trt.OnnxParser(self.network, self.trt_logger)

        onnx_path = os.path.realpath(onnx_path)
        with open(onnx_path, "rb") as f:
            if not self.parser.parse(f.read()):
                print("Failed to load ONNX file: {}".format(onnx_path))
                for error in range(self.parser.num_errors):
                    print(self.parser.get_error(error))
                sys.exit(1)

        inputs = [self.network.get_input(i) for i in range(self.network.num_inputs)]
        outputs = [self.network.get_output(i) for i in range(self.network.num_outputs)]

        print("Network Description")
        for input in inputs:
            self.batch_size = input.shape[0]
            print("Input '{}' with shape {} and dtype {}".format(input.name, input.shape, input.dtype))
        for output in outputs:
            print("Output '{}' with shape {} and dtype {}".format(output.name, output.shape, output.dtype))
        assert self.batch_size > 0
        self.builder.max_batch_size = self.batch_size

        if end2end:
            previous_output = self.network.get_output(0)
            self.network.unmark_output(previous_output)
            # output [1, 8400, 85]
            # slice boxes, obj_score, class_scores
            strides = trt.Dims([1,1,1])
            starts = trt.Dims([0,0,0])
            bs, num_boxes, temp = previous_output.shape
            shapes = trt.Dims([bs, num_boxes, 4])
            # [0, 0, 0] [1, 8400, 4] [1, 1, 1]
            boxes = self.network.add_slice(previous_output, starts, shapes, strides)
            num_classes = temp -5 
            starts[2] = 4
            shapes[2] = 1
            # [0, 0, 4] [1, 8400, 1] [1, 1, 1]
            obj_score = self.network.add_slice(previous_output, starts, shapes, strides)
            starts[2] = 5
            shapes[2] = num_classes
            # [0, 0, 5] [1, 8400, 80] [1, 1, 1]
            scores = self.network.add_slice(previous_output, starts, shapes, strides)
            # scores = obj_score * class_scores => [bs, num_boxes, nc]
            updated_scores = self.network.add_elementwise(obj_score.get_output(0), scores.get_output(0), trt.ElementWiseOperation.PROD)

            '''
            "plugin_version": "1",
            "background_class": -1,  # no background class
            "max_output_boxes": detections_per_img,
            "score_threshold": score_thresh,
            "iou_threshold": nms_thresh,
            "score_activation": False,
            "box_coding": 1,
            '''
            registry = trt.get_plugin_registry()
            assert(registry)
            creator = registry.get_plugin_creator("EfficientNMS_TRT", "1")
            assert(creator)
            fc = []
            fc.append(trt.PluginField("background_class", np.array([-1], dtype=np.int32), trt.PluginFieldType.INT32))
            fc.append(trt.PluginField("max_output_boxes", np.array([max_det], dtype=np.int32), trt.PluginFieldType.INT32))
            fc.append(trt.PluginField("score_threshold", np.array([conf_thres], dtype=np.float32), trt.PluginFieldType.FLOAT32))
            fc.append(trt.PluginField("iou_threshold", np.array([iou_thres], dtype=np.float32), trt.PluginFieldType.FLOAT32))
            fc.append(trt.PluginField("box_coding", np.array([1], dtype=np.int32), trt.PluginFieldType.INT32))
            
            fc = trt.PluginFieldCollection(fc) 
            nms_layer = creator.create_plugin("nms_layer", fc)

            layer = self.network.add_plugin_v2([boxes.get_output(0), updated_scores.get_output(0)], nms_layer)
            layer.get_output(0).name = "num_dets"
            layer.get_output(1).name = "det_boxes"
            layer.get_output(2).name = "det_scores"
            layer.get_output(3).name = "det_classes"
            for i in range(4):
                self.network.mark_output(layer.get_output(i))


    def create_engine(self, engine_path, precision, calib_input=None, calib_cache=None, calib_num_images=5000,
                      calib_batch_size=8, trttemplate = None)  :
        
        trt_engine_path = os.path.join(trttemplate)
        model = TrtModel(trt_engine_path)
        """
        Build the TensorRT engine and serialize it to disk.
        :param engine_path: The path where to serialize the engine to.
        :param precision: The datatype to use for the engine, either 'fp32', 'fp16' or 'int8'.
        :param calib_input: The path to a directory holding the calibration images.
        :param calib_cache: The path where to write the calibration cache to, or if it already exists, load it from.
        :param calib_num_images: The maximum number of images to use for calibration.
        :param calib_batch_size: The batch size to use for the calibration process.
        """
        engine_path = os.path.realpath(engine_path)
        engine_dir = os.path.dirname(engine_path)
        os.makedirs(engine_dir, exist_ok=True)
        print("Building {} Engine in {}".format(precision, engine_path))
        inputs = [self.network.get_input(i) for i in range(self.network.num_inputs)]

        # TODO: Strict type is only needed If the per-layer precision overrides are used
        # If a better method is found to deal with that issue, this flag can be removed.
        self.config.set_flag(trt.BuilderFlag.STRICT_TYPES)

        if precision == "fp16":
            if not self.builder.platform_has_fast_fp16:
                print("FP16 is not supported natively on this platform/device")
            else:
                self.config.set_flag(trt.BuilderFlag.FP16)
        elif precision == "int8":
            if not self.builder.platform_has_fast_int8:
                print("INT8 is not supported natively on this platform/device")
            else:
                if self.builder.platform_has_fast_fp16:
                    # Also enable fp16, as some layers may be even more efficient in fp16 than int8
                    self.config.set_flag(trt.BuilderFlag.FP16)
                self.config.set_flag(trt.BuilderFlag.INT8)
                # input_shapes = inputs
                # batcher = ImageBatcher(image_list, calibration_cache_file, input_shapes)
                # int8_calibrator = batcher
                # self.config.int8_calibrator = int8_calibrator
                calibrator = EngineCalibrator(calib_batch_size)
                self.config.int8_calibrator = calibrator
                if not os.path.exists(calib_cache):
                    # calib_shape = [calib_batch_size] + list(inputs[0].shape[1:])
                    # calib_dtype = trt.nptype(inputs[0].dtype)        
                    calib_shape = [([calib_batch_size] + list(inputs[i].shape[1:])) for i in range(len(inputs))]
                    calib_dtype = [(trt.nptype(inputs[i].dtype)) for i in range(len(inputs))]            
                    self.config.int8_calibrator.set_image_batcher(
                        ImageBatcher(calib_input, calib_shape, calib_dtype, max_num_images=calib_num_images,
                                     exact_batches=True,model = model))

        with self.builder.build_engine(self.network, self.config) as engine, open(engine_path, "wb") as f:
            print("Serializing engine to file: {:}".format(engine_path))
            f.write(engine.serialize())
            

def main(args):
    builder = EngineBuilder(args.verbose, args.workspace)
    builder.create_network(args.onnx, args.end2end, args.conf_thres, args.iou_thres, args.max_det)
    builder.create_engine(args.engine, args.precision, args.calib_input, args.calib_cache, args.calib_num_images,
                          args.calib_batch_size, args.trttemplate)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-o", "--onnx",default = "onnx_tensorrt/model_search.onnx", help="The input ONNX model file to load")
    parser.add_argument("-ot", "--trttemplate",default = "onnx_tensorrt/model_template_r50_int8py.trt", help="The input ONNX model file to load")
    parser.add_argument("-e", "--engine",default = "onnx_tensorrt/model_search_int8_py.trt", help="The output path for the TRT engine")
    parser.add_argument("-p", "--precision", default="int8", choices=["fp32", "fp16", "int8"],
                        help="The precision mode to build in, either 'fp32', 'fp16' or 'int8', default: 'fp16'")
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable more verbose log output")
    parser.add_argument("-w", "--workspace", default=1, type=int, help="The max memory workspace size to allow in Gb, "
                                                                       "default: 1")
    parser.add_argument("--calib_input",default = "demo/coco", help="The directory holding images to use for calibration")
    parser.add_argument("--calib_cache", default="./calibration.cache",
                        help="The file path for INT8 calibration cache to use, default: ./calibration.cache")
    parser.add_argument("--calib_num_images", default=5000, type=int,
                        help="The maximum number of images to use for calibration, default: 5000")
    parser.add_argument("--calib_batch_size", default=8, type=int,
                        help="The batch size for the calibration process, default: 8")
    parser.add_argument("--end2end", default=False, action="store_true",
                        help="export the engine include nms plugin, default: False")
    parser.add_argument("--conf_thres", default=0.8, type=float,
                        help="The conf threshold for the nms, default: 0.4")
    parser.add_argument("--iou_thres", default=0.75, type=float,
                        help="The iou threshold for the nms, default: 0.5")
    parser.add_argument("--max_det", default=100, type=int,
                        help="The total num for results, default: 100")


    args = parser.parse_args()
    print(args)
    if not all([args.onnx, args.engine]):
        parser.print_help()
        log.error("These arguments are required: --onnx and --engine")
        sys.exit(1)
    if args.precision == "int8" and not (args.calib_input or os.path.exists(args.calib_cache)):
        parser.print_help()
        log.error("When building in int8 precision, --calib_input or an existing --calib_cache file is required")
        sys.exit(1)
    
    main(args)