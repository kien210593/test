import tensorrt as trt

# Load the TensorRT engine
with open('/home/vee/thangkv/linhnq11/Tracking/pysot-master/onnx_tensorrt/model_template.trt', 'rb') as f:
    serialized_engine = f.read()
runtime = trt.Runtime(trt.Logger(trt.Logger.WARNING))
engine = runtime.deserialize_cuda_engine(serialized_engine)

# Get the data type of the input and output tensors
input_dtype = engine.get_binding_dtype(0)
output_dtype = engine.get_binding_dtype(1)
if input_dtype == trt.DataType.FLOAT and output_dtype == trt.DataType.FLOAT:
    print("Model uses float32 precision.")
elif input_dtype == trt.DataType.HALF and output_dtype == trt.DataType.HALF:
    print("Model uses float16 precision.")
else:
    print("Model uses mixed precision.")