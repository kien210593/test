import os
import shutil

folder_path = ""
folder_copy = ""
num_image = 1

for folder in os.listdir(folder_path):
    folder = os.path.join(folder_path + "/" + folder)
    for file in os.listdir(folder):
        if file.split(".")[-2] in ["x"] :
            shutil.copyfile(folder + "/" + file, folder_copy + "/0000." + str(num_image) + "." + file.split(".")[-2] + ".jpg")
    num_image += 1