from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os
import argparse

import cv2
import torch
import numpy as np
from glob import glob

from ef.core.config import cfg
from ef.models.model_builder import ModelBuilder
from ef.tracker.tracker_builder import build_tracker
from ef.utils.model_load import load_pretrain

torch.set_num_threads(1)



def get_frames(video_name):
    if not video_name:
        cap = cv2.VideoCapture(0)
        # warmup
        for i in range(5):
            cap.read()
        while True:
            ret, frame = cap.read()
            if ret:
                yield frame
            else:
                break
    elif video_name.endswith('avi') or \
        video_name.endswith('mp4') or video_name.endswith('MP4'):
        cap = cv2.VideoCapture(video_name)
        while True:
            ret, frame = cap.read()
            if ret:
                yield frame
            else:
                break
        cap.release()
    else:
        images = glob(os.path.join(video_name, '*.jp*'))
        images = sorted(images,
                        key=lambda x: int(x.split('/')[-1].split('.')[0]))
        for img in images:
            frame = cv2.imread(img)
            yield frame

    
def main():
    parser = argparse.ArgumentParser(description='tracking demo')
    parser.add_argument('--config', type=str, help='config file')
    parser.add_argument('--snapshot', type=str, help='model name')
    parser.add_argument('--path_video', default='/mnt/data/linhnq11/Data_Drone', type=str,
                        help='path folder video')
    parser.add_argument('--output_name', default='', type=str,
                        help='name folder output')
    parser.add_argument("--update_template", action="store_true", 
                        help="Mode update template or not") 

    args = parser.parse_args()

    # load config
    cfg.merge_from_file(args.config)
    cfg.CUDA = torch.cuda.is_available() and cfg.CUDA
    device = torch.device('cuda' if cfg.CUDA else 'cpu')

    # create model
    model = ModelBuilder()

    # load model
    model.load_state_dict(torch.load(args.snapshot,
        map_location=lambda storage, loc: storage.cpu())['state_dict'])
    model.eval().to(device)

    # load model
    model = load_pretrain(model, args.snapshot).cuda().eval()

    # build tracker
    tracker = build_tracker(model)

    folder_video = os.path.join(args.path_video, "Data_Drone_Linh_video")
    folder_gt_init = os.path.join(args.path_video, "gt_init")
    folder_gt = os.path.join(args.path_video, args.output_name)
    
    try:
        os.makedirs(folder_gt)
    except:
        pass
    
    for i in range(1,145):
        cv2.namedWindow(str(i), cv2.WND_PROP_FULLSCREEN)
        folder_img = folder_video + "/" + str(i) +'.mp4'
        file_txt = folder_gt_init + "/" + str(i) + ".txt"
        file_gt_txt = folder_gt + "/" + str(i) + ".txt"
        print(folder_img)
        print(file_txt)
        f = open(file_gt_txt, "w+")
        with open(file_txt,'r') as file :
            lines = file.readlines()
        lines = lines[0].split(',')
        print(lines)
        first_frame = True
        frame_count = 1
        
        for frame in get_frames(folder_img):
            print(frame_count)
            if first_frame:
                init_rect = (int(lines[0]),int(lines[1]),int(lines[2]),int(lines[3]))
                f.write(str(frame_count) + "," + str(lines[0]) + "," + str(lines[1]) + "," + str(lines[2]) + "," + str(lines[3]) + "\n")
                print(init_rect)
                tracker.init(frame, init_rect)
                first_frame = False
            else:
                outputs = tracker.track(frame)
                if args.update_template: 
                    if outputs['best_score'] > 0.9999 and (frame_count)%60 == 0:
                        tracker.init(frame, outputs['bbox'])
                bbox = list(map(int, outputs['bbox']))
                f.write(str(frame_count) + "," + str(bbox[0]) + "," + str(bbox[1]) + "," + str(bbox[2]) + "," + str(bbox[3]) + "\n")
                cv2.rectangle(frame, (bbox[0], bbox[1]),
                    (bbox[0]+bbox[2], bbox[1]+bbox[3]),
                    (0, 255, 0), 1)
                cv2.imshow(str(i), frame)
                cv2.waitKey(1)
            frame_count += 1
        cv2.destroyAllWindows()


if __name__ == '__main__':
    main()
