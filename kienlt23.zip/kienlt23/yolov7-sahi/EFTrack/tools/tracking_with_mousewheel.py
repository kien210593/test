from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os
import sys
import argparse

import cv2
import torch
import numpy as np
from glob import glob

sys.path.append(os.path.join(os.getcwd(), 'EFTrack'))
from ef.core.config import cfg
from ef.models.model_builder import ModelBuilder
from ef.tracker.tracker_builder import build_tracker
from ef.utils.model_load import load_pretrain

torch.set_num_threads(1)

parser = argparse.ArgumentParser(description='tracking demo')
parser.add_argument('--config', type=str, help='config file')
parser.add_argument('--snapshot', type=str, help='model name')
parser.add_argument('--video-path', type=str, help='videos or image files')
parser.add_argument('--txt-dir', type=str,
                    help='output text file to {txt-dir}/{video-file-name}')
parser.add_argument('--start', default=1, type=int,
                    help='the i-th frame to start from')
parser.add_argument('--wait-ms', default=100, type=int,
                    help='the wait time between frames (MILISECONDS)')
args = parser.parse_args()

IMAGE_SUFFIXES = ['.jpg', '.png']

class selectROI():
    def __init__(self, winname, frame):
        self.winname = winname
        self.frame = frame.copy()
        self.org_frame = frame.copy()
    def mwheel_SelectROI(self):
        # Read frame
        cv2.imshow(self.winname, self.frame)
        cv2.namedWindow(self.winname)
        cv2.setMouseCallback(self.winname, self.extract_coordinates)
        while True:
            key = cv2.waitKey(2)
            cv2.imshow(self.winname, self.frame)

            # end selection on SPACE (32), ESC (27) or ENTER (13)
            if key == 32 or key == 13:
                x1, y1 = self.image_coordinates[0]
                x2, y2 = self.image_coordinates[1]

                xleft = min(x1, x2)
                ytop = min(y1, y2)
                w = abs(x2 - x1)
                h = abs(y2 - y1)
                cv2.setMouseCallback(self.winname, self.empty_mouse_handler)
                print(x1, x2, y1, y2)
                print(xleft, ytop, w, h)
                return [xleft, ytop, w, h]
            elif key == 27:
                cv2.destroyAllWindows()
                return None

    def empty_mouse_handler(self, event, x, y, flags, parameters):
        pass

    def extract_coordinates(self, event, x, y, flags, parameters):
        # Record starting (x,y) coordinates on left mouse button click
        if event == cv2.EVENT_MBUTTONDOWN:
            self.frame = self.org_frame.copy()
            cv2.imshow(self.winname, self.frame)
            self.image_coordinates = [(x, y)]
            extract = True

        # Record ending (x,y) coordintes on left mouse bottom release
        elif event == cv2.EVENT_MBUTTONUP:
            self.image_coordinates.append((x, y))
            extract = False
            selected_ROI = True

            # Draw rectangle around ROI
            cv2.rectangle(
                self.frame, self.image_coordinates[0], self.image_coordinates[1], (0, 255, 0), 2)


def get_frames(video_path_or_images_dir):
    """
    Returns a stream of (frame, frame_name) from a video or directory of images.
    Returns:
        frame: numpy array of current frame
        frame_name: name of current frame without extension (to output corresponding labels later)
    """
    frame_cnt = 0
    if not video_path_or_images_dir:
        cap = cv2.VideoCapture(0)
        # warmup
        for i in range(5):
            cap.read()
        while True:
            ret, frame = cap.read()
            if ret:
                frame_name = f'{10000+frame_cnt}'
                frame_cnt += 1
                yield frame, frame_name
            else:
                break
    elif video_path_or_images_dir.endswith('avi') or video_path_or_images_dir.endswith('mp4'):
        cap = cv2.VideoCapture(video_path_or_images_dir)
        video_name = os.path.splitext(os.path.basename(video_path_or_images_dir))[0]
        while True:
            ret, frame = cap.read()
            if ret:
                frame_name = f'{video_name}_{10000+frame_cnt}'
                frame_cnt += 1
                yield frame, frame_name
            else:
                cap.release()
                break
    else:
        imgs = []
        for suffix in IMAGE_SUFFIXES:
            imgs += sorted(glob(os.path.join(video_path_or_images_dir, f'*{suffix}')))
        for img in imgs:
            frame = cv2.imread(img)
            frame_name = os.path.splitext(os.path.basename(img))[0]
            yield frame, frame_name
            
class StabTest:
    def __init__(self):
        self.pre_img = None
        self.detector = cv2.ORB_create()
        self.matcher = cv2.DescriptorMatcher_create(cv2.DESCRIPTOR_MATCHER_BRUTEFORCE_HAMMING)
        self.gme_rs = np.eye(3, dtype=np.float32)

    def init(self, in_frame):
        self.pre_img = in_frame.copy()
        self.gme_rs = np.eye(3, dtype=np.float32)
        return True

    def process(self, in_frame):
        frame = in_frame.copy()
        # print('----StabTest process---')
        # print('pre_img vs frame SSIM', ssim(self.pre_img[:,:,0], frame[:,:,0]))
        kp1, des1 = self.detector.detectAndCompute(self.pre_img, None)
        kp2, des2 = self.detector.detectAndCompute(frame, None)
        # print('kp1', kp1)
        # print('kp2', kp2)
        # print('des1', des1)
        # print('des2', des2)
        if des1 is None or des2 is None:
            self.gme_rs = np.eye(3, dtype=np.float32)
            return self.gme_rs

        matches = self.matcher.match(des1, des2, None)
        matches = sorted(matches, key=lambda x: x.distance)
        # print('number matches', len(matches))
        if len(matches) < 4:
            self.gme_rs = np.eye(3, dtype=np.float32)
            return self.gme_rs

        pts1 = np.float32([kp1[m.queryIdx].pt for m in matches[:30]]).reshape(-1, 1, 2)
        pts2 = np.float32([kp2[m.trainIdx].pt for m in matches[:30]]).reshape(-1, 1, 2)

        self.gme_rs, mask = cv2.estimateAffinePartial2D(pts1, pts2, cv2.RANSAC, ransacReprojThreshold=2)

        if self.gme_rs is None:
            self.gme_rs = np.eye(3, dtype=np.float32)
        else:
            self.gme_rs = np.vstack([self.gme_rs, [0, 0, 1]])

        # if not (pts1==pts2).all():
        #     print('pts1', pts1)
        #     print('pts2', pts2)
        #     print('pts1==pts2', (pts1==pts2).all())
        #     print('gme_rs', self.gme_rs)
        #     exit()
        self.pre_img = frame.copy()
        return self.gme_rs

    def get_gme_matrix(self):
        if self.gme_rs.size != 0:
            return self.gme_rs.copy()
        return None

    # Usage example:
    # stab_test = StabTest()
    # frame = cv2.imread("path_to_image")
    # stab_test.init(frame)
    # result = stab_test.process(frame)
    # gme_matrix = stab_test.get_gme_matrix()

def main():
    """
    Read a video or directory of images one-by-one-frame. Select ROI at first frame or key 's' is pressed
    After each frame, save labels to vidname_10000, vidname_10001.txt... for easier sorting
    """
    print('Start tracking!')    # Copy potential threading-issue code to this
    # load config
    cfg.merge_from_file(args.config)
    cfg.CUDA = torch.cuda.is_available() and cfg.CUDA
    device = torch.device('cuda' if cfg.CUDA else 'cpu')

    # create model
    model = ModelBuilder()

    # load model
    # model = load_pretrain(model, args.snapshot).eval().to(device)
    model.load_state_dict(torch.load(args.snapshot,
                                     map_location=lambda storage, loc: storage.cpu())['state_dict'])
    model.eval().to(device)
    
    stab_test = StabTest()

    # build tracker
    tracker = build_tracker(model)
    print('Done build tracker!')

    first_frame = True
    if args.video_path:
        video_name = args.video_path.split('/')[-1].split('.')[0]
    else:
        video_name = 'webcam'
    print('Done video name', video_name)

    # set up window, count start from 0
    frame_count = 0
    num_track = args.start
    if args.txt_dir:
        dir_txt = args.txt_dir
    else:
        dir_txt = '/'.join(args.video_path.split('/')
                           [:-1]) + '/' + video_name + '_labels'
    os.makedirs(dir_txt, exist_ok=True)
    print(f'Output texts to {dir_txt}')
    cv2.namedWindow(video_name, cv2.WINDOW_NORMAL)

    # Read frames one-by-one. Select ROI at first frame or key 's' is pressed
    is_selecting_roi = False
    for frame, frame_name in get_frames(args.video_path):
        
        if frame_count < num_track:     # omits all frames before start frame
            print('Processing', frame_count)
            frame_count += 1
            continue
        else:
            label_path = os.path.join(dir_txt, f'{frame_name}.txt')
            print('Processing', frame_count, 'saving to', label_path)
            
            if is_selecting_roi or (frame_count == num_track):
                width, height = frame.shape[1], frame.shape[0]
                
                cv2.imshow(video_name, frame)
                try:
                    roi = selectROI(video_name, frame)
                    init_rect = roi.mwheel_SelectROI()
                    print(init_rect)
                    # To YOLO labels
                    cls = 0
                    dx = (init_rect[0] + init_rect[2] / 2) / width
                    dy = (init_rect[1] + init_rect[3] / 2) / height
                    dw = init_rect[2] / width
                    dh = init_rect[3] / height
                    with open(label_path, 'w') as f:
                        f.write(
                            f"{cls} {' '.join(f'{txt:.6f}' for txt in (dx, dy, dw, dh))}")
                except:
                    exit()
                tracker.init(frame, init_rect)
                stab_test.init(frame)
                is_selecting_roi = False

            else:
                result = stab_test.process(frame)
                gme = stab_test.get_gme_matrix()
                gme = np.transpose(gme)
                outputs = tracker.track(frame, gme)
                bbox = list(map(int, outputs['bbox']))
                dx = (bbox[0] + bbox[2] / 2) / width
                dy = (bbox[1] + bbox[3] / 2) / height
                dw = bbox[2] / width
                dh = bbox[3] / height
                cv2.rectangle(
                    frame, (bbox[0], bbox[1]), (bbox[0]+bbox[2], bbox[1]+bbox[3]), (0, 255, 0), 1)

                # annotate dw, dh
                cv2.putText(frame, f'{dw*width:.0f}x{dh*height:.0f}',
                            (bbox[0], bbox[1]-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)

                # Put text of frame number
                cv2.setWindowTitle(video_name, 'Frame #' + str(frame_count))
                with open(label_path, 'w') as f:
                    f.write(
                        f"{cls} {' '.join(f'{txt:.6f}' for txt in (dx, dy, dw, dh))}")
                    
                # Put instructions
                font_color = (0, 0, 0)
                cv2.putText(frame, 'Press s to select ROI again', (20, 15), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1, font_color, 1)
                cv2.putText(frame, 'Press esc to quit', (20, 35), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1, font_color, 1)
                color = (255, 0, 0)
                cv2.circle(frame, (int(tracker.dic[0]), int(tracker.dic[1])), 2, color, -1)
                cv2.imshow(video_name, frame)

                # exit by 'esc' or manually change bbox by press 's'
                k = cv2.waitKey(args.wait_ms)
                if k == 27:
                    exit()
                    break
                elif k == ord('s'):
                    print(f'Redo frame {frame_count}')
                    is_selecting_roi = True

            frame_count += 1

if __name__ == '__main__':
    main()
