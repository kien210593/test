from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os
import argparse

import cv2
import torch
import numpy as np
from glob import glob
import time

from ef.core.config import cfg
from ef.models.model_builder import ModelBuilder

from torchvision import models
from torchsummary import summary

torch.set_num_threads(1)

def main():
    config = '/mnt/data/linhnq11/Tracking/EFTrack_git/experiments/efficientnet_b1_BAM/config.yaml'

    cfg.merge_from_file(config)
    cfg.CUDA = torch.cuda.is_available() and cfg.CUDA
    device = torch.device('cuda' if cfg.CUDA else 'cpu')

    model = ModelBuilder()
    model.to(device)

    # print(model.backbone.weight())

    if device == "cuda" and torch.cuda.is_available():
        dtype = torch.cuda.FloatTensor
        # dtype = torch.float32  
    else:
        dtype = torch.FloatTensor


    input_size_template = [(3, 128, 128)]
    input_size_search = [(3, 256, 256)]

    x = [torch.rand(*in_size_search).type(dtype) for in_size_search in input_size_search]
    z = [torch.rand(*in_size_template).type(dtype) for in_size_template in input_size_template]

    x = torch.stack(x).to(device)
    z = torch.stack(z).to(device)

    input_size_template = (3, 128, 128)
    input_size_search = (3, 256, 256) #1 

    summary(model, [input_size_template, input_size_search])

if __name__ == '__main__':
    main()
