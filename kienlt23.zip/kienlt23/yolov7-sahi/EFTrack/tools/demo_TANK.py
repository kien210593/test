# Copyright (c) SenseTime. All Rights Reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import argparse
import os

import cv2
import torch
import numpy as np
from glob import glob

from ef.core.config import cfg
from ef.models.model_builder import ModelBuilder
from ef.tracker.tracker_builder import build_tracker
from ef.utils.model_load import load_pretrain
from toolkit.datasets import DatasetFactory
from toolkit.utils.region import vot_overlap, vot_float2str


parser = argparse.ArgumentParser(description='siamrpn tracking')
parser.add_argument('--config', default='config.yaml', type=str,
        help='config file')
parser.add_argument('--snapshot', default='', type=str,
        help='snapshot of models to eval')
parser.add_argument('--path_data', default='', type=str,
        help='path folder data')
parser.add_argument('--output_name', default='', type=str,
        help='name folder txt output')
args = parser.parse_args()

torch.set_num_threads(1)

def get_frames(video_name):
    if not video_name:
        cap = cv2.VideoCapture(0)
        # warmup
        for i in range(5):
            cap.read()
        while True:
            ret, frame = cap.read()
            if ret:
                yield frame
            else:
                break
    elif video_name.endswith('avi') or \
        video_name.endswith('mp4') or video_name.endswith('MP4'):
        cap = cv2.VideoCapture(video_name)
        while True:
            ret, frame = cap.read()
            if ret:
                yield frame
            else:
                break
        cap.release()
    else:
        images = glob(os.path.join(video_name, '*.jp*'))
        images = sorted(images,
                        key=lambda x: int(x.split('/')[-1].split('.')[0]))
        for img in images:
            frame = cv2.imread(img)
            yield frame
    # cap.release()

# Convert to YCBCR
def imadjust(image, bbox, low_out=0, high_out=255, n = 2):
    # print("image : ", image)
    x1 = max(0,int(bbox[0] + bbox[2]/2 - 90))
    x2 = min(image.shape[1], int(bbox[0] + bbox[2]/2 + 90))
    y1 = max(0, int(bbox[1] + bbox[3]/2 - 90))
    y2 = min(image.shape[0], int(bbox[1] + bbox[3]/2 + 90))
    img_crop = image[y1:y2 ,x1 :x2,:]
    
    ycrcb_img = cv2.cvtColor(img_crop, cv2.COLOR_BGR2YCrCb)
    # print("ycrcb_img : ", ycrcb_img)
    img = ycrcb_img[:,:,0]
    avg = np.mean(img)
    sigma = np.std(img)
    low_in = avg - n * sigma 
    high_in = avg + n * sigma
    img = np.clip(img, low_in, high_in)
    img = (img - low_in) / (high_in - low_in)
    img = img * (high_out - low_out) + low_out
    img = np.clip(img, low_out, high_out)
    ycrcb_img[:,:,0] = img
    # convert back to RGB color-space from YCrCb
    img_crop = cv2.cvtColor(ycrcb_img, cv2.COLOR_YCrCb2BGR)
    image[y1:y2 , x1:x2, :] = img_crop
    return image.astype(np.uint8)

def histeq(img, bbox):
    x1 = max(0,int(bbox[0] + bbox[2]/2 - 90))
    x2 = min(img.shape[1], int(bbox[0] + bbox[2]/2 + 90))
    y1 = max(0, int(bbox[1] + bbox[3]/2 - 90))
    y2 = min(img.shape[0], int(bbox[1] + bbox[3]/2 + 90))
    img_crop = img[y1:y2 ,x1 :x2,:]
    
    # convert from RGB color-space to YCrCb
    ycrcb_img = cv2.cvtColor(img_crop, cv2.COLOR_BGR2YCrCb)

    # equalize the histogram of the Y channel
    ycrcb_img[:, :, 0] = cv2.equalizeHist(ycrcb_img[:, :, 0])

    # convert back to RGB color-space from YCrCb
    equalized_img = cv2.cvtColor(ycrcb_img, cv2.COLOR_YCrCb2BGR)
    
    img[y1:y2 ,x1 :x2,:] = equalized_img

    return img.astype(np.uint8)

def adapthisteq(image, bbox):
    x1 = max(0,int(bbox[0] + bbox[2]/2 - 90))
    x2 = min(image.shape[1], int(bbox[0] + bbox[2]/2 + 90))
    y1 = max(0, int(bbox[1] + bbox[3]/2 - 90))
    y2 = min(image.shape[0], int(bbox[1] + bbox[3]/2 + 90))

    img_crop = image[y1:y2 ,x1 :x2,:]
    ycrcb_img = cv2.cvtColor(img_crop, cv2.COLOR_BGR2YCrCb)
    img = ycrcb_img[:,:,0]
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    equalized_image = clahe.apply(img)
    ycrcb_img[:,:,0] = equalized_image
    img_crop = cv2.cvtColor(ycrcb_img, cv2.COLOR_YCrCb2BGR)
    image[y1:y2 ,x1 :x2,:] = img_crop
    return image.astype(np.uint8)

def adjust_image_gamma(image, bbox, gamma = 0.8):
    x1 = max(0,int(bbox[0] + bbox[2]/2 - 90))
    x2 = min(image.shape[1], int(bbox[0] + bbox[2]/2 + 90))
    y1 = max(0, int(bbox[1] + bbox[3]/2 - 90))
    y2 = min(image.shape[0], int(bbox[1] + bbox[3]/2 + 90))

    img_crop = image[y1:y2 ,x1 :x2,:]
    ycrcb_img = cv2.cvtColor(img_crop, cv2.COLOR_BGR2YCrCb)
    img = ycrcb_img[:,:,0]
    img = np.power(img, gamma)
    max_val = np.max(img.ravel())
    img = img/max_val * 255
    ycrcb_img[:,:,0] = img
    ycrcb_img = cv2.cvtColor(ycrcb_img, cv2.COLOR_YCrCb2BGR)
    image[y1:y2 ,x1 :x2,:] = ycrcb_img
    return image.astype(np.uint8)

CONTRAST = {
	  'imadjust': imadjust,
	  'histeq': histeq,
	  'adapthisteq': adapthisteq,
	  "gamma" : adjust_image_gamma,
        }

def enhance_contrast(img, bbox):
    return CONTRAST[cfg.TRACK.MODE_CONTRAST](img, bbox)

    
def main():
    # load config
    cfg.merge_from_file(args.config)

    cur_dir = os.path.dirname(os.path.realpath(__file__))


    # create model
    model = ModelBuilder()
  
    # load model
    model = load_pretrain(model, args.snapshot).cuda().eval()

    path_data = args.path_data
    
    # build tracker
    tracker = build_tracker(model)
    
    folder_video = os.path.join(path_data, "video_test_tank")
    folder_gt_init = os.path.join(path_data, "GT", "gt_init")
    folder_gt = os.path.join(path_data, "GT", args.output_name)

    folder_gt = folder_gt + "_" + cfg.TRACK.MODE_CONTRAST
    
    for folder_name in os.listdir(folder_video):
        path_folder_video = folder_gt + "/" + folder_name
        print("path_folder_video :",path_folder_video)
        try:
            os.makedirs(path_folder_video)
        except:
            pass

        for root, dirs, files in os.walk(folder_video + '/' + folder_name, topdown=True):
            # print(files)
            for name in files:
                # if True:
                if '20230209_144013' in name:
                    path_video = os.path.join(root, name)
                    name_video = name.split(".")[0]
                    
                    file_gt_init_txt = folder_gt_init + '/' + folder_name + "/" + name_video + ".txt"
                    file_gt_txt = folder_gt + '/' + folder_name + "/" + name_video + ".txt"
                    print("file_gt_txt : " , file_gt_txt)
                    
                    f = open(file_gt_txt, "w+")
                    with open(file_gt_init_txt,'r') as file :
                        lines = file.readlines()
                    lines = lines[0].split(',')
                    # print(lines)
                    first_frame = True
                    frame_count = 1
                    start_track = int(lines[0])
                    
                 
                    for frame in get_frames(path_video):
                        print("path_video :" , path_video)
                        print(frame_count)
                        if frame_count == start_track:
                            init_rect = (int(int(lines[1])),(int(lines[2])),int( int(lines[3])),int(int(lines[4])))
                            f.write(str(frame_count) + "," + str(lines[1]) + "," + str(lines[2]) + "," + str(lines[3]) + "," + str(lines[4]))
                            print(init_rect)
                            frame_enhanced = enhance_contrast(frame, init_rect)
                            tracker.init(frame_enhanced, init_rect)
                            bbox = init_rect
                            first_frame = False
                        
                        elif frame_count > start_track:
                            frame_enhanced = enhance_contrast(frame, bbox)
                            outputs = tracker.track(frame)
                            
                            if outputs['best_score'] > 0.9999 and (frame_count)%60 == 0:
                                tracker.init(frame, outputs['bbox'])

                            bbox = list(map(int, outputs['bbox']))
                            print("outputs['best_score'] : ", outputs['best_score'])
                            center = (int(bbox[0] + bbox[2]/2), int(bbox[1] + bbox[3]/2))
                            f.write(str(frame_count) + "," + str(bbox[0]) + "," + str(bbox[1]) + "," + str(bbox[2]) \
                                 + "," + str(bbox[3]) + "," + str(float(bbox[0] + bbox[2]/2)) + "," + str(float(bbox[1] + bbox[3]/2)) + "," \
                                 "\n")			
				
                            cv2.circle(frame, center=center, radius = 1, color=(255,255,0), thickness=-1)
                            if outputs['best_score'] > cfg.TRACK.CONFIDENCE_SCORE:
                                cv2.rectangle(frame, (bbox[0], bbox[1]),
                                    (bbox[0]+bbox[2], bbox[1]+bbox[3]),
                                    (0, 255, 0), 1)
                            else:
                                cv2.rectangle(frame, (bbox[0], bbox[1]),
                                    (bbox[0]+bbox[2], bbox[1]+bbox[3]),
                                    (0, 0, 255), 1)
                            cv2.imshow(name_video, frame)
                            cv2.waitKey(40)
                        frame_count += 1
                    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
