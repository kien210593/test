#!/usr/bin/env python
# coding: utf-8


import numpy as np
import pandas as pd
from PIL import Image
from glob import glob
import os
from pathlib import Path
import random
import re
from tqdm import tqdm
import json
import shutil
import argparse


# folder_img = '/home/pc1/works/HungNV/tank/9/tank_sb_916_Txx_00000009_07_03_clip5'
# target_path = folder_img + '_for_detect'
# Path(target_path).mkdir(parents=True, exist_ok=True)
# img_dir = sorted(glob(folder_img+'/*.jpg'), key = lambda x: os.path.getmtime(x))
# min_ID = 100597
# for i in range(0, len(img_dir)):
def take_image_4_detect(folder_img, min_ID):
    target_path = folder_img + '_for_detect'
    Path(target_path).mkdir(parents=True, exist_ok=True)
    img_dir = sorted(glob(folder_img+'/*.jpg'), key = lambda x: os.path.getmtime(x))
    for (i, im_i) in enumerate(tqdm(img_dir, "loading:")):
        tmp_img = img_dir[i]
        # print(tmp_img)
        name = tmp_img.split('/')[-1].split('.')[0]
        # print(name)
        tmp_ID = name.split('_')[-1]
        # print(tmp_ID)
        if (int(tmp_ID)< int(min_ID)):
            shutil.copy2(tmp_img, target_path)

if __name__ == "__main__":
        
    parser = argparse.ArgumentParser("take_image_4_detect")
    parser.add_argument('--ilog', required=True, type=str)
    parser.add_argument('--min_ID', required=True, type=int)
    
    args = parser.parse_args()
    
    folder_img = args.ilog
    min_ID = args.min_ID
 
    
    take_image_4_detect(folder_img, min_ID)




