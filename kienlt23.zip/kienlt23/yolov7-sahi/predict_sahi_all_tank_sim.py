from sahi.utils.detectron2 import Detectron2TestConstants
from sahi import AutoDetectionModel
from sahi.predict import get_sliced_prediction, predict, get_prediction
from sahi.utils.file import download_from_url
from sahi.utils.cv import read_image
from IPython.display import Image

from sahi.utils.yolov7 import download_yolov7_model
from sahi import AutoDetectionModel
# import required functions, classes
# from sahi.models import AutoDetectionModel
from sahi.predict import get_sliced_prediction, predict, get_prediction
from sahi.utils.file import download_from_url
from sahi.utils.cv import read_image
from IPython.display import Image
from sahi.slicing import get_slice_bboxes
from util import glob_images_all_suffixes
import argparse
import logging
import os
import time
from typing import List, Optional
from sahi.utils.import_utils import is_available
if is_available("torch"):
    import torch
import numpy as np
from tqdm import tqdm
from sahi.auto_model import AutoDetectionModel
from sahi.models.base import DetectionModel
from sahi.postprocess.combine import (
    GreedyNMMPostprocess,
    LSNMSPostprocess,
    NMMPostprocess,
    NMSPostprocess,
    PostprocessPredictions,
)
from sahi.prediction import ObjectPrediction, PredictionResult
from sahi.slicing import slice_image
from sahi.utils.coco import Coco, CocoImage
from sahi.utils.cv import (
    IMAGE_EXTENSIONS,
    VIDEO_EXTENSIONS,
    crop_object_predictions,
    cv2,
    get_video_reader,
    read_image_as_pil,
    visualize_object_predictions,
)
from sahi.utils.file import Path, increment_path, list_files, save_json, save_pickle
from sahi.utils.import_utils import check_requirements
import glob
import matplotlib.pyplot as plt
import copy
import random

POSTPROCESS_NAME_TO_CLASS = {
    "GREEDYNMM": GreedyNMMPostprocess,
    "NMM": NMMPostprocess,
    "NMS": NMSPostprocess,
    "LSNMS": LSNMSPostprocess,
}

LOW_MODEL_CONFIDENCE = 0.1


logger = logging.getLogger(__name__)

model_type = "yolov7pip"
model_path = '/mnt/data/dattv13/projects/yolov7/runs/train/yolov7-tiny_ball_white_black_target32/weights/best.pt'
model_device = 'cuda:1'
model_confidence_threshold = 0.4
slice_height = 640
slice_width = 640
overlap_height_ratio = 0.2
overlap_width_ratio = 0.2
# source_image_dir = '/mnt/data/tuananh/data/00000028_clip2_w_sahi/512_440_1152_1080'

detection_model = AutoDetectionModel.from_pretrained(
    model_type=model_type,
    model_path=model_path,
    config_path=model_path,
    confidence_threshold=model_confidence_threshold,
    image_size=640,
#     device="cpu", # or 'cuda:0'
    device = model_device
)

#replace function, luu them cac anh crop
def get_sliced_prediction(
    image,
    detection_model=None,
    slice_height: int = None,
    slice_width: int = None,
    overlap_height_ratio: float = 0.2,
    overlap_width_ratio: float = 0.2,
    perform_standard_pred: bool = False, # parameter for predict large image or not
    postprocess_type: str = "GREEDYNMM",
    postprocess_match_metric: str = "IOS",
    postprocess_match_threshold: float = 0.5,
    postprocess_class_agnostic: bool = False,
    verbose: int = 1,
    merge_buffer_length: int = None,
    auto_slice_resolution: bool = True,
) -> PredictionResult:
    
    # for profiling
    durations_in_seconds = dict()

    # currently only 1 batch supported
    num_batch = 1

    # create slices from full image
    time_start = time.time()
    slice_image_result = slice_image(
        image=image,
        slice_height=slice_height,
        slice_width=slice_width,
        overlap_height_ratio=overlap_height_ratio,
        overlap_width_ratio=overlap_width_ratio,
        auto_slice_resolution=auto_slice_resolution,
    )
    num_slices = len(slice_image_result)
    time_end = time.time() - time_start
    durations_in_seconds["slice"] = time_end

    # init match postprocess instance
    if postprocess_type not in POSTPROCESS_NAME_TO_CLASS.keys():
        raise ValueError(
            f"postprocess_type should be one of {list(POSTPROCESS_NAME_TO_CLASS.keys())} but given as {postprocess_type}"
        )
    elif postprocess_type == "UNIONMERGE":
        # deprecated in v0.9.3
        raise ValueError("'UNIONMERGE' postprocess_type is deprecated, use 'GREEDYNMM' instead.")
    postprocess_constructor = POSTPROCESS_NAME_TO_CLASS[postprocess_type]
    postprocess = postprocess_constructor(
        match_threshold=postprocess_match_threshold,
        match_metric=postprocess_match_metric,
        class_agnostic=postprocess_class_agnostic,
    )

    # create prediction input
    num_group = int(num_slices / num_batch)
#     if verbose == 1 or verbose == 2:
#         tqdm.write(f"Performing prediction on {num_slices} number of slices.")
    object_prediction_list_slice_before_shift = {} #fix
    object_prediction_list = []
    prediction_result_slice_img = [] #fix
    #print(num_group)
    #cnt = 1#fix
    # perform sliced prediction
    shift_amount_list_more = [] #fix
    for group_ind in range(num_group):
        # prepare batch (currently supports only 1 batch)
        image_list = []
        shift_amount_list = []
        for image_ind in range(num_batch):
            image_list.append(slice_image_result.images[group_ind * num_batch + image_ind])
            shift_amount_list.append(slice_image_result.starting_pixels[group_ind * num_batch + image_ind])
            shift_amount_list_more.append(slice_image_result.starting_pixels[group_ind * num_batch + image_ind])
        # perform batch prediction
        prediction_result = get_prediction(
            image=image_list[0],
            detection_model=detection_model,
            shift_amount=shift_amount_list[0],
            full_shape=[
                slice_image_result.original_image_height,
                slice_image_result.original_image_width,
            ],
        )
        #prediction_result.export_visuals(export_dir=output_dir, file_name = file_name_crop + "_crop" + str(cnt))#fix
        #luu cac anh crop
        #         print(cnt)
        #cnt += 1#fix
        prediction_result_slice_img.append(prediction_result) #fix
        
        # convert sliced predictions to full predictions
        for object_prediction in prediction_result.object_prediction_list:
            if object_prediction:  # if not empty
                object_prediction_list_slice_before_shift[str(group_ind)]=object_prediction #fix
                object_prediction_list.append(object_prediction.get_shifted_object_prediction())

        # merge matching predictions during sliced prediction
        if merge_buffer_length is not None and len(object_prediction_list) > merge_buffer_length:
            object_prediction_list = postprocess(object_prediction_list)
    #print("Object predictin list slice before shift", object_prediction_list_slice_before_shift) #fix
    #print("Object prediction list after shift", object_prediction_list) #fix
    #print("num slice",num_slices) #fix
    # perform standard prediction
    if num_slices > 1 and perform_standard_pred:
        prediction_result = get_prediction(
            image=image,
            detection_model=detection_model,
            shift_amount=[0, 0],
            full_shape=None,
            postprocess=None,
        )
        object_prediction_list.extend(prediction_result.object_prediction_list)
    #print("Object prediction list after perform_standard_pred", object_prediction_list) #fix
    # merge matching predictions
    if len(object_prediction_list) > 1:
        object_prediction_list = postprocess(object_prediction_list)
    
    #print("Object prediction list after nms last time", object_prediction_list) #fix
    time_end = time.time() - time_start
    durations_in_seconds["prediction"] = time_end

    if verbose == 2:
        print(
            "Slicing performed in",
            durations_in_seconds["slice"],
            "seconds.",
        )
        print(
            "Prediction performed in",
            durations_in_seconds["prediction"],
            "seconds.",
        )

    return PredictionResult(
        image=image, object_prediction_list=object_prediction_list, durations_in_seconds=durations_in_seconds
    ), shift_amount_list_more, prediction_result_slice_img

def predict_all_slice_image_with_coordinate_label(path_from_folder, export_txt = False, export_score = False):
    lst_file = glob_images_all_suffixes(path_from_folder)
    #-------------Create new folder include image predict and label predict----------------------
    name_from_folder = path_from_folder.split("/")[-1]
    name_to_folder = name_from_folder + "_predict"
    path_to_folder = path_from_folder.replace(name_from_folder, name_to_folder)
    path_to_folder = path_to_folder + "/"
    #--------------------------------------------------------------------------------------------
    
    #------------Check folder exist, if exist create folder with new name else create folder-----
    isExist = os.path.exists(path_to_folder)
    if isExist:
        while True:
            random_number = random.randint(1, 10000)
            name_to_folder = name_from_folder + "_predict" + str(random_number)
            path_to_folder = path_from_folder.replace(name_from_folder, name_to_folder)
            path_to_folder = path_to_folder + "/"
            isExist = os.path.exists(path_to_folder)
            if isExist:
                continue
            else:
                Path(path_to_folder).mkdir(parents=True, exist_ok=True)
                print("New folder name:", name_to_folder)
                print("Create folder successfully")
                break
    else:
        Path(path_to_folder).mkdir(parents=True, exist_ok=True)
        print("Folder not exist, create new origin folder: ", path_to_folder)
    #--------------------------------------------------------------------------------------------
    
    #-----------------------Create label_predict folder--------------------------------------------------
    path_sub_new_folder_label = ""
    if export_txt:
        path_sub_new_folder_label = path_to_folder + "label_predict"
        Path(path_sub_new_folder_label).mkdir(parents=True, exist_ok=True)
    #--------------------------------------------------------------------------------------------
    
    count_file_predict = 0
    for file in lst_file:
        #------------------Create image_predict folder and all folder contain each oririn iamge and slice image-----
        image_pil = read_image_as_pil(file)
        image_width, image_height= image_pil.size
        # file_split1 = file.split(".")
        # file_split_name_img = file_split1[0].split("/")[-1]
        file_split_name_img = file[:file.rindex(".")].split("/")[-1]
#         path_sub_new_folder_image = path_to_folder + "image_predict"
#         path_sub_new_folder = path_sub_new_folder_image + "/" + file_split_name_img
#         Path(path_sub_new_folder).mkdir(parents=True, exist_ok=True) 
        #------------------------------------------------------------------------------------------------------
        
        #-----------Take and convert slice bbox to string------------
        slice_bboxes = get_slice_bboxes(image_height=image_height,
                                            image_width=image_width,
                                            auto_slice_resolution=True,
                                            slice_height=slice_height,
                                            slice_width=slice_width,
                                            overlap_height_ratio=0.2,
                                            overlap_width_ratio=0.2,)
        slice_bboxes_str = []
        for boxes in slice_bboxes:
            new_boxes = [str(element) for element in boxes]
            slice_bboxes_str.append("_".join(new_boxes))
        #-----------------------------------------------------------
        
        #----------------Perdict and save crop image-----------------
        result, shift_amount_lst, prediction_result_slice_img = get_sliced_prediction(file, detection_model,
                                                                                        slice_height = slice_height,
                                                                                        slice_width = slice_width,
                                                                                        overlap_height_ratio = 0.2,
                                                                                        overlap_width_ratio = 0.2,)
        
#         for i in range(len(prediction_result_slice_img)):
#             path_file_name_crop = path_sub_new_folder + "/" + file_split_name_img + "_" + slice_bboxes_str[i]
#             prediction_result_slice_img[i].export_visuals(export_dir=path_sub_new_folder, file_name = path_file_name_crop)
        #-------------------------------------------------------------
        
        #-----------------Save origin image---------------------------
#         path_file_name_all = path_sub_new_folder + "/" + file_split_name_img + "_predict_all"
#         result.export_visuals(export_dir=path_sub_new_folder, file_name = path_file_name_all)
#         #-------------------------------------------------------------
        
        #----------------Save label of image in file txt--------------
        if export_txt:
            #---------Create label_with_score folder include confident score in file txt---------
            if export_score:
                path_sub1_new_folder_label = path_sub_new_folder_label + "/" + "label_with_score"
                Path(path_sub1_new_folder_label).mkdir(parents=True, exist_ok=True)
                
#                 path_file_name_txt_score = path_sub1_new_folder_label + "/" + file_split_name_img + "_predict_all_score.txt"
                path_file_name_txt_score = path_sub1_new_folder_label + "/" + file_split_name_img + ".txt"
                boxes_object_score = []
                for object_predict in result.object_prediction_list:
                    boxes = object_predict.bbox.to_xyxy()
                    boxes_center = []
                    boxes.insert(0, object_predict.category.id)
                    boxes[1] = boxes[1] / image_width
                    boxes[2] = boxes[2] / image_height
                    boxes[3] = boxes[3] / image_width
                    boxes[4] = boxes[4] / image_height

                    boxes_center.append(boxes[0])
                    boxes_center.append(round((boxes[1] + boxes[3]) / 2, 6))
                    boxes_center.append(round((boxes[2] + boxes[4]) / 2, 6))
                    boxes_center.append(round(boxes[3] - boxes[1], 6))
                    boxes_center.append(round(boxes[4] - boxes[2], 6))
                    boxes_center.append(round(object_predict.score.value, 6))

                    
                    boxes_center = [str(element) for element in boxes_center]
                    boxes_center = " ".join(boxes_center)
                    boxes_center = boxes_center + "\n"
                    boxes_object_score.append(boxes_center)
                    
                    with open(path_file_name_txt_score, "w") as f:
                        f.writelines(boxes_object_score)
            #----------------------------------------------------------------------------------
            
            #-----Create label_no_score folder with no confident score in file txt and origin image predict correspond        
            path_sub2_new_folder_label = path_sub_new_folder_label + "/" + "label_no_score"
            Path(path_sub2_new_folder_label).mkdir(parents=True, exist_ok=True)
            
            path_file_name_all_copy = path_sub2_new_folder_label + "/" + file_split_name_img
            result.export_visuals(export_dir=path_sub2_new_folder_label, file_name = path_file_name_all_copy)
            
#             path_file_name_txt_no_score = path_sub2_new_folder_label + "/" + file_split_name_img + "_predict_all.txt"
            path_file_name_txt_no_score = path_sub2_new_folder_label + "/" + file_split_name_img + ".txt"
            boxes_object_no_score = []
            for object_predict in result.object_prediction_list:
                boxes = object_predict.bbox.to_xyxy()
                boxes_center = []
                boxes.insert(0, object_predict.category.id)
                boxes[1] = boxes[1] / image_width
                boxes[2] = boxes[2] / image_height
                boxes[3] = boxes[3] / image_width
                boxes[4] = boxes[4] / image_height

                boxes_center.append(boxes[0])
                boxes_center.append(round((boxes[1] + boxes[3]) / 2, 6))
                boxes_center.append(round((boxes[2] + boxes[4]) / 2, 6))
                boxes_center.append(round(boxes[3] - boxes[1], 6))
                boxes_center.append(round(boxes[4] - boxes[2], 6))


                boxes_center = [str(element) for element in boxes_center]
                boxes_center = " ".join(boxes_center)
                boxes_center = boxes_center + "\n"
                boxes_object_no_score.append(boxes_center)
            
            with open(path_file_name_txt_no_score, "w") as f:
                    f.writelines(boxes_object_no_score)
            #----------------------------------------------------------------------------------------
        count_file_predict += 1
#         print("Number of image is predicting", count_file_predict)
        
    
    print("Number of file predict is:", count_file_predict)
    print("Done")

    
if __name__ == "__main__":
    
    parser = argparse.ArgumentParser("Export Results")
    parser.add_argument('--log', required=True, type=str)
    # parser.add_argument('--gt', required=True, type=str)
    # parser.add_argument('--out', required=True, type=str)
    # parser.add_argument('--iou_thresh', type=float, default=0.01)
    # parser.add_argument('--contrast_thresh', type=float, default=0.2)
    # parser.add_argument('--cen_diff_thresh', type=float, default=0.3)
    args = parser.parse_args()
    # file_path, ground_file, target_file, threshold_iou, contrast_threshold, threshold_error_center = args.log, args.gt, args.out, args.iou_thresh, args.contrast_thresh, args.cen_diff_thresh
#     export_results(file_path, ground_file, target_file, threshold_iou, contrast_threshold, threshold_error_center)
    
    # parser = argparse.ArgumentParser("Detect")
    # parser.add_argument('--log', required=True, type=str)
    # args = parser.parse_args()
    path_from_folder = args.log
#     path_from_folder = '/home/temp_data/tank_sb_916_T24_00000004_07_03_clip5'  
    # path_from_folder = '/home/temp_data/AQOO8583'
    predict_all_slice_image_with_coordinate_label(path_from_folder, 
                                              export_txt = True,
                                             export_score = True)




