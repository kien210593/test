## Some tools
- `auto_full_RGB.sh`: run extract frame, detect and compare detected result with tracking result;
- `bdc_log_plotly.ipynb`: draw plot from bdc log using plotly;

Install environment below before run these tools.

## Environment
Requirements: `yolo_ai_test.txt`

Activate `yolo_ai_test` before run any file.

## Detail explaination
- `0_Cut_clip_to_subclip_v1.ipynb`: Manually cut long video to subclips via frame IDs or time;
- `1_Extract_frame_v1.py`: auto extract video frames with name at format: `frame_<barcode>.jpg`;
- `2_0_read_file_seeker_v1.py`: read ip log & find start tracking (mouse clicked) frame ID, copy tracking frames into new folder;
- `2_1_take_image_for_detect.py`: copy frames before tracking into new folder;
- `predict_sahi_all_tank_sim.py`: perform predict with SAHI;
- `2_2_compare_track_w_predict_v2.py`: compare prediction vs tracking result, return false negative & false positve predicted frames;
- `3_0_resize_to_predict_v2.py`: perform 2 time scaling;
- `3_1_check_size.py`: filter out small objects to predict;
- `0_1_test_confusion_matrix_ver7.py`: calc confusion matrix of scaled prediction and scaled tracking result;
- `4_compute_error_box_center_v1.py`: compute center distance between prediction vs tracking result;
- `5_draw.py`: plot center distance and height wrt frame ID;
- `6_cp_contrast.py`: compute contrast of predicted objects;
- `7_reverse_tracking_for_detect.py`: perform reverse tracking (track from clicked frame to video starting frame) to get tracking result;
