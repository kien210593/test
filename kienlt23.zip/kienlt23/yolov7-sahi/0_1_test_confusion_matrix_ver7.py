import numpy as np
import seaborn as sns
import os
import matplotlib.pyplot as plt
import glob
import cv2
import pandas as pd
from pathlib import Path
import re
from tqdm import tqdm
import argparse
import shutil

def processing_bounding_box(arr_box):
    process_box = []
    for box in arr_box:
        boxes = box[0].split(" ")
        boxes1 = [float(ele) for ele in boxes]
        boxes1[0] = int(boxes[0])
        process_box.append(boxes1)
    return process_box


def xywh2xyxy(arr_box, width, height):
    '''
    Arguments:
        arr_box (Array[N, 5]) (class, x1_center_norm, y1_center_norm, w_norm, h_norm)
    Returns:
        arr (Array[N, 5]): (class, x1, y1, x2, y2)
    '''
    box_convert = []
    for box in arr_box:
        box1 = []
        box1.append(box[0])
        x_left = box[1] - (box[3] / 2)
        x_left = int(x_left * width)
        y_left = box[2] - (box[4] / 2)
        y_left = int(y_left * height)
        x_right = box[1] + (box[3] / 2)
        x_right = int(x_right * width)
        y_right = box[2] + (box[4] / 2)
        y_right = int(y_right * height)

        box1.append(x_left)
        box1.append(y_left)
        box1.append(x_right)
        box1.append(y_right)
        box_convert.append(box1)
    return box_convert

def xywh2xyxy_score(arr_box, width, height):
    '''
    Arguments:
        arr_box (Array[N, 6]) (class, x1_center_norm, y1_center_norm, w_norm, h_norm, conf)
    Returns:
        arr (Array[N, 6]): (class, x1, y1, x2, y2, conf)
    '''
    box_convert = []
    for box in arr_box:
        box1 = []
        box1.append(box[0])
        x_left = box[1] - (box[3] / 2)
        x_left = int(x_left * width)
        y_left = box[2] - (box[4] / 2)
        y_left = int(y_left * height)
        x_right = box[1] + (box[3] / 2)
        x_right = int(x_right * width)
        y_right = box[2] + (box[4] / 2)
        y_right = int(y_right * height)

        box1.append(x_left)
        box1.append(y_left)
        box1.append(x_right)
        box1.append(y_right)
        box1.append(round(box[5], 2))
        box_convert.append(box1)
    return box_convert

def xyxy2strxywh(arr_box, width, height):
    '''
    Arguments:
        arr_box (Array[N, 6]) (class, x1, y1, x2, y2, conf)
    Returns:
        arr (List[N]): (string(class, x_center_norm, y_center_norm, w_norm, h_norm, conf, \n))
    '''
    list_boxes_center = []
    if len(arr_box) <= 0:
        return list_boxes_center
    for boxes in arr_box:
        boxes_center = []
        boxes_center.append(str(boxes[0]))
        boxes_center.append(str(round(((boxes[1] / width) + (boxes[3] / width)) / 2, 6)))
        boxes_center.append(str(round(((boxes[2] / height) + (boxes[4] / height)) / 2, 6)))
        boxes_center.append(str(round(((boxes[3] / width) - (boxes[1] / width)), 6)))
        boxes_center.append(str(round(((boxes[4] / height) - (boxes[2] / height)), 6)))
        if len(boxes) == 6:
            boxes_center.append(str(boxes[5]))
        boxes_center.append("\n")
        str_box = " ".join(boxes_center)
        list_boxes_center.append(str_box)
    return list_boxes_center

def box_iou_calc(boxes1, boxes2):
    """
    Return intersection-over-union (Jaccard index) of boxes.
    Both sets of boxes are expected to be in (x1, y1, x2, y2) format.
    Arguments:
        boxes1 (Array[N, 4]) (x1, y1, x2, y2)
        boxes2 (Array[M, 4]) (x1, y1, x2, y2)
    Returns:
        iou (Array[N, M]): the NxM matrix containing the pairwise
            IoU values for every element in boxes1 and boxes2
    """
    def box_area(box):
        return (box[2] - box[0]) * (box[3] - box[1])

    area1 = box_area(boxes1.T)
    area2 = box_area(boxes2.T)

    lt = np.maximum(boxes1[:, None, :2], boxes2[:, :2])  # [N,M,2]
    rb = np.minimum(boxes1[:, None, 2:], boxes2[:, 2:])  # [N,M,2]

    inter = np.prod(np.clip(rb - lt, a_min=0, a_max=None), 2)
    return inter / (area1[:, None] + area2 - inter)  # iou = inter / (area1 + area2 - inter)

def create_subfolder_dict(classes):
    '''
        Arguments:
            classes (List[N]): "human", "car", "bicycle"
        Returns:
            List[N]: "human_car", "human_bicycle", "human_FN", "car_human", "car_bicycle".........
            Dict: {"human_car": [], "human_bicycle": [], "human_FN": [], "car_human": [], .....}
    '''
    name_subfolder_list = []
    new_class = classes.copy()
    new_class.append("FN")
    dict_subfolder = {}
    for i in range(len(new_class)):
        if i == len(new_class) - 1:
            name = "FP"
            for j in range(len(new_class)-1):
                name_subfolder_list.append(name + "_" + new_class[j])
                dict_subfolder[name + "_" + new_class[j]] = []
        else:
            for j in range(len(new_class)):
                    name_subfolder_list.append(new_class[i] + "_" + new_class[j])
                    dict_subfolder[new_class[i] + "_" + new_class[j]] = []
    
    return name_subfolder_list, dict_subfolder

class ConfusionMatrix:
    def __init__(self, classes, CONF_THRESHOLD=0.3, IOU_THRESHOLD=0.5):
        self.num_classes = len(classes)
        self.matrix = np.zeros((self.num_classes + 1, self.num_classes + 1))
        self.matrix1010 = np.zeros((self.num_classes + 1, self.num_classes + 1))
        self.matrix1515 = np.zeros((self.num_classes + 1, self.num_classes + 1))
        self.matrix3232 = np.zeros((self.num_classes + 1, self.num_classes + 1))
        self.matrix6464 = np.zeros((self.num_classes + 1, self.num_classes + 1))
        self.matrix6565 = np.zeros((self.num_classes + 1, self.num_classes + 1))

        self.dictname1010 = create_subfolder_dict(classes)[1]
        self.dictname1515 = create_subfolder_dict(classes)[1]
        self.dictname3232 = create_subfolder_dict(classes)[1]
        self.dictname6464 = create_subfolder_dict(classes)[1]
        self.dictname6565 = create_subfolder_dict(classes)[1]
        self.dictname = create_subfolder_dict(classes)[1]

        self.CONF_THRESHOLD = CONF_THRESHOLD
        self.IOU_THRESHOLD = IOU_THRESHOLD
        self.classes = classes

    def process_batch(self, detections, labels: np.ndarray):
        '''
        Arguments:
            detections (Array[N, 6]), class, x1, y1, x2, y2, conf
            labels (Array[M, 5]), class, x1, y1, x2, y2
        Returns:
            None, updates confusion matrix accordingly
        '''
        labels_copy = labels.copy()
        if len(labels)==0:
            if len(detections)==0:
                return
            elif len(detections) > 0:
                detections = detections[detections[:, 5] > self.CONF_THRESHOLD]
                detection_classes = detections[:, 0].astype(np.int16)
                for i, detection in enumerate(detections):
                    detection_class = detection_classes[i]
                    self.matrix[detection_class, self.num_classes] += 1

                    excess_detect =  detection
                    excess_detect = excess_detect.tolist()
                    excess_detect[0] = len(self.classes) + 2
                    gt_label = "FP"
                    detection_label = self.classes[detection_class]
                    name_dct = gt_label + "_" + detection_label
                    self.dictname[name_dct].append(excess_detect)

                    area = (detection[3]-detection[1])*(detection[4]-detection[2])
                    if 0<=area<100:
                        self.matrix1010[detection_class, self.num_classes] += 1
                        self.dictname1010[name_dct].append(excess_detect)
                    elif 100<=area<225:
                        self.matrix1515[detection_class, self.num_classes] += 1
                        self.dictname1515[name_dct].append(excess_detect)
                    elif 225<=area<1024:
                        self.matrix3232[detection_class, self.num_classes] += 1
                        self.dictname3232[name_dct].append(excess_detect)
                    elif 1024<=area<4096:
                        self.matrix6464[detection_class, self.num_classes] += 1
                        self.dictname6464[name_dct].append(excess_detect)
                    elif area>=4096:
                        self.matrix6565[detection_class, self.num_classes] += 1
                        self.dictname6565[name_dct].append(excess_detect)
                return
        else:
            gt_classes = labels[:, 0].astype(np.int16) #lay ra nhan cua ground truth
            try:
                #loc ra nhung pred boundingbox co conf score > conf_threshold
                detections = detections[detections[:, 5] > self.CONF_THRESHOLD]
            except IndexError or TypeError:
                # detections are empty, end of process
                #Bo qua neu detection bi trong, empty
                for i, label in enumerate(labels):
                    gt_class = gt_classes[i]
                    self.matrix[self.num_classes, gt_class] += 1

                    missing_truth = label
                    missing_truth = missing_truth.tolist()
                    missing_truth[0] = len(self.classes) + 1
                    gt_label = self.classes[gt_class]
                    detection_label = "FN"
                    name_dct = gt_label + "_" + detection_label
                    self.dictname[name_dct].append(missing_truth)

                    area = (label[3]-label[1])*(label[4]-label[2])
                    if 0<=area<100:
                        self.matrix1010[self.num_classes, gt_class] += 1
                        self.dictname1010[name_dct].append(missing_truth)
                    elif 100<=area<225:
                        self.matrix1515[self.num_classes, gt_class] += 1
                        self.dictname1515[name_dct].append(missing_truth)
                    elif 225<=area<1024:
                        self.matrix3232[self.num_classes, gt_class] += 1
                        self.dictname3232[name_dct].append(missing_truth)
                    elif 1024<=area<4096:
                        self.matrix6464[self.num_classes, gt_class] += 1
                        self.dictname6464[name_dct].append(missing_truth)
                    elif area>=4096:
                        self.matrix6565[self.num_classes, gt_class] += 1
                        self.dictname6565[name_dct].append(missing_truth)
                return

            detection_classes = detections[:, 0].astype(np.int16) #lay ra nhan cua pred bounding box

            #tinh iou giua ground truth va pred bounding box
            all_ious = box_iou_calc(labels[:, 1:], detections[:, 1:5])
            #lay ra index cua nhung pred boundingbox > iou_threshold
            want_idx = np.where(all_ious > self.IOU_THRESHOLD)
            all_matches = [[want_idx[0][i], want_idx[1][i], all_ious[want_idx[0][i], want_idx[1][i]]]
                        for i in range(want_idx[0].shape[0])]

            all_matches = np.array(all_matches)
            if all_matches.shape[0] > 0:  # if there is match
                #sap xep va khi co 1 pred bouding box deu thoa man ca 2 ground truth thi chi 
                #cho pred bounding box day thuoc ve ground truth nao co conf_score lon hon
                all_matches = all_matches[all_matches[:, 2].argsort()[::-1]]
                all_matches = all_matches[np.unique(all_matches[:, 1], return_index=True)[1]]

                #sap xep va khi co 2 pred bounding box deu thoa man khi du doan 1 ground truth
                #thi chon pred bounding box co conf_score lon hon
                all_matches = all_matches[all_matches[:, 2].argsort()[::-1]]
                all_matches = all_matches[np.unique(all_matches[:, 0], return_index=True)[1]]

            for i, label in enumerate(labels):
                gt_class = gt_classes[i]
                if all_matches.shape[0] > 0 and all_matches[all_matches[:, 0] == i].shape[0] == 1:
                    detection_class = detection_classes[int(all_matches[all_matches[:, 0] == i, 1][0])]
                    self.matrix[detection_class, gt_class] += 1
                    if detection_class != gt_class:
                        wrong_detect =  detections[int(all_matches[all_matches[:, 0] == i, 1][0]), :]
                        wrong_detect = wrong_detect.tolist()
                        wrong_detect[0] = len(self.classes)
                        detection_label = self.classes[detection_class]
                        gt_label = self.classes[gt_class]
                        name_dct = gt_label + "_" + detection_label
                        self.dictname[name_dct].append(wrong_detect)
                        area = (label[3]-label[1])*(label[4]-label[2])
                        if 0<=area<100:
                            self.matrix1010[detection_class, gt_class] += 1
                            self.dictname1010[name_dct].append(wrong_detect)
                        elif 100<=area<225:
                            self.matrix1515[detection_class, gt_class] += 1
                            self.dictname1515[name_dct].append(wrong_detect)
                        elif 225<=area<1024:
                            self.matrix3232[detection_class, gt_class] += 1
                            self.dictname3232[name_dct].append(wrong_detect)
                        elif 1024<=area<4096:
                            self.matrix6464[detection_class, gt_class] += 1
                            self.dictname6464[name_dct].append(wrong_detect)
                        elif area>=4096:
                            self.matrix6565[detection_class, gt_class] += 1
                            self.dictname6565[name_dct].append(wrong_detect)
                    else:
                        true_detection = detections[int(all_matches[all_matches[:, 0] == i, 1][0]), :]
                        true_detection = true_detection.tolist()
                        #true_detection[0] = gt_class + 3 + len(self.classes)
                        true_detection[0] = gt_class + len(self.classes)
                        true_label = label
                        true_label = true_label.tolist()
                        detection_label = self.classes[detection_class]
                        gt_label = self.classes[gt_class]
                        name_dct = gt_label + "_" + detection_label
                        self.dictname[name_dct].append(true_label)
                        self.dictname[name_dct].append(true_detection)

                        area = (label[3]-label[1])*(label[4]-label[2])
                        if 0<=area<100:
                            self.matrix1010[detection_class, gt_class] += 1
                            self.dictname1010[name_dct].append(true_label)
                            self.dictname1010[name_dct].append(true_detection)
                        elif 100<=area<225:
                            self.matrix1515[detection_class, gt_class] += 1
                            self.dictname1515[name_dct].append(true_label)
                            self.dictname1515[name_dct].append(true_detection)
                        elif 225<=area<1024:
                            self.matrix3232[detection_class, gt_class] += 1
                            self.dictname3232[name_dct].append(true_label)
                            self.dictname3232[name_dct].append(true_detection)
                        elif 1024<=area<4096:
                            self.matrix6464[detection_class, gt_class] += 1
                            self.dictname6464[name_dct].append(true_label)
                            self.dictname6464[name_dct].append(true_detection)
                        elif area>=4096:
                            self.matrix6565[detection_class, gt_class] += 1
                            self.dictname6565[name_dct].append(true_label)
                            self.dictname6565[name_dct].append(true_detection)
                else:
                    #FN, nhung ground truth nhung khong co pred bounding box du doan tai vi tri do
                    self.matrix[self.num_classes, gt_class] += 1

                    missing_truth =  label
                    missing_truth = missing_truth.tolist()
                    missing_truth[0] = len(self.classes) + 1
                    gt_label = self.classes[gt_class]
                    detection_label = "FN"
                    name_dct = gt_label + "_" + detection_label
                    self.dictname[name_dct].append(missing_truth)

                    area = (label[3]-label[1])*(label[4]-label[2])
                    if 0<=area<100:
                        self.matrix1010[self.num_classes, gt_class] += 1
                        self.dictname1010[name_dct].append(missing_truth)
                    elif 100<=area<225:
                        self.matrix1515[self.num_classes, gt_class] += 1
                        self.dictname1515[name_dct].append(missing_truth)
                    elif 225<=area<1024:
                        self.matrix3232[self.num_classes, gt_class] += 1
                        self.dictname3232[name_dct].append(missing_truth)
                    elif 1024<=area<4096:
                        self.matrix6464[self.num_classes, gt_class] += 1
                        self.dictname6464[name_dct].append(missing_truth)
                    elif area>=4096:
                        self.matrix6565[self.num_classes, gt_class] += 1
                        self.dictname6565[name_dct].append(missing_truth)

            for i, detection in enumerate(detections):
                #FP, la nhung pred boundingbox du doan tai vi tri do nhung ko co ground truth tai vi tri do
                if not all_matches.shape[0] or ( all_matches.shape[0] and all_matches[all_matches[:, 1] == i].shape[0] == 0 ):
                    detection_class = detection_classes[i]
                    self.matrix[detection_class, self.num_classes] += 1

                    
                    excess_detect =  detection
                    excess_detect = excess_detect.tolist()
                    ##cy
                    excess_detect[0] = len(self.classes) + 2
                    gt_label = "FP"
                    detection_label = self.classes[detection_class]
                    name_dct = gt_label + "_" + detection_label
                    self.dictname[name_dct].append(excess_detect)

                    area = (detection[3]-detection[1])*(detection[4]-detection[2])
                    if 0<=area<100:
                        self.matrix1010[detection_class, self.num_classes] += 1
                        self.dictname1010[name_dct].append(excess_detect)
                    elif 100<=area<225:
                        self.matrix1515[detection_class, self.num_classes] += 1
                        self.dictname1515[name_dct].append(excess_detect)
                    elif 225<=area<1024:
                        self.matrix3232[detection_class, self.num_classes] += 1
                        self.dictname3232[name_dct].append(excess_detect)
                    elif 1024<=area<4096:
                        self.matrix6464[detection_class, self.num_classes] += 1
                        self.dictname6464[name_dct].append(excess_detect)
                    elif area>=4096:
                        self.matrix6565[detection_class, self.num_classes] += 1
                        self.dictname6565[name_dct].append(excess_detect)
                
    def return_matrix(self):
        '''
        Returns: (Array[n_classes, n_classes])
        '''
        return self.matrix1010, self.matrix1515, self.matrix3232, self.matrix6464, self.matrix6565, self.matrix

    def print_matrix(self):
        for i in range(self.num_classes + 1):
            print(' '.join(map(str, self.matrix[i])))

    def return_dict(self):
        return self.dictname1010, self.dictname1515, self.dictname3232, self.dictname6464, self.dictname6565, self.dictname
    
def read_file_to_array(groudth_path_txt, predict_path_txt, origin_image):
    '''
        Returns:
            truth_txt_after_class0_all: List[np.array]: [np.array([classes, x1, y1, x2, y2])]
            predict_txt_after_class0_all: List[np.array]: [np.array([classes, x1, y1, x2, y2, score])]
            name_img_list: List[N]: ["0000021_00500_d_0000002", ....]
            wh: List[tuple()]: [(960, 540), ..........]
    '''

    path_origin_image = origin_image + "/*.jpg"
    list_img_folder = sorted(glob.glob(path_origin_image))
    # print(len(list_img_folder))
    truth_txt_after_class0_all = []
    predict_txt_after_class0_all = []
    name_img_list = []
    wh = []
    length_truth, length_predict = 0, 0
    for i in range(len(list_img_folder)):
        #-------take only one path in list-----------
        img_path1 = list_img_folder[i]
        name_img = img_path1.split("/")[-1].split(".")[0]
        truth_path_txt = groudth_path_txt + "/" + name_img +".txt"
        pred_path_txt = predict_path_txt + "/" + name_img + ".txt"
        pred_path_txt1 = predict_path_txt + "/" + name_img + "_predict_all_score" + ".txt"
        exist_truth = os.path.exists(truth_path_txt) and os.path.getsize(truth_path_txt) > 0
        exist_pred = os.path.exists(pred_path_txt) and os.path.getsize(pred_path_txt) > 0
        exist_pred1 = os.path.exists(pred_path_txt1) and os.path.getsize(pred_path_txt1) > 0
        if exist_truth and (exist_pred or exist_pred1):
            if exist_pred:
                # print('img_path1:', img_path1)
                img1 = cv2.imread(img_path1)
                truth_txt = pd.read_csv(truth_path_txt, header=None)
                predict_txt = pd.read_csv(pred_path_txt, header=None)
                truth_txt = truth_txt.to_numpy()
                predict_txt = predict_txt.to_numpy()
                if len(truth_txt) == 0:
                    print("File truth empty:", name_img)
                if len(predict_txt) == 0:
                    print("File pred empty:", name_img)
                height, width = img1.shape[0:2]

                truth_txt_after = processing_bounding_box(truth_txt)
                predict_txt_after = processing_bounding_box(predict_txt)
                truth_txt_after = xywh2xyxy(truth_txt_after, width, height)
                predict_txt_after = xywh2xyxy_score(predict_txt_after, width, height)
                truth_txt_after = np.array(truth_txt_after)
                predict_txt_after = np.array(predict_txt_after)

                truth_txt_after_class0_all.append(truth_txt_after)
                predict_txt_after_class0_all.append(predict_txt_after)
                name_img_list.append(name_img)
                wh.append((width,height))
                length_truth += len(truth_txt_after)
                length_predict += len(predict_txt_after)
            elif exist_pred1:
                img1 = cv2.imread(img_path1)
                truth_txt = pd.read_csv(truth_path_txt, header=None)
                predict_txt = pd.read_csv(pred_path_txt1, header=None)
                truth_txt = truth_txt.to_numpy()
                predict_txt = predict_txt.to_numpy()
                if len(truth_txt) == 0:
                    print("File truth empty:", name_img)
                if len(predict_txt) == 0:
                    print("File pred empty:", name_img)
                height, width = img1.shape[0:2]

                truth_txt_after = processing_bounding_box(truth_txt)
                predict_txt_after = processing_bounding_box(predict_txt)
                truth_txt_after = xywh2xyxy(truth_txt_after, width, height)
                predict_txt_after = xywh2xyxy_score(predict_txt_after, width, height)
                truth_txt_after = np.array(truth_txt_after)
                predict_txt_after = np.array(predict_txt_after)

                truth_txt_after_class0_all.append(truth_txt_after)
                predict_txt_after_class0_all.append(predict_txt_after)
                name_img_list.append(name_img)
                wh.append((width,height))
                length_truth += len(truth_txt_after)
                length_predict += len(predict_txt_after)
        elif exist_truth == True and exist_pred == False and exist_pred1 == False:
            img1 = cv2.imread(img_path1)
            height, width = img1.shape[0:2]
            truth_txt = pd.read_csv(truth_path_txt, header=None)
            truth_txt = truth_txt.to_numpy()
            truth_txt_after = processing_bounding_box(truth_txt)
            truth_txt_after = xywh2xyxy(truth_txt_after, width, height)
            truth_txt_after = np.array(truth_txt_after)

            predict_txt_after = np.array([])
            truth_txt_after_class0_all.append(truth_txt_after)
            predict_txt_after_class0_all.append(predict_txt_after)
            name_img_list.append(name_img)
            wh.append((width,height))
            length_truth += len(truth_txt_after)
            length_predict += len(predict_txt_after)
        else:
            continue
    assert len(truth_txt_after_class0_all) == len(predict_txt_after_class0_all) == len(name_img_list) == len(wh), "Length is not equal"
    return truth_txt_after_class0_all, predict_txt_after_class0_all, name_img_list, wh, length_truth, length_predict    

def compute_confusion_matrix(gt_label, detect, classes, conf_score, iou_score):
    cfm=ConfusionMatrix(classes, conf_score, iou_score)
    cfm.process_batch(detect, gt_label)
    mat1010, mat1515, mat3232, mat6464, mat6565, mat = cfm.return_matrix()
    dct1010, dct1515, dct3232, dct6464, dct6565, dct = cfm.return_dict()
    return mat1010, mat1515, mat3232, mat6464, mat6565, mat,\
            dct1010, dct1515, dct3232, dct6464, dct6565, dct

def draw_confusion_matrix(matric, matric_percent, conf, iou, classes):
    '''
        Arguments:
            matric: (Array[n_class, n_class])
            matric_percent: (Array[n_class, n_class])
        Returns:
            fig: figure of confusion matrix
    '''
    nc = len(classes)
    labels = True
    fig1 = plt.figure(figsize=(7, 7), tight_layout=True)
    sns.set(font_scale=1.0 if nc < 50 else 0.8)
    sns.heatmap(matric, annot=nc < 30, annot_kws={"size": 8}, cmap='Blues', fmt='.0f', square=True,
                xticklabels=classes + ['background FP'] if labels else "auto",
                yticklabels=classes + ['background FN'] if labels else "auto").set_facecolor((1, 1, 1))
    fig1.axes[0].set_xlabel('True')
    fig1.axes[0].set_ylabel('Predicted')
    fig1.suptitle(f'confident_score:{conf}, iou_score:{iou}')
    
    fig2 = plt.figure(figsize=(7, 7), tight_layout=True)
    sns.set(font_scale=1.0 if nc < 50 else 0.8)
    sns.heatmap(matric_percent, annot=nc < 30, annot_kws={"size": 8}, cmap='Blues', fmt='.2f', square=True,
                xticklabels=classes + ['background FP'] if labels else "auto",
                yticklabels=classes + ['background FN'] if labels else "auto").set_facecolor((1, 1, 1))
    fig2.axes[0].set_xlabel('True')
    fig2.axes[0].set_ylabel('Predicted')
    fig2.suptitle(f'confident_score:{conf}, iou_score:{iou}')

    return fig1, fig2

def increment_path(path, exist_ok=True, sep=''):
    # Increment path, i.e. runs/exp --> runs/exp{sep}0, runs/exp{sep}1 etc.
    path = Path(path)  # os-agnostic
    if (path.exists() and exist_ok) or (not path.exists()):
        return str(path)
    else:
        dirs = glob.glob(f"{path}{sep}*")  # similar paths
        matches = [re.search(rf"%s{sep}(\d+)" % path.stem, d) for d in dirs]
        i = [int(m.groups()[0]) for m in matches if m]  # indices
        n = max(i) + 1 if i else 2  # increment number
        return f"{path}{sep}{n}"  # update path
    
def save_confusion_matrix_v1(groudth_path_txt, predict_path_txt, origin_image, conf_score, iou_score, classes):
    gt_label, detect, name_file, wh, lt, lpr = read_file_to_array(groudth_path_txt, predict_path_txt, origin_image)
    nc = len(classes)
    matrix1010 = np.zeros((nc + 1, nc + 1))
    matrix1515 = np.zeros((nc + 1, nc + 1))
    matrix3232 = np.zeros((nc + 1, nc + 1))
    matrix6464 = np.zeros((nc + 1, nc + 1))
    matrix6565 = np.zeros((nc + 1, nc + 1))
    matrix = np.zeros((nc + 1, nc + 1))

    name_subfolder_list = create_subfolder_dict(classes)[0]
    
    # print("predict_path_txt:", predict_path_txt)
    # print(predict_path_txt.split("/")[-1]+"_cfm")
    # save_dir = "/".join(predict_path_txt.split("/")[:-1]) + "/" + "plot_confusion_matrix"
    save_dir = "/".join(predict_path_txt.split("/")[:-1]) + "/" + predict_path_txt.split("/")[-1]+"_cfm"
    
    save_dir = increment_path(save_dir, exist_ok=False)
    Path(save_dir).mkdir(parents=True, exist_ok=True)
    save_dir1010 = save_dir + "/area1010"
    Path(save_dir1010).mkdir(parents=True, exist_ok=True)
    save_dir1515 = save_dir + "/area1515"
    Path(save_dir1515).mkdir(parents=True, exist_ok=True)
    save_dir3232 = save_dir + "/area3232"
    Path(save_dir3232).mkdir(parents=True, exist_ok=True)
    save_dir6464 = save_dir + "/area6464"
    Path(save_dir6464).mkdir(parents=True, exist_ok=True)
    save_dir6565 = save_dir + "/area_other"
    Path(save_dir6565).mkdir(parents=True, exist_ok=True)
    save_dirall = save_dir + "/area"
    Path(save_dirall).mkdir(parents=True, exist_ok=True)
    
    save_dir_image = save_dir + "/image_cfm"
    Path(save_dir_image).mkdir(parents=True, exist_ok=True)


    save_dir_list = [save_dir1010, save_dir1515, save_dir3232, save_dir6464, save_dir6565, save_dirall]
    for folder in save_dir_list:
        for name_subfolder in name_subfolder_list:
            path_subfolder = folder + "/" + name_subfolder
            Path(path_subfolder).mkdir(parents=True, exist_ok=True)
            file_exist_content = path_subfolder + "/" + "not_empty.txt"
            with open(file_exist_content, "w") as f:
                f.write("")
    
    for i in tqdm(range(len(gt_label))):
        rs1010, rs1515, rs3232, rs6464, rs6565, rs,\
             rsdct1010, rsdct1515, rsdct3232, rsdct6464, rsdct6565, rsdcts = compute_confusion_matrix(gt_label[i], detect[i],
                                                                           classes, conf_score, iou_score)
        rsdct_list = [rsdct1010, rsdct1515, rsdct3232, rsdct6464, rsdct6565, rsdcts]
        for j, rsdct in enumerate(rsdct_list):
            for keys in rsdct:
                arr_save = rsdct[keys]
                arr_save = xyxy2strxywh(arr_save, wh[i][0], wh[i][1])
                path_file_save = save_dir_list[j] + "/" + keys + "/" + name_file[i] + ".txt"
                
                if len(arr_save) > 0:
                    with open(path_file_save, "w") as f:
                        f.writelines(arr_save)
                    file_exist_content = save_dir_list[j] + "/" + keys + "/" + "not_empty.txt"
                    with open(file_exist_content, "a") as f:
                        f.write(name_file[i] + "\n")
                        
                    if 'FP' in keys or 'FN' in keys:
                        org_img = origin_image +'/'+ name_file[i] + '.jpg'
                        tmp_dir = save_dir_list[j] + "/" + keys
                        shutil.copy2(org_img, tmp_dir)    
                        
        
        matrix1010 += rs1010
        matrix1515 += rs1515
        matrix3232 += rs3232
        matrix6464 += rs6464
        matrix6565 += rs6565
        matrix += rs
        if np.array_equal(rs, rs1010+rs1515+rs3232+rs6464+rs6565) == False:
            print("Matrix not equal")
            print(f"Something wrong in file:{name_file[i]}, index {i}")
            print("Review again")
            break
    if np.array_equal(matrix, matrix1010+matrix1515+matrix3232+matrix6464+matrix6565) == True:
        print("All equal")
        total1010 = np.sum(matrix1010, axis=0)
        matrix_precent1010 = matrix1010 / total1010
        total1515 = np.sum(matrix1515, axis=0)
        matrix_precent1515 = matrix1515 / total1515
        total3232 = np.sum(matrix3232, axis=0)
        matrix_precent3232 = matrix3232 / total3232
        total6464 = np.sum(matrix6464, axis=0)
        matrix_precent6464 = matrix6464 / total6464
        total6565 = np.sum(matrix6565, axis=0)
        matrix_precent6565 = matrix6565 / total6565
        total = np.sum(matrix, axis=0)
        matrix_precent = matrix / total
        fig1010_1, fig1010_2 = draw_confusion_matrix(matrix1010, matrix_precent1010, conf_score, iou_score, classes)
        fig1515_1, fig1515_2 = draw_confusion_matrix(matrix1515, matrix_precent1515, conf_score, iou_score, classes)
        fig3232_1, fig3232_2 = draw_confusion_matrix(matrix3232, matrix_precent3232, conf_score, iou_score, classes)
        fig6464_1, fig6464_2 = draw_confusion_matrix(matrix6464, matrix_precent6464, conf_score, iou_score, classes)
        fig6565_1, fig6565_2 = draw_confusion_matrix(matrix6565, matrix_precent6565, conf_score, iou_score, classes)
        fig1, fig2 = draw_confusion_matrix(matrix, matrix_precent, conf_score, iou_score, classes)

        fig1010_1.savefig(Path(save_dir1010) / 'confusion_matrix_1010.png', dpi=250)
        fig1010_1.savefig(Path(save_dir_image) / 'confusion_matrix_1010.png', dpi=250)
        fig1010_2.savefig(Path(save_dir1010) / 'confusion_matrix_1010_pc.png', dpi=250)

        fig1515_1.savefig(Path(save_dir1515) / 'confusion_matrix_1515.png', dpi=250)
        fig1515_1.savefig(Path(save_dir_image) / 'confusion_matrix_1515.png', dpi=250)
        fig1515_2.savefig(Path(save_dir1515) / 'confusion_matrix_1515_pc.png', dpi=250)

        fig3232_1.savefig(Path(save_dir3232) / 'confusion_matrix_3232.png', dpi=250)
        fig3232_1.savefig(Path(save_dir_image) / 'confusion_matrix_3232.png', dpi=250)
        fig3232_2.savefig(Path(save_dir3232) / 'confusion_matrix_3232_pc.png', dpi=250)

        fig6464_1.savefig(Path(save_dir6464) / 'confusion_matrix_6464.png', dpi=250)
        fig6464_1.savefig(Path(save_dir_image) / 'confusion_matrix_6464.png', dpi=250)
        fig6464_2.savefig(Path(save_dir6464) / 'confusion_matrix_6464_pc.png', dpi=250)

        fig6565_1.savefig(Path(save_dir6565) / 'confusion_matrix_other.png', dpi=250)
        fig6565_1.savefig(Path(save_dir_image) / 'confusion_matrix_other.png', dpi=250)
        fig6565_2.savefig(Path(save_dir6565) / 'confusion_matrix_other_pc.png', dpi=250)

        fig1.savefig(Path(save_dirall) / 'confusion_matrix.png', dpi=250)
        fig1.savefig(Path(save_dir_image) / 'confusion_matrix.png', dpi=250)
        fig2.savefig(Path(save_dirall) / 'confusion_matrix_pc.png', dpi=250)

        print("All results save in:", save_dir)
    else:
        print("Not equal, check again")
    
    return matrix[1][1]/(matrix[1][1] + matrix[1][2] + 1e-6)
    
if __name__ == "__main__":
        
    parser = argparse.ArgumentParser("Confusion matrix")
    parser.add_argument('--glog', required=True, type=str)
    parser.add_argument('--ilog', required=True, type=str)
    parser.add_argument('--plog', required=True, type=str)
    classes = ["0", "1"]
    confident_score = 0.1
    iou_score = 0.1
    args = parser.parse_args()
    ground_path_txt = args.glog
    image_path = args.ilog
    predict_path = args.plog  
    # ground_path_txt = "/mnt/data/chinnl/data/annotated_tank_sim/tank_sb_916_T02_00000002_17_05_clip1/obj_train_data/train"
    # predict_path = "/mnt/data/chinnl/data/deblur_result_new/tank_sb_916_T02_00000002_17_05_clip1_db"
    # image_path = ground_path_txt

    
    save_confusion_matrix_v1(ground_path_txt, predict_path, image_path, confident_score, iou_score, classes)
    
    #python 0_1_test_confusion_matrix_ver7.py --glog '/home/pc1/works/HungNV/tank/all/ground_imgs_au/RGBshift' --ilog '/home/pc1/works/HungNV/tank/all/ground_imgs_au/RGBshift' --plog '/home/pc1/works/HungNV/tank/all/ground_imgs_au/RGBshift_predict/label_predict/label_with_score'  




