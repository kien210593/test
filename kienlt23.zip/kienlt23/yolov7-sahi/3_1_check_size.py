#!/usr/bin/env python
# coding: utf-8


import numpy as np
import pandas as pd
from PIL import Image
from glob import glob
import os
import cv2
from pathlib import Path
import random
from tqdm import tqdm
import shutil
import argparse
from shapely.geometry import Polygon
from util import yolo2xyxy, read_size


def convert_box2yolo1(size, box): # (x_top, y_top, x_bot, y_bot)
    width = size[0]
    height = size[1]
    return (box[0]+box[2])/(2*width), (box[1]+box[3])/(2*height), (box[2]-box[0])/width, (box[3]-box[1])/height
def is_file_empty(file_path):
    return os.path.getsize(file_path) == 0




def check_size_HBB(folder_input):
    txt_dir = sorted(glob(folder_input + '/*.txt'))
    parent_folder = str(Path(folder_input).parent.absolute())
    # name_new_folder = '_'.join(folder_track_im.split("/")[-1].split("_")[:-2])
    name_new_folder = '_'.join(folder_input.split("/")[-1].split("_")) 
    # print(name_new_folder)
    # 1/0
    tar_dir1 = parent_folder + "/" + name_new_folder + '_checkeds/'
    # print(tar_dir1)
    tar_dir0 = parent_folder + "/" + name_new_folder + '_checkedl/'
    Path(tar_dir1).mkdir(parents=True, exist_ok=True)
    Path(tar_dir0).mkdir(parents=True, exist_ok=True)
    columns = ['class', 'x0', 'y0', 'dw', 'dh']
    sz1 = [640, 640]
    for (txt_i, txt) in enumerate(tqdm(txt_dir, "check_size:")):
        if 'classes' in txt:
            os.remove(txt)
        else:
            img = txt[:-4]+ '.jpg'
            # print('img:', img)
            # print(txt)
            df = pd.read_csv(txt, header = None, names = columns, sep = ' ')
            df1 =df[df['class']==1]
            df1 = df1.reset_index(drop= True)
            
            # print(df1)
            if len(df1)>0:
                # print('txt:', txt)
                box1 = [df1['x0'][0], df1['y0'][0], df1['dw'][0], df1['dh'][0]]
                w1 = box1[2]*640
                h1 = box1[3]*640
                if max(w1, h1)< 60:
                    # print(txt)
                    if os.path.exists(txt) and os.path.exists(img):
                        shutil.copy2(txt, tar_dir1)
                        shutil.copy2(img, tar_dir1)
                else:
                    if os.path.exists(txt) and os.path.exists(img):
                        shutil.copy2(txt, tar_dir0)
                        shutil.copy2(img, tar_dir0)
             

def check_size_OBB(folder_input):
    txt_dir = sorted(glob(folder_input + '/*.txt'))
    parent_folder = str(Path(folder_input).parent.absolute())
    # name_new_folder = '_'.join(folder_track_im.split("/")[-1].split("_")[:-2])
    name_new_folder = '_'.join(folder_input.split("/")[-1].split("_")) 
    # print(name_new_folder)
    # 1/0
    tar_dir1 = parent_folder + "/" + name_new_folder + '_checkeds/'
    # print(tar_dir1)
    tar_dir0 = parent_folder + "/" + name_new_folder + '_checkedl/'
    Path(tar_dir1).mkdir(parents=True, exist_ok=True)
    Path(tar_dir0).mkdir(parents=True, exist_ok=True)
    columns = ['class', 'x0', 'y0', 'x1', 'y1', 'x2', 'y2', 'x3','y3']
    sz1 = [640, 640]
    for (txt_i, txt) in enumerate(tqdm(txt_dir, "check_size:")):
        if 'classes' in txt:
            os.remove(txt)
        else:
            img = txt[:-4]+ '.jpg'
            # print('img:', img)
            # print(txt)
            df = pd.read_csv(txt, header = None, names = columns, sep = ' ')
            df1 =df[df['class']==1]
            df1 = df1.reset_index(drop= True)
            
            # print(df1)
            if len(df1)>0:
                # print('txt:', txt)
                box0 = [df['x0'][0], df['y0'][0], df['x1'][0], df['y1'][0], df['x2'][0], df['y2'][0], df['x3'][0], df['y3'][0]] 
                box0 = yolo2xyxy(read_size(img), box0)
                box = np.array([[box0[0], box0[1]],
                                [box0[2], box0[3]],
                                [box0[4], box0[5]],
                                [box0[6], box0[7]]])
                
                poly = Polygon(box)

                if poly.area < 40:
                    # print(txt)
                    if os.path.exists(txt) and os.path.exists(img):
                        shutil.copy2(txt, tar_dir1)
                        shutil.copy2(img, tar_dir1)
                else:
                    if os.path.exists(txt) and os.path.exists(img):
                        shutil.copy2(txt, tar_dir0)
                        shutil.copy2(img, tar_dir0)
                        
                        
                        
if __name__ == "__main__":
        
    parser = argparse.ArgumentParser("check_size")
    parser.add_argument('--ilog', required=True, type=str)
    parser.add_argument('--type', required=True, type=str)
    args = parser.parse_args()
    
    input_folder = args.ilog
    
    if args.type == 'hbb':
        check_size_HBB(input_folder)
    else:
        check_size_OBB(input_folder)




