import os
import sys
import argparse

import cv2
import torch
import numpy as np
from glob import glob

sys.path.append(os.path.join(os.getcwd(), 'EFTrack'))
from ef.core.config import cfg
from ef.models.model_builder import ModelBuilder
from ef.tracker.tracker_builder import build_tracker
from ef.utils.model_load import load_pretrain

torch.set_num_threads(1)

parser = argparse.ArgumentParser(description='tracking demo')
parser.add_argument('--config', type=str, help='config file', default= 'EFTrack/experiments/efficienet/config.yaml')
parser.add_argument('--snapshot', type=str, help='model name', default= 'EFTrack/experiments/efficienet/snapshot/checkpoint_e21.pth')
parser.add_argument('--video-path', type=str, help='For detect folder path')
parser.add_argument('-a', '--after-click-folder', type=str,
                    help='The track_img folder path')
parser.add_argument('--wait-ms', default=100, type=int,
                    help='the wait time between frames (MILISECONDS)')
args = parser.parse_args()

IMAGE_SUFFIXES = ['.jpg', '.png']

def initROI(after_click_folder):
    tracked_frame_list = os.listdir(after_click_folder)
    tracked_frame_list.sort()
    
    init_frame_path = os.path.join(after_click_folder, tracked_frame_list[0])
    frame = cv2.imread(init_frame_path)

    init_track_label = init_frame_path.replace("_tracking_im/", "_tracking_lb/")[:-4] + ".txt"
    with open(init_track_label, "r") as f:
        init_label = f.readlines()[0].replace("\n", "")
    init_label = [float(v) for v in init_label.split(" ")]
    cls = int(init_label.pop(0))

    frame_h, frame_w = frame.shape[:-1]
    cx = int(init_label[0]*frame_w)
    cy = int(init_label[1]*frame_h)
    w = int(init_label[2]*frame_w)
    h = int(init_label[3]*frame_h)
    x1 = cx - w//2
    y1 = cy - h//2
    # cv2.rectangle(frame, (x1, y1), (x1+w, y1+h), (0, 255, 0), 1)
    # cv2.imwrite('first_frame.png', frame)
    return cls, [x1, y1, w, h], frame, tracked_frame_list[0]

def get_frames(video_path_or_images_dir, reversed = False):
    """
    Returns a stream of (frame, frame_name) from a video or directory of images.
    Returns:
        frame: numpy array of current frame
        frame_name: name of current frame without extension (to output corresponding labels later)
    """
    frame_cnt = 0
    if not video_path_or_images_dir:
        cap = cv2.VideoCapture(0)
        # warmup
        for i in range(5):
            cap.read()
        while True:
            ret, frame = cap.read()
            if ret:
                frame_name = f'{10000+frame_cnt}'
                frame_cnt += 1
                yield frame, frame_name
            else:
                break
    elif video_path_or_images_dir.endswith('avi') or video_path_or_images_dir.endswith('mp4'):
        cap = cv2.VideoCapture(video_path_or_images_dir)
        video_name = os.path.splitext(os.path.basename(video_path_or_images_dir))[0]
        while True:
            ret, frame = cap.read()
            if ret:
                frame_name = f'{video_name}_{10000+frame_cnt}'
                frame_cnt += 1
                yield frame, frame_name
            else:
                cap.release()
                break
    else:
        imgs = []
        for suffix in IMAGE_SUFFIXES:
            imgs += sorted(glob(os.path.join(video_path_or_images_dir, f'*{suffix}')))
        if reversed:
            imgs.reverse()
        for img in imgs:
            frame = cv2.imread(img)
            frame_name = os.path.splitext(os.path.basename(img))[0]
            yield frame, frame_name
            
class StabTest:
    def __init__(self):
        self.pre_img = None
        self.detector = cv2.ORB_create()
        self.matcher = cv2.DescriptorMatcher_create(cv2.DESCRIPTOR_MATCHER_BRUTEFORCE_HAMMING)
        self.gme_rs = np.eye(3, dtype=np.float32)

    def init(self, in_frame):
        self.pre_img = in_frame.copy()
        self.gme_rs = np.eye(3, dtype=np.float32)
        return True

    def process(self, in_frame):
        frame = in_frame.copy()
        # print('----StabTest process---')
        # print('pre_img vs frame SSIM', ssim(self.pre_img[:,:,0], frame[:,:,0]))
        kp1, des1 = self.detector.detectAndCompute(self.pre_img, None)
        kp2, des2 = self.detector.detectAndCompute(frame, None)
        # print('kp1', kp1)
        # print('kp2', kp2)
        # print('des1', des1)
        # print('des2', des2)
        if des1 is None or des2 is None:
            self.gme_rs = np.eye(3, dtype=np.float32)
            return self.gme_rs

        matches = self.matcher.match(des1, des2, None)
        matches = sorted(matches, key=lambda x: x.distance)
        # print('number matches', len(matches))
        if len(matches) < 4:
            self.gme_rs = np.eye(3, dtype=np.float32)
            return self.gme_rs

        pts1 = np.float32([kp1[m.queryIdx].pt for m in matches[:30]]).reshape(-1, 1, 2)
        pts2 = np.float32([kp2[m.trainIdx].pt for m in matches[:30]]).reshape(-1, 1, 2)

        self.gme_rs, mask = cv2.estimateAffinePartial2D(pts1, pts2, cv2.RANSAC, ransacReprojThreshold=2)

        if self.gme_rs is None:
            self.gme_rs = np.eye(3, dtype=np.float32)
        else:
            self.gme_rs = np.vstack([self.gme_rs, [0, 0, 1]])

        # if not (pts1==pts2).all():
        #     print('pts1', pts1)
        #     print('pts2', pts2)
        #     print('pts1==pts2', (pts1==pts2).all())
        #     print('gme_rs', self.gme_rs)
        #     exit()
        self.pre_img = frame.copy()
        return self.gme_rs

    def get_gme_matrix(self):
        if self.gme_rs.size != 0:
            return self.gme_rs.copy()
        return None

    # Usage example:
    # stab_test = StabTest()
    # frame = cv2.imread("path_to_image")
    # stab_test.init(frame)
    # result = stab_test.process(frame)
    # gme_matrix = stab_test.get_gme_matrix()

def main():
    print('Start tracking!')    # Copy potential threading-issue code to this
    # load config
    cfg.merge_from_file(args.config)
    cfg.CUDA = torch.cuda.is_available() and cfg.CUDA
    device = torch.device('cuda' if cfg.CUDA else 'cpu')

    # create model
    model = ModelBuilder()

    # load model
    # model = load_pretrain(model, args.snapshot).eval().to(device)
    model.load_state_dict(torch.load(args.snapshot,
                                     map_location=lambda storage, loc: storage.cpu())['state_dict'])
    model.eval().to(device)
    
    stab_test = StabTest()

    # build tracker
    tracker = build_tracker(model)
    print('Done build tracker!')

    video_name = args.video_path.split("/")[-1]
    print('Done video name', video_name)

    # create txt_dir
    dir_txt = '/'.join(args.video_path.split('/')
                           [:-1]) + '/' + video_name + '_tracking_lb'
    dir_img = dir_txt.replace("_tracking_lb", "_tracking_im")
    dir_pred = dir_txt.replace("_tracking_lb", "_tracking_im_predict")
    os.makedirs(dir_txt, exist_ok=True)
    os.makedirs(dir_img, exist_ok=True)
    os.makedirs(dir_pred, exist_ok=True)
    
    # print(f'Output texts to {dir_txt}')
    # cv2.namedWindow(video_name, cv2.WINDOW_NORMAL)

    if args.after_click_folder:
        after_click_folder = args.after_click_folder
    else:
        after_click_folder = args.video_path.replace("_for_detect", "tracking_im")

    cls, init_rect, init_frame, init_frame_name = initROI(after_click_folder)
    # cv2.imwrite(os.path.join(dir_pred, init_frame_name), init_frame) 
    # cv2.imshow(video_name, init_frame)
    height, width = init_frame.shape[:-1]

    tracker.init(init_frame, init_rect)
    stab_test.init(init_frame)
    lost_tracking_count = 0
    out_of_frame_count = 0
    # Read frames from video-path folder in reversed order
    for frame, frame_name in get_frames(args.video_path, reversed = True):
        label_path = os.path.join(dir_txt, f'{frame_name}.txt')
        # print('Processing', frame_name, 'saving to', label_path)
        
        result = stab_test.process(frame)
        gme = stab_test.get_gme_matrix()
        
        gme = np.transpose(gme)
        outputs = tracker.track(frame, gme)
        bbox = list(map(int, outputs['bbox']))
        dx = (bbox[0] + bbox[2] / 2) / width
        dy = (bbox[1] + bbox[3] / 2) / height
        dw = bbox[2] / width
        dh = bbox[3] / height

        x2 = bbox[0]+bbox[2]
        y2 = bbox[1]+bbox[3]
        
        if min(bbox[2], bbox[3]) < 8:
            print("End tracking due to small object.")
            break
        
        if x2 >= width or y2 >= height:
            out_of_frame_count +=1
        else:
            out_of_frame_count = 0

        if out_of_frame_count == 10:
            print('End tracking due to object out of frame.')
            break        
        
        # # Put text of frame number
        # cv2.setWindowTitle(video_name, 'Frame #' + str(frame_name))
        
        if (gme - np.eye(3)).sum() == 0:
            lost_tracking_count += 1
        else:
            lost_tracking_count = 0
            with open(label_path, 'w') as f:
                f.write(
                    f"{cls} {' '.join(f'{txt:.6f}' for txt in (dx, dy, dw, dh))}")
            cv2.imwrite(os.path.join(dir_img, f"{frame_name}.jpg"), frame)
            
            cv2.rectangle(
                frame, (bbox[0], bbox[1]), (bbox[0]+bbox[2], bbox[1]+bbox[3]), (0, 255, 0), 1)

            # annotate dw, dh
            cv2.putText(frame, f'{dw*width:.0f}x{dh*height:.0f}',
                        (bbox[0], bbox[1]-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2) 
            
            cv2.imwrite(os.path.join(dir_pred, f"{frame_name}.jpg"), frame)           
        if lost_tracking_count == 10:
            print('End tracking after 10 frames of tracking lost.')
            break
        
        
        '''  
        # Put instructions
        font_color = (0, 0, 0)
        # cv2.putText(frame, 'Press s to select ROI again', (20, 15), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1, font_color, 1)
        cv2.putText(frame, 'Press esc to quit', (20, 35), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1, font_color, 1)
        color = (255, 0, 0)
        cv2.circle(frame, (int(tracker.dic[0]), int(tracker.dic[1])), 2, color, -1)
        cv2.imshow(video_name, frame)

        # exit by 'esc' 
        k = cv2.waitKey(args.wait_ms)
        if k == 27:
            exit()
            break
        '''

if __name__ == '__main__':
    main()
