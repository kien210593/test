#!/usr/bin/env python
# coding: utf-8

# In[14]:


import cv2
from pyzbar.pyzbar import decode
import numpy as np
import pandas as pd
from PIL import Image
import glob
import os
from pathlib import Path
import random
import re
from tqdm import tqdm
import argparse


# In[15]:


def increment_path(path, exist_ok=True, sep=''):
    # Increment path, i.e. runs/exp --> runs/exp{sep}0, runs/exp{sep}1 etc.
    path = Path(path)  # os-agnostic
    if (path.exists() and exist_ok) or (not path.exists()):
        return str(path)
    else:
        dirs = glob.glob(f"{path}{sep}*")  # similar paths
        matches = [re.search(rf"%s{sep}(\d+)" % path.stem, d) for d in dirs]
        i = [int(m.groups()[0]) for m in matches if m]  # indices
        n = max(i) + 1 if i else 2  # increment number
        return f"{path}{sep}{n}"  # update path
    

def read_file_seeker(folder_video_path):
    startID = 0
    startX = 0
    startY = 0
    # width = 170
    # height = 12
    width = 164
    height = 20
    #print('folder_video_path:', folder_video_path)
    if os.path.isfile(folder_video_path) and folder_video_path[-4:] == ".mp4":
        vid_dir = [folder_video_path]
    else:
        vid_dir = sorted(glob.glob(folder_video_path + '/' + '*.mp4'))
    number_video = len(vid_dir)
    #print('vid_dir:', vid_dir)
    for (vid_i, vid_path) in enumerate(tqdm(vid_dir, 'tracking')):
        video = cv2.VideoCapture(vid_path)
        
        name_video = Path(vid_path).name[:-4]
        #print(name_video)
        
        # save_dir = vid_path[:-4] + "_extract"
        save_dir = vid_path[:-4]
        save_dir = increment_path(save_dir, exist_ok=False)
        Path(save_dir).mkdir(parents=True, exist_ok=True)
        
        # save_video_dir = save_dir + "/" + "ex"
        # Path(save_video_dir).mkdir(parents=True, exist_ok=True)
        
        number_frame = int(video.get(cv2.CAP_PROP_FRAME_COUNT))

        frame_id = 10001
        decode_list = []
        previous_barcode_data = ""
        barcode_error = 5555555
        while True:
            ret, frame = video.read()
            if ret:
                cropped_image = frame[startY:startY+ height, startX: startX+width]
                decode_objects = decode(frame)
                # print(decode_objects)
                for obj in decode_objects:
                    barcode_data = obj.data.decode('utf-8')
                    # print(barcode_data)
                    barcode_type = obj.type
                    try:
                        barcode_data = int(barcode_data[0:7])
                    except:
                        barcode_data = barcode_error
                        barcode_error += 1
                    if barcode_data != previous_barcode_data:
                        name_image = name_video + "_" + str(frame_id) + "_" + str(barcode_data) + ".jpg"
                        path_image = save_dir + "/" + name_image
                        cv2.imwrite(path_image, frame)
                        previous_barcode_data = barcode_data
                        decode_list.append(barcode_data)
                #print(f'video {vid_i + 1}/{number_video} ({frame_id}/{number_frame}) {vid_path}: ')
                frame_id += 1
            else:
                break
        assert len(decode_list) == len(set(decode_list)), "Double code ID, check again"
#         startID = decode_list[0]
#         print(startID)
#         save_in = parent_folder + "/" + name_new_json
#         dict_all = {"dic_detect": dic_detect, "dic_TiT":dic_TiT, "dic_redetect": dic_redetect}
#         with open(save_in, 'w') as f:
#             json.dump(dict_all, f)
#             decode_list = None
                
#     print("All result save in:", save_dir1_Extract_frame_v1)            
#    return startID

# In[24]:


# folder_video_path = "/home/pc1/works/HungNV/tank/9/tank_sb_916_Txx_00000009_07_03_clip5.mp4"
# read_file_seeker(folder_video_path)


if __name__ == "__main__":
        
    parser = argparse.ArgumentParser("Extract_frame")
    parser.add_argument('--vlog', required=False, type=str)
    
    args = parser.parse_args()
    
    folder_video_path = args.vlog 

    
    read_file_seeker(folder_video_path)
    
    #python 1_Extract_frame_v1.py --vlog "/home/pc1/works/HungNV/tank/11/tank_sb_916_T24_00000011_12_03_clip1.mp4"




