import pandas as pd
import cv2
import numpy as np
import glob
import os
from PIL import Image 
import shutil


IMAGE_SUFFIXES = ['jpg', 'png']

def read_im(path):
    return np.array(Image.open(path))

def read_lb(path):
    lb_txt = pd.read_csv(path, header=None)
    lbs = processing_bounding_box(lb_txt.to_numpy()) #xywhn
    return lbs

def cp_file(org_dir, dst, oname, dname):
    shutil.copyfile(f"{org_dir}/{oname}", f"{dst}/{dname}")
    
def glob_images_all_suffixes(dir):
    im_list = []
    for suffix in IMAGE_SUFFIXES:
        im_list += sorted(glob.glob(os.path.join(dir, f"*.{suffix}")))
    return im_list

def get_luminance(rgb_im):
    yuv = cv2.cvtColor(rgb_im, cv2.COLOR_RGB2YUV)
    return yuv[:,:,0]

def recreate_dir(dst):
    if os.path.isdir(dst):
        shutil.rmtree(dst)
    os.makedirs(dst)

def processing_bounding_box(arr_box):
    process_box = []
    for box in arr_box:
        boxes = box[0].split(" ")
        boxes1 = [float(ele) for ele in boxes if ele != '']
        boxes1[0] = int(boxes[0])
        process_box.append(boxes1)
    return process_box

def xywh2xyxy(arr_box, width, height):
    '''
    Arguments:
        arr_box (Array[N, 5]) (class, x1_center_norm, y1_center_norm, w_norm, h_norm)
    Returns:
        arr (Array[N, 5]): (class, x1, y1, x2, y2)
    '''
    box_convert = []
    for box in arr_box:
        box1 = []
        box1.append(box[0])
        x_left = box[1] - (box[3] / 2)
        x_left = int(x_left * width)
        y_left = box[2] - (box[4] / 2)
        y_left = int(y_left * height)
        x_right = box[1] + (box[3] / 2)
        x_right = int(x_right * width)
        y_right = box[2] + (box[4] / 2)
        y_right = int(y_right * height)

        box1.append(x_left)
        box1.append(y_left)
        box1.append(x_right)
        box1.append(y_right)
        box_convert.append(box1)
    return box_convert

def xyxy2xywh(box, width, height):
    if len(box) == 4:
        x1, y1, x2, y2 = box
        cls = None
    else:
        x1, y1, x2, y2 = box[1:5]
        cls = box[0]
    
    cx = (x1 + x2)/2
    cy = (y1 + y2)/2
    w = x2 - x1
    h = y2 - y1
    cxn = cx/width
    cyn = cy/height
    wn = w/width
    hn = h/height
    if cls is None:
        return [cxn, cyn, wn, hn]
    else:
        return [cls, cxn, cyn, wn, hn]

def xyxy2strxywh(arr_box, width, height):
    '''
    Arguments:
        arr_box (Array[N, 6]) (class, x1, y1, x2, y2, conf)
    Returns:
        arr (List[N]): (string(class, x_center_norm, y_center_norm, w_norm, h_norm, conf, \n))
    '''
    list_boxes_center = []
    if len(arr_box) <= 0:
        return list_boxes_center
    for boxes in arr_box:
        boxes_center = []
        boxes_center.append(str(boxes[0]))
        boxes_center.append(str(round(((boxes[1] / width) + (boxes[3] / width)) / 2, 6)))
        boxes_center.append(str(round(((boxes[2] / height) + (boxes[4] / height)) / 2, 6)))
        boxes_center.append(str(round(((boxes[3] / width) - (boxes[1] / width)), 6)))
        boxes_center.append(str(round(((boxes[4] / height) - (boxes[2] / height)), 6)))
        if len(boxes) == 6:
            boxes_center.append(str(boxes[5]))
        boxes_center.append("\n")
        str_box = " ".join(boxes_center)
        list_boxes_center.append(str_box)
    return list_boxes_center

def get_object_boxes_mask(im, xywhn):
    mask = np.zeros_like(im[:,:,0])
    H, W = im.shape[:2]
    boxes = []
    for lb in xywhn:
        # if lb[0] == 1:
        xn, yn, wn, hn = lb[1:5]
        boxes.append([int(xn*W), int(yn*H), int(wn*W), int(hn*H)])
        mask = cv2.rectangle(mask, 
                            (int(lb[1]*im.shape[1]), 
                                int(lb[2]*im.shape[0])),
                            (int((lb[1] + lb[3])*im.shape[1]), 
                                int((lb[2] + lb[4])*im.shape[0])),
                            1,
                            -1)
    if len(boxes) > 0:
        boxes = np.stack(boxes)
    else:
        boxes = None
    return boxes, mask.astype(np.uint8)

def line(t,cx,cy, angle):
    return (cx + t * np.cos(angle)).astype(np.int32), (cy + t * np.sin(angle)).astype(np.int32)

def line_inv(x, y, cx, cy):
    r = np.sqrt((x - cx)**2 + (y - cy)**2)
    a = (x >= cx)*np.arctan((y-cy)/(x - cx)) + (
            x < cx)*(np.arctan((y - cy)/(x - cx)) + np.pi)
    return r, a 

def line_and_values(t,cx,cy, angle):
    t = t.astype(float)
    X = (cx + t * np.cos(angle)).astype(np.int32)
    Y = (cy + t * np.sin(angle)).astype(np.int32)
    t = t/t.max()
    f = 6
    I = np.exp(-f*t) - np.exp(-f*t).min()
    I = I/I.max()
    # I = I.astype(np.int32)
    return X, Y, I

def get_angle(obj_boxes, cx, cy, rad):
    x, y, w, h = obj_boxes[0]
    phi = np.arctan(w/h)
    if cx <= x:
        xl1 = rad*np.cos(np.pi/2 - phi) + x + w
        yl1 = y - rad*np.sin(np.pi/2 - phi)
        xl2 = x - rad*np.cos(phi)
        yl2 = rad*np.sin(phi) + y + h

        al1 = np.arctan(abs(yl1 - cy)/abs(xl1 - cx))
        al2 = np.arctan(abs(yl2 - cy)/abs(xl2 - cx))
    
    elif x< cx and cx <= x + w:
        al1 = np.pi/2 - np.arctan(abs(x + w - cx)/abs(y - cy))
        al2 = np.pi/2 + np.arctan(abs(cx - x)/abs(y - cy))
    else:
        xl1 = rad*np.sin(phi) + x + w
        yl1 = rad*np.cos(phi) + y + h
        xl2 = x - rad*np.cos(np.pi/2 - phi)
        yl2 = y - rad*np.sin(np.pi/2 - phi)

        al1 = np.pi - np.arctan(abs(yl1 - cy)/abs(xl1 - cx))
        al2 = np.pi - np.arctan(abs(yl2 - cy)/abs(xl2 - cx))

    return al1, al2

def get_rad_limit(H, W, cx, cy, a):
    offset = 1e-6
    if a >= 0:
        a = max(a, 1e-6)
        tmax = np.ceil(
            int(a > np.pi/2)* min(cx, (H - cy)/(np.tan(np.pi - a) + offset)) / (np.cos(np.pi - a) + offset) + 
            int(a < np.pi/2)* min(W - cx, (H - cy)/(np.tan(a) + offset)) / (np.cos(a) + offset) + 
            int(a == np.pi/2)*(H - cy)
            )
    else:
        tmax = np.ceil(
            int(a > -np.pi/2)* min(W - cx, cy/(np.tan(-a) + offset)) / (np.cos(-a) + offset) + 
            int (a < -np.pi/2)* min(cx, cy/(np.tan(np.pi + a) + offset)) / (np.cos(np.pi + a) + offset) +
            int (a == -np.pi/2)*cy
            )

    return int(tmax)

# def yolo2xyxy(size, box):
#     w = size[0]
#     h = size[1]
#     x1 = round((box[0]-box[2]/2)*w)
#     y1 = round((box[1]-box[3]/2)*h)
#     x2 = round((box[0]+box[2]/2)*w)
#     y2 = round((box[1]+box[3]/2)*h)
#     return (x1, y1, x2, y2)
def yolo2xyxy(size, box):
    w = size[0]
    h = size[1]
    output_box = []
    
    if len(box) > 4:
        for i in range(0, len(box), 2):
            output_box.append(box[i]*w)
            output_box.append(box[i+1]*h)
    else:
        x1 = round((box[0]-box[2]/2)*w)
        y1 = round((box[1]-box[3]/2)*h)
        x2 = round((box[0]+box[2]/2)*w)
        y2 = round((box[1]+box[3]/2)*h)
        output_box = [x1, y1, x2, y2]
    return output_box

def read_size(img_file):
    # width, height
    img = Image.open(img_file)
    sz = img.size
    img.close()
    return sz