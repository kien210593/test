#!/bin/bash

parent_folder="/mnt/data/hungnv152/data/UAV_2X/bia_video/bia_den_tam_trang/simple/T12B/T12B/video_record/test"
csv_file="/mnt/data/hungnv152/data/UAV_2X/bia_video/bia_den_tam_trang/simple/T12B/T12B/video_record/test/00000012.csv"
bandicam_log="/mnt/data/hungnv152/data/UAV_2X/bia_video/bia_den_tam_trang/simple/T12B/T12B/video_record/test/00000012_bdc.csv"
json_file="/mnt/data/hungnv152/data/UAV_2X/bia_video/bia_den_tam_trang/simple/T12B/T12B/video_record/test/sb_916_bia_video_0724_00000012.json"

## Find only imediate child directories (input folders)
#input_folders=($(find "$parent_folder" -maxdepth 1 -mindepth 1 -type d |sort))
#output_folder="/home/temp_data/output_folder"

#videos=($(find "$parent_folder" -type f \( -iname "*.mp4" -o -iname "*.avi"\) |sort))
videos=($(find "$parent_folder" -type f -name "*.mp4" |sort))
# videos=($(find "$parent_folder" -maxdepth 1 -mindepth 1 -type d |sort))

#echo "$videos"

GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RESET='\033[0m'

for vid in "${videos[@]}"; do
	echo -e "${GREEN}vid: $vid.${RESET}"
	# python 1_Extract_frame_v1.py --vlog "$vid"
	---------- PROCESS FRAMES AFTER CLICKED ----------
	startID=$(python 2_0_read_file_seeker_v1.py --ilog "${vid::-4}" --csv "$csv_file")
	echo -e "${YELLOW}startID: $startID.${RESET}"
	python 2_1_take_image_for_detect.py --ilog "${vid::-4}" --min_ID $startID
	python predict_sahi_all_tank_sim.py --log "${vid::-4}_tracking_im"
	python 2_2_compare_track_w_predict_v2.py --ilog "${vid::-4}_tracking_im" --ltlog "${vid::-4}_tracking_lb/" --lplog "${vid::-4}_tracking_im_predict/label_predict/label_no_score/" --imgsz 1920 1080
	python 3_0_resize_to_predict_v2.py --ilog "${vid::-4}_tracking_im" --llog "${vid::-4}_lb_org"  --type "hbb" 
	python 3_1_check_size.py --ilog "${vid::-4}_tracking_im_crop_rs" --type "hbb"
	python predict_sahi_all_tank_sim.py --log "${vid::-4}_tracking_im_crop_rs_checkeds"
	python 0_1_test_confusion_matrix_ver7.py --glog "${vid::-4}_tracking_im_crop_rs_checkeds" --ilog "${vid::-4}_tracking_im_crop_rs_checkeds" --plog "${vid::-4}_tracking_im_crop_rs_checkeds_predict/label_predict/label_with_score"
	python 4_compute_error_box_center_v1.py --tlog "${vid::-4}_tracking_im" --tllog "${vid::-4}_tracking_lb" --plog "${vid::-4}_tracking_im_predict/label_predict/label_no_score" --json "$json_file" 

	python 5_draw.py --csv "${vid::-4}_tracking_cp_error/results.csv" --blog "$bandicam_log" --json "$json_file" --tg "${vid::-4}"
	python 6_cp_contrast.py --txtlog "${vid::-4}_tracking_cp_error/results0.csv" --ilog "${vid::-4}" --tglog "${vid::-4}.txt"
	
	# ---------- PROCESS FRAMES BEFORE CLICKED ----------
	python predict_sahi_all_tank_sim.py --log "${vid::-4}_for_detect" 
	python 7_reverse_tracking_for_detect.py --video-path "${vid::-4}_for_detect" -a "${vid::-4}_tracking_im"
    python 2_2_compare_track_w_predict_v2.py --ilog "${vid::-4}_for_detect" --ltlog "${vid::-4}_for_detect_tracking_lb/" --lplog "${vid::-4}_for_detect_predict/label_predict/label_no_score/"  --imgsz 1920 1080
	python 3_0_resize_to_predict_v2.py --ilog "${vid::-4}_for_detect" --llog "${vid::-4}_for_detect_lb_org"  --type "hbb"
	python 3_1_check_size.py --ilog "${vid::-4}_for_detect_crop_rs" --type "hbb"
	python predict_sahi_all_tank_sim.py --log "${vid::-4}_for_detect_crop_rs_checkeds"
	python 0_1_test_confusion_matrix_ver7.py --glog "${vid::-4}_for_detect_crop_rs_checkeds" --ilog "${vid::-4}_for_detect_crop_rs_checkeds" --plog "${vid::-4}_for_detect_crop_rs_checkeds_predict/label_predict/label_with_score"
	# echo -e "${GREEN}json: ${vid::-10}.json.${RESET}"
done