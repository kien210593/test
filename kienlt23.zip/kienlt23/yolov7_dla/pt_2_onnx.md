# Copy `export_no_head.py` to your yolov7 folder to use
# Yolov7 architecture modification
In order to inference a YoloV7 (or V5 as well) on DLA cores, each node of the model must follow the restrictions of the DLA cores specified on [NVIDIA TensorRT documentations](https://docs.nvidia.com/deeplearning/tensorrt/archives/tensorrt-853/developer-guide/index.html#dla_topic).
Thus, some nodes of Yolov7 model must be modificated or removed to make the model be able to run on DLA cores.

**All changes are implemented in the **`load_model`** function in `scripts/qat.pt` file.** Below are explainations of the modifications that is needed to quantize the model into INT8 and inference on DLA cores.

## 1. Max-pooling layer
Restriction for `Pooling layer`:
    
- Only two spatial dimension operations are supported.
- Both FP16 and INT8 are supported.
- Operations supported: **kMAX**, **kAVERAGE**.
- Dimensions of the **window** must be in the range **[1, 8]**.
- Dimensions of **padding** must be in the range **[0, 7]**.
- Dimensions of **stride** must be in the range **[1, 16]**.
- With INT8 mode, input and output tensor scales must be the same.

In Yolov7, layer maxpool 32 and 33 have kernel sizes and padding values that exceed the requirement ranges. Thus we need to chunk it into sequences of "smaller" pooling nodes. 

*MaxPooling 32 (kernel size = 9, padding = 4) and MaxPooling 33 (kernel size = 13, padding = 6) are converted to sequence of 2 layers: {MaxPooling 32.0, 32.1} (kernel size = 5, padding = 2) and {MaxPooling 33.0, 33.1} (kernel size = 7, padding = 3).*
<img style="width: 600px; height: 400px;" src=fig_dla_01.jpg>


Fortunately, there isn't any Convolution ops exceed the limits above, thus we don't have to re-train or fine-tune the modified model.

## 2. Transpose and Shuffle
Yolov7 split and transpose the output feature maps from `B x (7*na) x H x W` into `B x (na x H x W) x 7`. These operations are not supported on DLA cores, so they are eliminated.

The model now return 3 outputs at shape `B x (7*na) x H x W`. Where *'na'* denoted the number of anchor boxes predicted per grid cell.

## 3. Sigmoid function of IDetect head
There are 3 **Sigmoid** functions for 3 output tensors called inside of the forward functions of the `IDetect` head. They are not pre-defined as attributes of the model, thus the scale and zero-point calculating process in quantization may not consider them. Thus, a new layer contains 3 Sigmoid nodes named `OutSigmoid` is added to the head. `IDetect` head now feed the 3 feature maps through this new layer.

Due to those changes, the model requires a custom forward function, it is also defined in the **`load_model`** function in `scripts/qat.pt` file.

## 4. Element-wise
DLA does not support operations with constant scalar/tensor variables, thus only Element-wise operations between *non-leaf tensors*, i.e output of an operator, are supported.

## 5. Concat/Split
DLA only support Concat/Split on channel dim and output tensors must have 4 dims.

## 6. Convert to ONNX model 
All above modifications are done in `export_no_head.py`, just run this command to convert .pt model to ONNX, then convert the ONNX to TRTEngine on edge devices.
```
python export_no_head.py --weights=runs/train/exp2/weights/best.pt --grid --simplify
```
