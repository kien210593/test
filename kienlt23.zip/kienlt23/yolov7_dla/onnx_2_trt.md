## ! Different I/O format requires different pre/post-processing
Sample command:
```
trtexec --onnx=best.onnx --inputIOFormats=fp16:dla_linear --outputIOFormats=fp16:dla_linear --fp16 --useDLACore=0 --useSpinWait
```
Argument `useSpinWait` is optional. 

